//
//  HasDetectionCoreDataTool.h
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HistoricalInformation+CoreDataProperties.h" // 历史信息表 -- Historical information table
#import "EmergencyContact+CoreDataProperties.h"      // 紧急联系人表 -- Emergency contact list
#import "UserInformation+CoreDataProperties.h"       // 用户信息表 -- The user information table
#import "SettingForm+CoreDataProperties.h"           // 历史信息表 -- Historical information table
#import "AlarmNotify+CoreDataClass.h"                // 警报记录表 -- Alarm record

#import "HistoricalDataDay+CoreDataProperties.h"     // 历史信息表_天 -- Historical information table _ days

#import "HHBluetoothModel.h" // 蓝牙数据model -- Bluetooth data model

NS_ASSUME_NONNULL_BEGIN

@interface GasDetectionCoreDataTool : NSObject

@property (nonatomic,strong)NSManagedObjectContext *context;


/// 提供快速创建方法 -- Provides a quick creation method
+ (instancetype)shared;


/// 读取历史数据表 一天的数据 -- Read history data table data of a day
- (HistoricalDataDay *)HHReadDataHistoricalData_Day:(NSDate *)date;

/// 读取历史数据表 -- Read the history data tables
- (NSArray<HistoricalDataDay *> *)HHReadDataHistoricalData_All;

/// 插入历史数据表 -- Inserting historical data tables
- (void)HHInsertDataHistoricalDataDay:(HHBluetoothModel *)bluetoothModel;

/// 删除历史数据表 一天 -- Delete the history data table for a day
- (void)HHDeleteDataHistoricalData_Day:(NSDate *)date;

/// 删除历史数据表 全部 -- Delete the history data table all of them
- (void)HHDeleteDataHistoricalData_All;






/// 读取查询设置表  保存直接修改model信息调用 HHUpdateData -- Read the query table to save directly modify call HHUpdateData model information
- (SettingForm *)HHReadDataSettingForm;

/// 读取用户信息表  保存直接修改model信息调用 HHUpdateData -- Read the user information table call HHUpdateData save directly modify the model information
- (UserInformation *)HHReadDataUserInformation;



/// 读取紧急联系人数据表 -- Read the emergency contact data tables
- (NSArray<EmergencyContact *> *)HHReadDataEmergencyContact;

/// 插入紧急联系人数据表 -- Insert the emergency contact data tables
- (void)HHInsertDataEmergencyContact:(NSString *)name PhoneNumber:(NSString *)phoneNumber Email:(NSString *)email EmergencyInformation:(NSString *)emergencyInformation;

/// 删除紧急联系人表 -- Delete the emergency contact list
- (void)HHDeleteDataEmergencyContact:(EmergencyContact *)emergencyContact;


/// 读取警报通知数据表 -- Read the warning notice data tables
- (NSArray<AlarmNotify *> *)HHReadDataAlarmNotify;

/// 插入警报通知数据表 -- Insert an alert data tables
- (AlarmNotify *)HHInsertDataAlarmNotify:(HHBluetoothModel *)bluetoothModel;

/// 删除警报通知数据表 -- To delete an alert data tables
- (void)HHDeleteDataAlarmNotify:(AlarmNotify *)alarmNotify;





/// 修改设置表 -- Change the setting table
- (void)HHUpdateData;




@end

NS_ASSUME_NONNULL_END
