//
//  HasDetectionCoreDataTool.m
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "GasDetectionCoreDataTool.h"
#import "NSDate+Extension.h"

@implementation GasDetectionCoreDataTool

// 用来保存唯一的单例对象 -- Used to store only a singleton
static GasDetectionCoreDataTool *instance;

+ (instancetype)shared {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

+ (id)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}

- (id)copyWithZone:(NSZone *)zone {
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化 -- Initialize the
- (void)Initialize {
    
    /// 创建数据库 -- Create the database
    [self HHCreateSqlite];
    
}


/// 创建数据库 -- Create the database
- (void)HHCreateSqlite {
    
    // 数据库的名称和路径
    NSString *filePath = FILEPATH_D(@"/database");
    
    // 判断是文件是否存在 （主要是看路径指的是目录还是文件）
    BOOL isExist = [[NSFileManager defaultManager] fileExistsAtPath:filePath];
    
    // 判断文件是否存在 不存在创建
    if (isExist == NO) {
        // 根据路径创建文件夹
        NSError *error = nil;
        [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:&error];
        if (error) {
            NSLog(@"创建数据库文件夹错误:%@",error.localizedDescription);
        }
    }
    
    
    // 拼接路径
    NSString *sqlPath = [filePath stringByAppendingPathComponent:@"coreData.sqlite"];

    
    // 1、创建模型对象
    // 获取模型路径
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"GasDetectionModel" withExtension:@"momd"];
    // 根据模型文件创建模型对象
    NSManagedObjectModel *coreModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    // 2、创建持久化存储助理：数据库
    // 利用模型对象创建助理对象
    NSPersistentStoreCoordinator *coreStore = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:coreModel];
    
    NSError *error = nil;
    // 设置数据库相关信息 添加一个持久化存储库并设置存储类型和路径，NSSQLiteStoreType：SQLite作为存储库
    [coreStore addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:[NSURL fileURLWithPath:sqlPath] options:nil error:&error];
    
    if (error) {
        NSLog(@"初始化数据库失败:%@",error);
        
        /// 弹出提示框 清理数据 退出程序
        [self HHRepairCatch];
    } else {
        NSLog(@"初始化数据库成功");
    }
    
    // 3、创建上下文 保存信息 操作数据库
    NSManagedObjectContext *context = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    // 关联持久化助理
    context.persistentStoreCoordinator = coreStore;
    // 赋值给全局属性
    self.context = context;
    
}





/// 读取历史数据表 一天的数据
- (HistoricalDataDay *)HHReadDataHistoricalData_Day:(NSDate *)date {
    
    // 创建查询请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"HistoricalDataDay"];
    
    // 查询条件
    NSPredicate *pre = [NSPredicate predicateWithFormat:@"localTime == %@",[date HHDateTime:@"YYYY-MM-dd"]];
    request.predicate = pre;
    
    // 发送查询请求,并返回结果
    NSArray<HistoricalDataDay *> *resArray = [self.context executeFetchRequest:request error:nil];
    
//    NSLog(@"读取历史数据表_Day:\n%@",resArray);
    
    return resArray.firstObject;
}


/// 读取历史数据表
- (NSArray<HistoricalDataDay *> *)HHReadDataHistoricalData_All {
    
    // 创建查询请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"HistoricalDataDay"];
    
    // 发送查询请求,并返回结果
    NSArray<HistoricalDataDay *> *resArray = [self.context executeFetchRequest:request error:nil];
    
//    NSLog(@"读取历史数据表_All:\n%@",resArray);
    
    return resArray;
}



/// 插入历史数据表
- (void)HHInsertDataHistoricalDataDay:(HHBluetoothModel *)bluetoothModel {
    
    /// 获取当前天数的数据
    HistoricalDataDay *dayModel = [self HHReadDataHistoricalData_Day:bluetoothModel.recordingTime];
    
    /// 判断当前插入s日期是否存在 不存在创建
    if (!dayModel) {
        
        // 1.在表中插入新的值
        dayModel = [NSEntityDescription insertNewObjectForEntityForName:@"HistoricalDataDay" inManagedObjectContext:self.context];
        /// UTC 时间
        dayModel.recordingTime = bluetoothModel.recordingTime;
        /// 字符串日期 用来读取时间的标记
        dayModel.localTime = [bluetoothModel.recordingTime HHDateTime:@"YYYY-MM-dd"];
        /// 修改设置表
        [self HHUpdateData];
    }
    
    /// 1.创建新的值
    HistoricalInformation *historicalInformation = [[HistoricalInformation alloc] initWithContext:self.context];
    /// 记录时间
    historicalInformation.recordingTime = bluetoothModel.recordingTime;
    /// 记录设备UUID
    historicalInformation.identifier = bluetoothModel.identifier;
    /// 记录服务UUID
    historicalInformation.service_uuid = bluetoothModel.service_uuid;
    /// 记录原始数据
    historicalInformation.originalData = bluetoothModel.originalData;
    /// 传感器1
    historicalInformation.sensor1 = bluetoothModel.sensor1_float;
    /// 传感器2
    historicalInformation.sensor2 = bluetoothModel.sensor2_float;
    /// 温度
    historicalInformation.temperature = bluetoothModel.temperature_float;
    /// 湿度
    historicalInformation.humidity = bluetoothModel.humidity_float;
    /// 压力
    historicalInformation.pressure = bluetoothModel.pressure_float;
    /// 电池电压
    historicalInformation.batteryVoltage = bluetoothModel.batteryVoltage_float;
    /// 记录位置地址
    historicalInformation.locationAddress = bluetoothModel.locationAddress;
    /// 天气信息
    historicalInformation.weather = bluetoothModel.weather;

    
    /// 2.添加新的值
    [dayModel addHistoricalDataObject:historicalInformation];
    
    /// 修改设置表
    [self HHUpdateData];
    
}


/// 删除历史数据表 一天
- (void)HHDeleteDataHistoricalData_Day:(NSDate *)date {
    
    /// 获取当前天数的数据
    HistoricalDataDay *dayModel = [self HHReadDataHistoricalData_Day:date];
    
    /// 判断当前插入s日期是否存在
    if (!dayModel) {
        return;
    }
    
    
    // 创建删除请求
    NSFetchRequest *deleRequest = [NSFetchRequest fetchRequestWithEntityName:@"HistoricalDataDay"];
    
    // 删除条件
    NSPredicate *pre = [NSPredicate predicateWithFormat:@"localTime == %@",[date HHDateTime:@"YYYY-MM-dd"]];
    deleRequest.predicate = pre;
    
    // 返回需要删除的对象数组
    NSArray<HistoricalDataDay *> *deleArray = [self.context executeFetchRequest:deleRequest error:nil];
    
    // 从数据库中删除
    for (HistoricalInformation *historicalInformation in deleArray) {
        [self.context deleteObject:historicalInformation];
    }
    
    /// 修改设置表
    [self HHUpdateData];
}


/// 删除历史数据表 全部
- (void)HHDeleteDataHistoricalData_All {
    
    // 创建删除请求
    NSFetchRequest *deleRequest = [NSFetchRequest fetchRequestWithEntityName:@"HistoricalDataDay"];

    // 返回需要删除的对象数组
    NSArray<HistoricalDataDay *> *deleArray = [self.context executeFetchRequest:deleRequest error:nil];
    
    // 从数据库中删除
    for (HistoricalInformation *historicalInformation in deleArray) {
        [self.context deleteObject:historicalInformation];
    }
    
    /// 修改设置表
    [self HHUpdateData];
}





















/// 读取查询设置表
- (SettingForm *)HHReadDataSettingForm {
    
    // 创建查询请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"SettingForm"];

    // 发送查询请求,并返回结果
    NSArray<SettingForm *> *resArray = [self.context executeFetchRequest:request error:nil];
    
//    NSLog(@"读取查询设置表:\n%@",resArray);
    
    // 判断数组是否存在  不存在初始化
    if (resArray.count <= 0) {
        // 1.根据Entity名称和NSManagedObjectContext获取一个新的继承于NSManagedObject的子类Student
        SettingForm *settingForm = [NSEntityDescription insertNewObjectForEntityForName:@"SettingForm" inManagedObjectContext:self.context];
  
        /// 数据读取频率
        settingForm.frequency = 3.0;
        /// 是否推送12
        settingForm.isPush = YES;
        /// 是否响铃
        settingForm.isVoice = YES;
        /// 是否震动
        settingForm.isVibration = YES;
        /// 是否自动联系紧急联系人
        settingForm.isContactEmergencyContact = NO;
        /// 是否自动拨打电话
        settingForm.isAutoPhoneCall = NO;
        
        /// 修改设置表
        [self HHUpdateData];
        
        return settingForm;
    }
    
    return [resArray firstObject];
}


/// 读取用户信息表
- (UserInformation *)HHReadDataUserInformation {
    
    // 创建查询请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"UserInformation"];
    
    // 发送查询请求,并返回结果
    NSArray<UserInformation *> *resArray = [self.context executeFetchRequest:request error:nil];
    
//    NSLog(@"读取查询设置表:\n%@",resArray);
    
    // 判断数组是否存在  不存在初始化
    if (resArray.count <= 0) {
        // 1.根据Entity名称和NSManagedObjectContext获取一个新的继承于NSManagedObject的子类Student
        UserInformation *settingForm = [NSEntityDescription insertNewObjectForEntityForName:@"UserInformation" inManagedObjectContext:self.context];

        /// 修改设置表
        [self HHUpdateData];
        
        return settingForm;
    }
    
    return [resArray firstObject];
}





/// 读取紧急联系人数据表
- (NSArray<EmergencyContact *> *)HHReadDataEmergencyContact {
    
    // 创建查询请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"EmergencyContact"];

    // 发送查询请求,并返回结果
    NSArray<EmergencyContact *> *resArray = [self.context executeFetchRequest:request error:nil];
    
//    NSLog(@"读取历史数据表:\n%@",resArray);
    
    return [NSArray arrayWithArray:resArray];
    
}

/// 插入紧急联系人数据表
- (void)HHInsertDataEmergencyContact:(NSString *)name PhoneNumber:(NSString *)phoneNumber Email:(NSString *)email EmergencyInformation:(NSString *)emergencyInformation {
    
    // 1.根据Entity名称和NSManagedObjectContext获取一个新的继承于NSManagedObject的子类Student
    EmergencyContact *emergencyContact = [NSEntityDescription insertNewObjectForEntityForName:@"EmergencyContact" inManagedObjectContext:self.context];
    
    /// 姓名
    emergencyContact.name = name;
    /// 手机号
    emergencyContact.phoneNumber = phoneNumber;
    /// 邮箱
    emergencyContact.email = email;
    /// 紧急信息
    emergencyContact.emergencyInformation = emergencyInformation;
    
    /// 修改设置表
    [self HHUpdateData];
}

/// 删除紧急联系人表
- (void)HHDeleteDataEmergencyContact:(EmergencyContact *)emergencyContact {
    
    // 创建删除请求
    NSFetchRequest *deleRequest = [NSFetchRequest fetchRequestWithEntityName:@"EmergencyContact"];
    
    // 删除条件
    NSPredicate *pre = [NSPredicate predicateWithFormat:@"phoneNumber == %@",emergencyContact.phoneNumber];
    deleRequest.predicate = pre;
    
    // 返回需要删除的对象数组
    NSArray *deleArray = [self.context executeFetchRequest:deleRequest error:nil];
    
    // 从数据库中删除
    for (EmergencyContact *emergencyContact in deleArray) {
        [self.context deleteObject:emergencyContact];
    }
    
    /// 修改设置表
    [self HHUpdateData];
    
}




/// 读取警报通知数据表
- (NSArray<AlarmNotify *> *)HHReadDataAlarmNotify {
    
    // 创建查询请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"AlarmNotify"];
    
    // 发送查询请求,并返回结果
    NSArray<AlarmNotify *> *resArray = [self.context executeFetchRequest:request error:nil];
    
//    NSLog(@"读取历史数据表:\n%@",resArray);
    
    return [NSArray arrayWithArray:resArray];
    
}

/// 插入警报通知数据表
- (AlarmNotify *)HHInsertDataAlarmNotify:(HHBluetoothModel *)bluetoothModel {
    
    // 1.根据Entity名称和NSManagedObjectContext获取一个新的继承于NSManagedObject的子类Student
    AlarmNotify *alarmNotify = [NSEntityDescription insertNewObjectForEntityForName:@"AlarmNotify" inManagedObjectContext:self.context];
    
    /// 记录开始时间
    alarmNotify.startTime = bluetoothModel.recordingTime;
    
    /// 记录设备UUID
    alarmNotify.identifier = bluetoothModel.identifier;
    /// 记录服务UUID
    alarmNotify.service_uuid = bluetoothModel.service_uuid;
    /// 记录原始数据
    alarmNotify.originalData = bluetoothModel.originalData;
    /// 传感器1
    alarmNotify.sensor1 = bluetoothModel.sensor1_float;
    /// 传感器2
    alarmNotify.sensor2 = bluetoothModel.sensor2_float;
    /// 温度
    alarmNotify.temperature = bluetoothModel.temperature_float;
    /// 湿度
    alarmNotify.humidity = bluetoothModel.humidity_float;
    /// 压力
    alarmNotify.pressure = bluetoothModel.pressure_float;
    /// 电池电压
    alarmNotify.batteryVoltage = bluetoothModel.batteryVoltage_float;
    /// 记录位置地址
    alarmNotify.locationAddress = bluetoothModel.locationAddress;
    /// 天气信息
    alarmNotify.weather = bluetoothModel.weather;
    
    /// 修改设置表
    [self HHUpdateData];
    
    return alarmNotify;
}

/// 删除警报通知数据表
- (void)HHDeleteDataAlarmNotify:(AlarmNotify *)alarmNotify {
    
    // 创建删除请求
    NSFetchRequest *deleRequest = [NSFetchRequest fetchRequestWithEntityName:@"AlarmNotify"];
    
    // 删除条件
    NSPredicate *pre = [NSPredicate predicateWithFormat:@"startTime == %@",alarmNotify.startTime];
    deleRequest.predicate = pre;
    
    // 返回需要删除的对象数组
    NSArray *deleArray = [self.context executeFetchRequest:deleRequest error:nil];
    
    // 从数据库中删除
    for (AlarmNotify *alarmNotify in deleArray) {
        [self.context deleteObject:alarmNotify];
    }
    
    /// 修改设置表
    [self HHUpdateData];
    
}








/// 修改设置表
- (void)HHUpdateData {
    
    @try {
        
        // 保存
        NSError *error = nil;
        // 判断是否保存成功
        if ([self.context save:&error]) {
//            NSLog(@"更新设置表成功:%@",[self HHReadDataIPloreDisplayType]);
        }else{
            NSLog(@"更新设置表失败:%@", error.localizedDescription);
        }
        
    } @catch (NSException *exception) {
        
        /// 弹出提示框 清理数据 退出程序
        [self HHRepairCatch];
        
    } @finally {
//        NSLog(@"代码执行成功");
    }
}


/// 弹出提示框 清理数据 退出程序
- (void)HHRepairCatch {
    
    NSLog(@"发生闪退,尝试清理数据库恢复!!!  ❌");
    
    // 1.创建UIAlertController
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"程序崩溃~" message:@"数据库崩溃导致,点击确认删除数据库~" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *stopAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        // 数据库的名称和路径
        NSString *filePath = FILEPATH_D(@"/database");
        /// 根据路径删除文件
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
        
        /// 手动退出程序
        exit(0);
    }];
    [alertController addAction:stopAction];
    // 初始化UIWindows
    UIWindow *window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    window.rootViewController = [[UIViewController alloc]init];
    window.windowLevel = UIWindowLevelAlert + 1;
    [window makeKeyAndVisible];
    [window.rootViewController presentViewController:alertController animated:YES completion:nil];
    
}



@end
