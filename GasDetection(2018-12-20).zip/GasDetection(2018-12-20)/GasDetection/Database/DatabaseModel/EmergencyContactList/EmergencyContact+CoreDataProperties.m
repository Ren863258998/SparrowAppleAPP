//
//  EmergencyContact+CoreDataProperties.m
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "EmergencyContact+CoreDataProperties.h"

@implementation EmergencyContact (CoreDataProperties)

+ (NSFetchRequest<EmergencyContact *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"EmergencyContact"];
}

@dynamic name;
@dynamic phoneNumber;
@dynamic email;
@dynamic emergencyInformation;

@end
