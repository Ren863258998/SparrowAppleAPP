//
//  EmergencyContact+CoreDataClass.m
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "EmergencyContact+CoreDataClass.h"

@implementation EmergencyContact

@end
