//
//  EmergencyContact+CoreDataProperties.h
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "EmergencyContact+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface EmergencyContact (CoreDataProperties)

+ (NSFetchRequest<EmergencyContact *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *phoneNumber;
@property (nullable, nonatomic, copy) NSString *email;
@property (nullable, nonatomic, copy) NSString *emergencyInformation;

@end

NS_ASSUME_NONNULL_END
