//
//  HistoricalInformation+CoreDataProperties.m
//  GasDetection
//
//  Created by 司月 on 2018/8/24.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "HistoricalInformation+CoreDataProperties.h"

@implementation HistoricalInformation (CoreDataProperties)

+ (NSFetchRequest<HistoricalInformation *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"HistoricalInformation"];
}

@dynamic batteryVoltage;
@dynamic humidity;
@dynamic identifier;
@dynamic locationAddress;
@dynamic originalData;
@dynamic pressure;
@dynamic sensor1;
@dynamic sensor2;
@dynamic service_uuid;
@dynamic temperature;
@dynamic weather;
@dynamic recordingTime;

@end
