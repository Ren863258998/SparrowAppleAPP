//
//  SettingForm+CoreDataProperties.h
//  GasDetection
//
//  Created by 司月 on 2018/8/30.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "SettingForm+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface SettingForm (CoreDataProperties)

+ (NSFetchRequest<SettingForm *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSUUID *equipmentUUID;
@property (nonatomic) float frequency;
@property (nonatomic) BOOL isPush;
@property (nonatomic) BOOL isVibration;
@property (nonatomic) BOOL isVoice;
@property (nonatomic) BOOL isContactEmergencyContact;
@property (nonatomic) BOOL isAutoPhoneCall;

@end

NS_ASSUME_NONNULL_END
