//
//  UserInformation+CoreDataProperties.h
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "UserInformation+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface UserInformation (CoreDataProperties)

+ (NSFetchRequest<UserInformation *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *sex;
@property (nullable, nonatomic, copy) NSString *birthday;
@property (nullable, nonatomic, copy) NSString *email;

@end

NS_ASSUME_NONNULL_END
