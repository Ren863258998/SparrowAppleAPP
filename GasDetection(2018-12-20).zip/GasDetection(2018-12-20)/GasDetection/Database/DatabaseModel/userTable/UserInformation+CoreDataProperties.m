//
//  UserInformation+CoreDataProperties.m
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "UserInformation+CoreDataProperties.h"

@implementation UserInformation (CoreDataProperties)

+ (NSFetchRequest<UserInformation *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"UserInformation"];
}

@dynamic name;
@dynamic sex;
@dynamic birthday;
@dynamic email;

@end
