//
//  AlarmNotify+CoreDataProperties.m
//  GasDetection
//
//  Created by 司月 on 2018/8/30.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "AlarmNotify+CoreDataProperties.h"

@implementation AlarmNotify (CoreDataProperties)

+ (NSFetchRequest<AlarmNotify *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"AlarmNotify"];
}

@dynamic batteryVoltage;
@dynamic humidity;
@dynamic identifier;
@dynamic locationAddress;
@dynamic originalData;
@dynamic pressure;
@dynamic sensor1;
@dynamic sensor2;
@dynamic service_uuid;
@dynamic temperature;
@dynamic weather;
@dynamic endTime;
@dynamic startTime;

@end
