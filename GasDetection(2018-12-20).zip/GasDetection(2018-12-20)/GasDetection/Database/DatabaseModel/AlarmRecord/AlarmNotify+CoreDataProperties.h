//
//  AlarmNotify+CoreDataProperties.h
//  GasDetection
//
//  Created by 司月 on 2018/8/30.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "AlarmNotify+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface AlarmNotify (CoreDataProperties)

+ (NSFetchRequest<AlarmNotify *> *)fetchRequest;

@property (nonatomic) float batteryVoltage;
@property (nonatomic) float humidity;
@property (nullable, nonatomic, copy) NSString *identifier;
@property (nullable, nonatomic, copy) NSString *locationAddress;
@property (nullable, nonatomic, copy) NSString *originalData;
@property (nonatomic) float pressure;
@property (nonatomic) float sensor1;
@property (nonatomic) float sensor2;
@property (nullable, nonatomic, copy) NSString *service_uuid;
@property (nonatomic) float temperature;
@property (nullable, nonatomic, copy) NSString *weather;
@property (nullable, nonatomic, copy) NSDate *endTime;
@property (nullable, nonatomic, copy) NSDate *startTime;

@end

NS_ASSUME_NONNULL_END
