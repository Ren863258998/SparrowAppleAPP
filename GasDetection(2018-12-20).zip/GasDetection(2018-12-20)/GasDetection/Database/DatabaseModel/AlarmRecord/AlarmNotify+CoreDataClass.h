//
//  AlarmNotify+CoreDataClass.h
//  GasDetection
//
//  Created by 司月 on 2018/8/30.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface AlarmNotify : NSManagedObject

/// 获取地址  Get the address
- (NSString *)HHAddress;


@end

NS_ASSUME_NONNULL_END

#import "AlarmNotify+CoreDataProperties.h"
