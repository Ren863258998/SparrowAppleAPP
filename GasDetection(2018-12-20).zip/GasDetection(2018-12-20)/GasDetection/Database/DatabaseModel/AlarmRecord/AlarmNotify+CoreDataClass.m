//
//  AlarmNotify+CoreDataClass.m
//  GasDetection
//
//  Created by 司月 on 2018/8/30.
//  Copyright © 2018年 syihh. All rights reserved.
//
//

#import "AlarmNotify+CoreDataClass.h"

@implementation AlarmNotify


/// 获取地址 Get the address
- (NSString *)HHAddress {
    
    NSString *address_temp = [[self.locationAddress componentsSeparatedByString:@"@"] firstObject];
    
    NSString *address_temp2 = [[address_temp componentsSeparatedByString:@","] lastObject];
    
    if (address_temp2.length > 0) {
        return address_temp2;
    }
    
    return address_temp;
}

@end
