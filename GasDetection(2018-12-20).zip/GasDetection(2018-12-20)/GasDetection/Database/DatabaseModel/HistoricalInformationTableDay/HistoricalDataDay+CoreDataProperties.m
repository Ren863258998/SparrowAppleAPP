//
//  HistoricalDataDay+CoreDataProperties.m
//  GasDetection
//
//  Created by 司月 on 2018/10/3.
//  Copyright © 2018 syihh. All rights reserved.
//
//

#import "HistoricalDataDay+CoreDataProperties.h"

@implementation HistoricalDataDay (CoreDataProperties)

+ (NSFetchRequest<HistoricalDataDay *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"HistoricalDataDay"];
}

@dynamic recordingTime;
@dynamic localTime;
@dynamic historicalData;


@end
