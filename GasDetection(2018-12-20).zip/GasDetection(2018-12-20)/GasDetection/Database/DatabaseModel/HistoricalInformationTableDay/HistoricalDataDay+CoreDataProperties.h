//
//  HistoricalDataDay+CoreDataProperties.h
//  GasDetection
//
//  Created by 司月 on 2018/10/3.
//  Copyright © 2018 syihh. All rights reserved.
//
//

#import "HistoricalDataDay+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface HistoricalDataDay (CoreDataProperties)

+ (NSFetchRequest<HistoricalDataDay *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSDate *recordingTime;

@property (nullable, nonatomic, copy) NSString *localTime;

@property (nullable, nonatomic, retain) NSSet<HistoricalInformation *> *historicalData;

@end

@interface HistoricalDataDay (CoreDataGeneratedAccessors)

- (void)addHistoricalDataObject:(HistoricalInformation *)value;
- (void)removeHistoricalDataObject:(HistoricalInformation *)value;
- (void)addHistoricalData:(NSSet<HistoricalInformation *> *)values;
- (void)removeHistoricalData:(NSSet<HistoricalInformation *> *)values;

@end

NS_ASSUME_NONNULL_END
