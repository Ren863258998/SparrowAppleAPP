//
//  HistoricalDataDay+CoreDataClass.h
//  GasDetection
//
//  Created by 司月 on 2018/10/3.
//  Copyright © 2018 syihh. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class HistoricalInformation;

NS_ASSUME_NONNULL_BEGIN

@interface HistoricalDataDay : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "HistoricalDataDay+CoreDataProperties.h"
