//
//  HistoricalDataDay+CoreDataClass.m
//  GasDetection
//
//  Created by 司月 on 2018/10/3.
//  Copyright © 2018 syihh. All rights reserved.
//
//

#import "HistoricalDataDay+CoreDataClass.h"

@implementation HistoricalDataDay

@end
