//
//  customAnnonation.h
//  GasDetection
//
//  Created by catbook on 2018/10/9.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface customAnnonation : NSObject<MKAnnotation>
/** 坐标位置 */
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
/** 标题 */
@property (nonatomic, copy) NSString *title;
/** 子标题 */
@property (nonatomic, copy) NSString *subtitle; 
@end

NS_ASSUME_NONNULL_END
