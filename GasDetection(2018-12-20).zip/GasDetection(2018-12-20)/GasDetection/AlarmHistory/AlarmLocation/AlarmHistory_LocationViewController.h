//
//  AlarmHistory_LocationViewController.h
//  GasDetection
//
//  Created by catbook on 2018/10/8.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import  <CoreLocation/CoreLocation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AlarmHistory_LocationViewController : UIViewController
// 报警的地理位置信息(大头针钉在什么地方)
@property (readonly, nonatomic) CLLocationCoordinate2D *location;

@property (strong, nonatomic) AlarmNotify * alarmModel;


@end

NS_ASSUME_NONNULL_END
