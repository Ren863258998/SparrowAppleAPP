//
//  AlarmHistory_LocationViewController.m
//  GasDetection
//
//  Created by catbook on 2018/10/8.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "AlarmHistory_LocationViewController.h"
//#import  <CoreLocation/CoreLocation.h>

#import  <MapKit/MapKit.h>

#import "MyAnnonation.h"


@interface AlarmHistory_LocationViewController () <CLLocationManagerDelegate ,MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;


@property(nonatomic,strong) CLLocationManager*locationManager;//定位管理

@property(nonatomic,assign) float latitude,longitude;//经纬度

@end

@implementation AlarmHistory_LocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"警报位置", @"");
    
    [self setBaseConfig];
}

- (void)setBaseConfig{
    
    _mapView.delegate = self;
    
    // 定位设置
    self.locationManager = [[CLLocationManager alloc] init];
    
    // 判断是否可用
    if (![CLLocationManager locationServicesEnabled]) {
                NSLog(@"当前设备定位不可用");
           }
    if ([CLLocationManager authorizationStatus] != kCLAuthorizationStatusAuthorizedWhenInUse) {
               [self.locationManager requestWhenInUseAuthorization];
    }
  
      // 设置地图的定位追踪
      _mapView.userTrackingMode = MKUserTrackingModeFollow;
  
      // 设置地图的类型
      _mapView.mapType = MKMapTypeStandard;
  
      // 添加大头针
      [self addAnnotation];
}

#pragma mark - 添加大头针
- (void)addAnnotation{
    
    
    NSLog(@"------%@",self.alarmModel.locationAddress);
    
    
    NSString *string = self.alarmModel.locationAddress;
    
    NSRange startRange = [string rangeOfString:@"<"];
    NSRange endRange = [string rangeOfString:@">"];
    NSRange range = NSMakeRange(startRange.location + startRange.length, endRange.location - startRange.location - startRange.length);
    NSString *result = [string substringWithRange:range];
    NSLog(@"开始 %@",result);
    // 截取的经纬度 +40.03771672,+116.35886492
    
    
    // 获取纬度
    NSRange startRange1 = [result rangeOfString:@"+"];
    NSRange endRange1 = [result rangeOfString:@","];
    NSRange range1 = NSMakeRange(startRange1.location + startRange1.length, endRange1.location - startRange1.location - startRange1.length);
    NSString *latitude = [result substringWithRange:range1];
    
    
    double latitude1 = [[NSString stringWithFormat:@"%.8f",[latitude doubleValue]]doubleValue];
    NSLog(@"纬度 %.8f",latitude1);
    
    // 分割字符串 取出最后部分的经度
    NSArray * arr = [result componentsSeparatedByString:@"+"];
    NSLog(@"数组%@",arr);
    NSString *longitude = [arr lastObject];
    
    double longitude1 = [[NSString stringWithFormat:@"%.8f",[longitude doubleValue]]doubleValue];
    NSLog(@"经度 %.8f",longitude1);
    
    // 设置位置
    CLLocationCoordinate2D location1 = CLLocationCoordinate2DMake(latitude1, longitude1);
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    point.coordinate = location1;
    point.title = [self.alarmModel HHAddress];
    point.subtitle = [NSString stringWithFormat:@"start:%@",[_alarmModel.startTime HHDateTime:@"YYYY-MM-dd HH:mm:ss"]];
    [_mapView addAnnotation:point];
    
//    [_mapView setCenterCoordinate:location1 animated:YES];
    
    //显示区域跨度
    MKCoordinateSpan span = MKCoordinateSpanMake(0.01, 0.01);
    
    //显示区域，第一个参数：经纬度为中心，第二个参数：跨区域显示
    MKCoordinateRegion region = MKCoordinateRegionMake(location1, span);
    
    //在地图上显示
    [self.mapView setRegion:region animated:YES];
    
}


#pragma mark - 代理方法
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
         NSLog(@"=====%@", userLocation);
}
//关于大头针

//- (nullable
//   MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation{
//   
//    //判断是不是用户的大头针数据模型
//    if ([annotation isKindOfClass:[MKUserLocation class]]) {
//        
//       MKAnnotationView *annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"111"];
//        
//                 //设置大头针视图的图片
//                 
//                 annotationView.image = [UIImage imageNamed:@"alarm-location-icon"];
//                 
//                 //是否允许显示插入视图
//                 
//                annotationView.canShowCallout =YES;
//                
//                 //设置大头针视图的中心点偏移
//                 
//                 // x左->向右
//                 
//                 // y正->向下
//                 
//                 // annotationView.centerOffset = CGPointMake(100, 0);
//                 
//          
//                 //设置大头针插入视图的偏移量
//                 
//                
//                 
//          // annotationView.calloutOffset = CGPointMake(100, 0);
//                 
//            
//            //设置大头针视图是不是可以拖动
//           annotationView.draggable = NO;
//        
//                 
//         //设置左侧配件视图
//                 
//            UIImageView *leftView = [[UIImageView alloc]initWithFrame:CGRectMake(0,0, 30,30)];
//        
//            leftView.image = [UIImage imageNamed:@"set-alarm-icon"];
//                 
//            annotationView.leftCalloutAccessoryView = leftView;
//        
//        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 30)];
//        label.text = @"1111";
//        annotationView.rightCalloutAccessoryView = label;
//        
//        annotationView.detailCalloutAccessoryView = label;
//                 
//               return annotationView;
//        
//        
//                 
//                }
//    
//     return nil;
//    
//}
//

@end
