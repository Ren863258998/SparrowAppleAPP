//
//  AlarmHistory_CoKnowledgeViewController.m
//  GasDetection
//
//  Created by catbook on 2018/10/8.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "AlarmHistory_CoKnowledgeViewController.h"

@interface AlarmHistory_CoKnowledgeViewController () <UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic , copy) NSArray *dataArray;
@end

@implementation AlarmHistory_CoKnowledgeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.title = NSLocalizedString(@"一氧化碳常识", @"");
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    
    self.dataArray = @[@"1.什么是一氧化碳",
                       @"2.有哪些危害",
                       @"3.如何预防",
                       @"4.如何急救",
                       @"5.等级划分",
                       ];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = self.dataArray[indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 45.;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}
@end
