//
//  HHAlarmHistoryCell.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/24.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHAlarmHistoryCell.h"

@implementation HHAlarmHistoryCell

+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView{
    HHAlarmHistoryCell *cell = (HHAlarmHistoryCell *)[tableView dequeueReusableCellWithIdentifier:@"HHAlarmHistoryCellId"];
    if (cell == nil) {
        cell= (HHAlarmHistoryCell *)[[[NSBundle  mainBundle]  loadNibNamed:@"HHAlarmHistoryCell" owner:nil options:nil]  lastObject];
        cell.backView.layer.cornerRadius = 10;
        cell.backView.layer.masksToBounds= YES;
        
    }
    
    return cell;
}

@end
