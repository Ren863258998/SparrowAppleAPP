//
//  HHAlarmHistoryCell.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/24.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHAlarmHistoryCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *alarmValue;
@property (weak, nonatomic) IBOutlet UILabel *alarmTime;
@property (weak, nonatomic) IBOutlet UILabel *alarmLocation;
@property (weak, nonatomic) IBOutlet UIImageView *backView;
@property (weak, nonatomic) IBOutlet UILabel *duration;

+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView;
@end

NS_ASSUME_NONNULL_END
