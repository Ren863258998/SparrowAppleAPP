//
//  HHAlarmViewController.m
//  GasDetection
//
//  Created by 司月 on 2018/8/14.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHAlarmViewController.h"
#import "HHAlarmHistoryCell.h"

#import "AlarmManager.h"

#import "NSDate+Extension.h"

#import "UIScrollView+EmptyDataSet.h" // 占位图

#import "HHUserNotifications.h"

#import <MessageUI/MessageUI.h>

#import "UIBarButtonItem+Block.h"

#import "AlarmHistory_CoKnowledgeViewController.h"

#import "AlarmHistory_LocationViewController.h"

@interface HHAlarmViewController () <UITableViewDelegate,UITableViewDataSource,DZNEmptyDataSetDelegate,DZNEmptyDataSetSource,MFMessageComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong)  NSMutableArray * dataArray;

@property (nonatomic, strong)  AlarmNotify * tmpAlarmModel;

@property (nonatomic, strong)  NSMutableArray * alarmDataArray; // 记录本次报警记录


@end

@implementation HHAlarmViewController

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize {
    
    // 获取通知中心单例
    NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
    
    __weak typeof(self) weakSelf = self;
    
    // 接收通知
    [notiCenter addObserverForName:@"HHWriteValue_s" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        
        /// 创建数据model
        HHBluetoothModel *bluetoothModel = note.object;
        
        if (bluetoothModel.sensor1_float > 10.0) {
            
            
            
            [weakSelf.alarmDataArray addObject:bluetoothModel];
            
            // 如果i连续三次出于报警状态 才让报警提示
            if (weakSelf.alarmDataArray.count >= 3) {
                if (!weakSelf.tmpAlarmModel) {
                    weakSelf.tmpAlarmModel = [[GasDetectionCoreDataTool shared] HHInsertDataAlarmNotify:bluetoothModel];
                    [[AlarmManager shared] play];
                    
                    // 报警提示
                    [weakSelf showAlert];
                    
                    
                    // 使用推送
                    if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.isPush) {
                        [HHUserNotifications HHLocalNotification:NSLocalizedString(@"当前处于危险环境中",@"") Subtitle:nil Body:nil Url:nil];
                    }
                }
                
                // 判断报警值是否大于 上一次警报值 为了记录最高的报警值
                if (bluetoothModel.sensor1_float > weakSelf.tmpAlarmModel.sensor1) {
                    weakSelf.tmpAlarmModel.sensor1 = bluetoothModel.sensor1_float;
                }
            }
            
            
            
            
        } else {
            
            
            
            // 在不报警状态下清空本地报警数据
            [weakSelf.alarmDataArray removeAllObjects];
            [[AlarmManager shared] stop];
            
            // 记录一下上次的报警结束时间 存入数据库
            if (weakSelf.tmpAlarmModel) {
                weakSelf.tmpAlarmModel.endTime = [NSDate date];
                [[GasDetectionCoreDataTool shared] HHUpdateData];
                [weakSelf updateAlarmData];
                
                [weakSelf.tableView reloadData];
            }
            
            // 清空临时报警数据
            self.tmpAlarmModel = nil;
        }
        
        
        
        
    }];
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.delegate   = self;
    self.tableView.dataSource = self;

    // 占位代理
    self.tableView.emptyDataSetSource = self;
    self.tableView.emptyDataSetDelegate = self;

   
    [self updateAlarmData];
    

    self.alarmDataArray = [NSMutableArray array];
    
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"关于",@"") style:UIBarButtonItemStylePlain target:self action:@selector(aboutCoInfoAction)];
    

}

- (void)aboutCoInfoAction{
    
    AlarmHistory_CoKnowledgeViewController *VC = [AlarmHistory_CoKnowledgeViewController new];
    VC.hidesBottomBarWhenPushed = YES;

    [self.navigationController pushViewController:VC animated:YES];
}

- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView {
    return YES;
}

- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
    return [UIImage imageNamed:@"icon_list_empty.png"];
}

- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView {
    NSString *title = NSLocalizedString(@"暂无文件",@"");
    NSDictionary *attributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:16.0f],NSForegroundColorAttributeName:RGBColor(206, 206, 206)};
    return [[NSAttributedString alloc] initWithString:title attributes:attributes];
}

// 销毁时
- (void)dealloc {
    
    // 移除观察者，Observer不能为nil
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}

- (void)updateAlarmData{
     self.dataArray = [NSMutableArray arrayWithArray:[[GasDetectionCoreDataTool shared] HHReadDataAlarmNotify]] ;
    
    // 数组倒序
    _dataArray = (NSMutableArray *)[[_dataArray reverseObjectEnumerator] allObjects];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataArray count];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HHAlarmHistoryCell *cell = [HHAlarmHistoryCell creatXibCellWithTableView:tableView];
    
    AlarmNotify * model = self.dataArray[indexPath.row];
    
    cell.alarmValue.text = @(model.sensor1).stringValue;
    cell.alarmLocation.text = [model HHAddress];
    cell.alarmTime.text = [NSString stringWithFormat:@"start:%@",[model.startTime HHDateTime:@"YYYY-MM-dd HH:mm:ss"]];
    cell.duration.text  = [NSString stringWithFormat:@"end:%@",[model.endTime HHDateTime:@"YYYY-MM-dd HH:mm:ss"]];
    
    
    
//    cell.backView.backgroundColor = RGBColor(49, 98, 177);
//    cell.alarmValue.textColor  = [self SYColorWith:[model.originalData floatValue]];
//    cell.alarmTime.textColor   = [self SYColorWith:[model.originalData floatValue]];
//    cell.alarmLocation.textColor = [self SYColorWith:[model.originalData floatValue]];
//    cell.duration.textColor      = [self SYColorWith:[model.originalData floatValue]];
    
//    cell.backView.backgroundColor = [self SYColorWith:[model.originalData floatValue]];
    cell.backView.image = [self SYImageWith:model.sensor1];
    return cell;
    
}

- (UIImage *)SYImageWith:(CGFloat)num{
    
    if (num <= 50) {
        return [UIImage imageNamed:@"报警历史淡绿"];
    }
    
    if (num <= 100) {
        return [UIImage imageNamed:@"报警历史黄"];
    }
    
    if (num <= 150) {
        return [UIImage imageNamed:@"报警历史橘红"];
    }
    
    if (num <= 200) {
        return [UIImage imageNamed:@"报警历史浅红"];
    }
    
    if (num <= 300) {
        return [UIImage imageNamed:@"报警历史浅红"];
    }
    
    if (num <= 500) {
        return [UIImage imageNamed:@"报警历史深红"];
    }
    
    return [UIImage imageNamed:@"报警历史深红"];
    
}
- (UIColor *)SYColorWith:(CGFloat)num{
    
    if (num <= 50) {
        return [UIColor colorWithRed:0/255. green:222/255. blue:0/255. alpha:1.];
    }
    
    if (num <= 100) {
        return [UIColor colorWithRed:225/255. green:230/255. blue:0/255. alpha:1.];
    }
    
    if (num <= 150) {
        return [UIColor colorWithRed:249/255. green:109/255. blue:0/255. alpha:1.];
    }
    
    if (num <= 200) {
        return [UIColor colorWithRed:240/255. green:0/255. blue:0/255. alpha:1.];
    }
    
    if (num <= 300) {
        return [UIColor colorWithRed:149/255. green:0/255. blue:63/255. alpha:1.];
    }
    
    if (num <= 500) {
        return [UIColor colorWithRed:122/255. green:0/255. blue:23/255. alpha:1.];
    }
    
    return [UIColor colorWithRed:0/255. green:0/255. blue:0/255. alpha:1.];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 126;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    AlarmHistory_LocationViewController *VC = [AlarmHistory_LocationViewController new];
    VC.hidesBottomBarWhenPushed = YES;
    AlarmNotify * model = self.dataArray[indexPath.row];

    VC.alarmModel = model;
    [self.navigationController pushViewController:VC animated:YES];
}


- (void)showAlert{
    
    // 是否设置自动紧急联系人信息
    if (![GasDetectionCoreDataTool shared].HHReadDataSettingForm.isContactEmergencyContact) {
        
        // 未设置紧急联系人 则只提示当前处于危险环境中
        [HHAlertController HHErrorNew:NSLocalizedString(@"提示",@"") Message:NSLocalizedString(@"当前出于危险环境中",@"")  ViewController:self ActionBlock:^{
            
        }];
        
        
        return;
    }
    
    
    // 判断是否设置了紧急联系人
    if ([[[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact] count] >= 1) {
        EmergencyContact *info = [[[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact] firstObject];
        
        
        UIAlertController *controller=[UIAlertController alertControllerWithTitle:NSLocalizedString(@"提示",@"") message:NSLocalizedString(@"是否联系紧急联系人",@"") preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *act1=[UIAlertAction actionWithTitle:NSLocalizedString(@"拨打紧急联系人电话",@"") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            // 拨打紧急联系人电话
            if (info.phoneNumber.length) {
                NSMutableString *str=[[NSMutableString alloc] initWithFormat:@"telprompt://%@",info.phoneNumber];
                
//                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:@{} completionHandler:^(BOOL success) {
                    
                }];
            } else {
                [HHAlertController HHErrorNew:NSLocalizedString(@"提示",@"") Message:NSLocalizedString(@"未设置正确的紧急联系人电话",@"") ViewController:self ActionBlock:^{
                    
                }];
            }
        }];
        UIAlertAction *act2=[UIAlertAction actionWithTitle:NSLocalizedString(@"给紧急联系人发送信息",@"") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            // 给紧急联系人发送信息 判断是否有电话信息
            if (info.phoneNumber.length) {
                MFMessageComposeViewController *vc = [[MFMessageComposeViewController alloc] init];
                // 设置短信内容
                vc.body = info.emergencyInformation;
                
                // 设置收件人列表
                vc.recipients = @[info.phoneNumber];  // 号码数组
                // 设置代理
                vc.messageComposeDelegate = self;
                // 显示控制器
                [self presentViewController:vc animated:YES completion:nil];
                
                
            } else {
                [HHAlertController HHErrorNew:NSLocalizedString(@"提示",@"") Message:NSLocalizedString(@"未设置正确的紧急联系人电话",@"") ViewController:self ActionBlock:^{
                    
                }];
            }
        }];
        UIAlertAction *act3=[UIAlertAction actionWithTitle:NSLocalizedString(@"取消",@"") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [controller addAction:act1];
        [controller addAction:act2];
        [controller addAction:act3];
        
        [self presentViewController:controller animated:YES completion:^{
            
        }];
    } else {
        [HHAlertController HHErrorNew:NSLocalizedString(@"提示",@"") Message:NSLocalizedString(@"未设置紧急联系人",@"") ViewController:self ActionBlock:^{
            
        }];
    }
  
    
}
    
#pragma mark -- 短信发送代理事件
- (void)messageComposeViewController:(MFMessageComposeViewController*)controller didFinishWithResult:(MessageComposeResult)result
{
    // 关闭短信界面
    [controller dismissViewControllerAnimated:YES completion:nil];
    if(result == MessageComposeResultCancelled) {
        NSLog(@"取消发送");
    } else if(result == MessageComposeResultSent) {
        NSLog(@"已经发出");
    } else {
        NSLog(@"发送失败");
    }
}


@end

