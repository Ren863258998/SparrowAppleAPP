//
//  HHAlarmViewController.h
//  GasDetection
//
//  Created by 司月 on 2018/8/14.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHAlarmViewController : HHViewController

@end

NS_ASSUME_NONNULL_END
