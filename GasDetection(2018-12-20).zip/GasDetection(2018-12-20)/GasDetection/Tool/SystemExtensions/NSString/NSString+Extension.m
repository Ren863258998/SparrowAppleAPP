//
//  NSString+Extension.m
//  GasDetection
//
//  Created by 司月 on 2018/10/4.
//  Copyright © 2018 syihh. All rights reserved.
//

#import "NSString+Extension.h"

@implementation NSString (Extension)

/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSDate *)HHDateTime:(NSString *)format {
    
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:format];
    
    NSDate *birthdayDate = [formatter dateFromString:self];
    
    return birthdayDate;
    
}

/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSDate *)HHDateTime_UTC:(NSString *)format {
    
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [formatter setDateFormat:format];
    
    NSDate *birthdayDate = [formatter dateFromString:self];
    
    return birthdayDate;
    
}









@end
