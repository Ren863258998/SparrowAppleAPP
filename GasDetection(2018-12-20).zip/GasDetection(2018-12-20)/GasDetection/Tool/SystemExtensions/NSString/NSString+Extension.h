//
//  NSString+Extension.h
//  GasDetection
//
//  Created by 司月 on 2018/10/4.
//  Copyright © 2018 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Extension)


/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSDate *)HHDateTime:(NSString *)format;

/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSDate *)HHDateTime_UTC:(NSString *)format;






@end

NS_ASSUME_NONNULL_END
