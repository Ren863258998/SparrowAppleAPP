//
//  UIBarButtonItem+Block.h
//  SYBarButtonItemBlock
//
//  Created by syihh on 16/5/20.
//  Copyright © 2016年 syinn. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^UIBarButtonItemAction)(UIBarButtonItem *item);


@interface UIBarButtonItem (Block)


/// UIBarButtonItem点击事件block 图片
- (UIBarButtonItem *)HHPic:(NSString *)pic Block:(UIBarButtonItemAction)blcok;

/// UIBarButtonItem点击事件block 文字
- (UIBarButtonItem *)HHContent:(NSString *)content Block:(UIBarButtonItemAction)blcok;



//// 导航条左按钮
//self.navigationItem.leftBarButtonItems = @[[[UIBarButtonItem new] SYInitWithContent:@"左按钮" ClickBlock:^{
//    weakSelf.label.text = @"左按钮点击1";
//}],[[UIBarButtonItem new] SYInitWithContent:@"左按钮" ClickBlock:^{
//    weakSelf.label.text = @"左按钮点击2";
//}]];
//
//// 导航条右按钮
//self.navigationItem.rightBarButtonItems = @[[[UIBarButtonItem new] SYInitWithContent:[UIImage imageNamed:@"arrow-right.png"] ClickBlock:^{
//    weakSelf.label.text = @"右按钮点击1";
//}],[[UIBarButtonItem new] SYInitWithContent:[UIImage imageNamed:@"arrow-right.png"] ClickBlock:^{
//    weakSelf.label.text = @"右按钮点击2";
//}]];

//// 导航条左按钮
//self.navigationItem.leftBarButtonItem = [[UIBarButtonItem new] SYInitWithContent:@"左按钮" ClickBlock:^{
//    weakSelf.label.text = @"左按钮点击";
//}];
//
//// 导航条右按钮
//self.navigationItem.rightBarButtonItem = [[UIBarButtonItem new] SYInitWithContent:[UIImage imageNamed:@"arrow-right.png"] ClickBlock:^{
//    weakSelf.label.text = @"右按钮点击";
//}];



@end
