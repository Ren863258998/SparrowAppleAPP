//
//  UIBarButtonItem+Block.m
//  SYBarButtonItemBlock
//
//  Created by syihh on 16/5/20.
//  Copyright © 2016年 syinn. All rights reserved.
//

#import "UIBarButtonItem+Block.h"
#import <objc/runtime.h>

static char *UIBarButtonItemActionBlock;

@implementation UIBarButtonItem (Block)


/// UIBarButtonItem点击事件block 图片
- (UIBarButtonItem *)HHPic:(NSString *)pic Block:(UIBarButtonItemAction)blcok {
    
    objc_setAssociatedObject(self, &UIBarButtonItemActionBlock, blcok, OBJC_ASSOCIATION_COPY_NONATOMIC);
    
    [self setStyle:UIBarButtonItemStylePlain];
    [self setTarget:self];
    [self setAction:@selector(click)];
    [self setImage:[UIImage imageNamed:pic]];
    
    return self;
}

/// UIBarButtonItem点击事件block 文字
- (UIBarButtonItem *)HHContent:(NSString *)content Block:(UIBarButtonItemAction)blcok {
    
    objc_setAssociatedObject(self, &UIBarButtonItemActionBlock, blcok, OBJC_ASSOCIATION_COPY_NONATOMIC);
    
    [self setStyle:UIBarButtonItemStylePlain];
    [self setTarget:self];
    [self setAction:@selector(click)];
    
    [self setTitle:content];
    
    return self;
}


/// 点击事件
- (void)click{
    UIBarButtonItemAction blockClick = objc_getAssociatedObject(self, &UIBarButtonItemActionBlock);
    if (blockClick != nil){
        __weak typeof(self) weakSelf = self;
        blockClick(weakSelf);
    }
}
























@end
