//
//  UIImage+Extension.m
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "UIImage+Extension.h"

@implementation UIImage (Extension)


/// 渐变色
+ (UIImage *)HHGradientColor:(UIColor *)startColor endColor:(UIColor *)endColor image:(UIImage *)image {
    
    // 底部上下渐变效果背景
    // 通过图片上下文设置颜色空间间
    UIGraphicsBeginImageContext(image.size);
    
    //获得当前的上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    //创建颜色空间 /* Create a DeviceRGB color space. */
    CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();
    
    //通过矩阵调整空间变换
    CGContextScaleCTM(context, image.size.width, image.size.height);
    
    // 通过颜色组件获得渐变上下文
    CGGradientRef backGradient;
    

    const CGFloat *startColor_temp = CGColorGetComponents(startColor.CGColor);
    const CGFloat *endColor_temp = CGColorGetComponents(endColor.CGColor);

    //设置颜色 矩阵
    CGFloat colors[] = {
        startColor_temp[0],startColor_temp[1],startColor_temp[2],startColor_temp[3],
        endColor_temp[0],endColor_temp[1],endColor_temp[2],endColor_temp[3],
    };
    backGradient = CGGradientCreateWithColorComponents(rgb, colors, NULL, sizeof(colors)/(sizeof(colors[0])*4));
    
    
    //释放颜色渐变
    CGColorSpaceRelease(rgb);
    //通过上下文绘画线色渐变
    CGContextDrawLinearGradient(context, backGradient, CGPointMake(0.5, 0), CGPointMake(0.5, 1), kCGGradientDrawsBeforeStartLocation);
    //通过图片上下文获得照片
    image = UIGraphicsGetImageFromCurrentImageContext();
    
    return image;
}





@end
