//
//  UIImage+Extension.h
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (Extension)

/// 渐变色
+ (UIImage *)HHGradientColor:(UIColor *)startColor endColor:(UIColor *)endColor image:(UIImage *)image;



@end

NS_ASSUME_NONNULL_END
