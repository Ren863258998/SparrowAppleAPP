//
//  UINavigationBar+Custom.h
//  SYNavigationBar
//
//  Created by syihh on 15/12/18.
//  Copyright © 2015年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (Custom)

// 背景颜色
- (void)setBackgroundColor:(UIColor *)backgroundColor;

// 设置元素透明度
- (void)setElementsAlpha:(CGFloat)alpha;

// 重置
- (void)reset;


@end
