//
//  NSDate+Extension.m
//  SFile
//
//  Created by 司月 on 2018/2/13.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "NSDate+Extension.h"

@implementation NSDate (Extension)



/// 获取文件的修改时间
- (NSString *)HHFileModifyTime {

    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    
    // 现在日期时间
    NSDate *nowDate = [NSDate date];
    
    // 判断文件时间是否是今天
    if ([[nowDate HHYears] floatValue] - [[self HHYears] floatValue] == 0 &&
        [[nowDate HHMonth] floatValue] - [[self HHMonth] floatValue] == 0) {
        
        if ([[nowDate HHDay] floatValue] - [[self HHDay] floatValue] == 0) {
            [formatter setDateFormat:@"今天 HH:mm"];
        }else if ([[nowDate HHDay] floatValue] - [[self HHDay] floatValue] == 1){
            [formatter setDateFormat:@"昨天 HH:mm"];
        }else{
            [formatter setDateFormat:@"yyyy/MM/dd"];
        }
    }else{
        [formatter setDateFormat:@"yyyy/MM/dd"];
    }
    
    return [formatter stringFromDate:self];
}






/// 年-月-日 时:分:秒
- (NSString *)HHDateTime {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss:SSS"];
    return [formatter stringFromDate:self];
}

/// 年-月-日
- (NSString *)HHDateWith:(NSString *)symbol {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:[NSString stringWithFormat:@"yyyy%@MM%@dd",symbol,symbol]];
    return [formatter stringFromDate:self];
}

/// 年
- (NSString *)HHYears {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"yyyy"];
    return [formatter stringFromDate:self];
}

/// 月
- (NSString *)HHMonth {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"MM"];
    return [formatter stringFromDate:self];
}

/// 日
- (NSString *)HHDay {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"dd"];
    return [formatter stringFromDate:self];
}

/// 时
- (NSString *)HHHour {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"HH"];
    return [formatter stringFromDate:self];
}

/// 分
- (NSString *)HHMinute {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"mm"];
    return [formatter stringFromDate:self];
}

/// 秒
- (NSString *)HHSecond {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"ss"];
    return [formatter stringFromDate:self];
}

/// 毫秒
- (NSString *)HHMillisecond {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:@"SSS"];
    return [formatter stringFromDate:self];
}





/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSString *)HHDateTime_UTC:(NSString *)str {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [formatter setDateFormat:str];
    return [formatter stringFromDate:self];
}

/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSString *)HHDateTime:(NSString *)str {
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setDateFormat:str];
    return [formatter stringFromDate:self];
}





/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
+ (NSString *)HHDateString_UTC:(NSString *)str Format:(NSString *)format {
 
    // 设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    // 设置日历获取方式 避免 佛历获取错误
    [formatter setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [formatter setDateFormat:format];
    
    NSDate *birthdayDate = [formatter dateFromString:str];
    
    return [birthdayDate HHDateTime:format];
    
}



@end
