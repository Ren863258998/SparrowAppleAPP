//
//  NSDate+Extension.h
//  SFile
//
//  Created by 司月 on 2018/2/13.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Extension)

/// 获取文件的修改时间
- (NSString *)HHFileModifyTime;



/// 年-月-日 时:分:秒
- (NSString *)HHDateTime;

/// 年-月-日
- (NSString *)HHDateWith:(NSString *)symbol;

/// 年
- (NSString *)HHYears;

/// 月
- (NSString *)HHMonth;

/// 日
- (NSString *)HHDay;

/// 时
- (NSString *)HHHour;

/// 分
- (NSString *)HHMinute;

/// 秒
- (NSString *)HHSecond;

/// 毫秒
- (NSString *)HHMillisecond;


/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSString *)HHDateTime_UTC:(NSString *)str;

/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
- (NSString *)HHDateTime:(NSString *)str;


/// 年-月-日 时:分:秒  @"yyyy-MM-dd HH:mm:ss:SSS"
+ (NSString *)HHDateString_UTC:(NSString *)str Format:(NSString *)format;






@end
