//
//  HHAlertController.h
//  SFile
//
//  Created by 司月 on 2018/3/28.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HHAlertController : UIAlertController

/// 视图将要显示
@property (nonatomic,strong)void (^viewWillAppearBlock)(BOOL animated);
/// 试图已经出现
@property (nonatomic,strong)void (^viewDidAppearBlock)(BOOL animated);
/// 试图已经消失
@property (nonatomic,strong)void (^viewDidDisappearBlock)(BOOL animated);

/// 监听当键盘将要出现时
@property (nonatomic,strong)void (^keyboardWillShowBlock)(HHAlertController *alert);
/// 监听当键盘将要消失时
@property (nonatomic,strong)void (^keyboardWillHideBlock)(HHAlertController *alert);


/// 确定按钮提示框
+ (void)HHErrorNew:(NSString *)title Message:(NSString *)message ViewController:(UIViewController *)viewController ActionBlock:(void (^)(void))actionBlock;


/// 确定按钮提示框
+ (void)HHNew:(NSString *)title Message:(NSString *)message ViewController:(UIViewController *)viewController CancelBlock:(void (^)(void))cancelBlock ActionBlock:(void (^)(void))actionBlock;




@end
