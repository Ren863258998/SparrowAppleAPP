//
//  HHAlertController.m
//  SFile
//
//  Created by 司月 on 2018/3/28.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "HHAlertController.h"
#import "AFViewShaker.h"

@interface HHAlertController ()<UITextFieldDelegate>

@end

@implementation HHAlertController

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    NSLog(@"⚠️收到内存警告_HHAlertController");
}


// 视图将要显示
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    if (self.viewWillAppearBlock) {
        self.viewWillAppearBlock(animated);
    }
}

// 试图已经出现
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    if (self.viewDidAppearBlock) {
        self.viewDidAppearBlock(animated);
    }
}

// 试图已经消失
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:YES];
    
    if (self.viewDidDisappearBlock) {
        self.viewDidDisappearBlock(animated);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    __weak typeof(self) weakSelf = self;
    
    /// 监听当键盘将要出现时
    [[NSNotificationCenter defaultCenter] addObserverForName:UIKeyboardWillShowNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        if (weakSelf.keyboardWillShowBlock) {
            weakSelf.keyboardWillShowBlock(weakSelf);
        }
    }];
    /// 监听当键盘将要消失时
    [[NSNotificationCenter defaultCenter] addObserverForName:UIKeyboardWillHideNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        if (weakSelf.keyboardWillHideBlock) {
            weakSelf.keyboardWillHideBlock(weakSelf);
        }
    }];

    
}



/// 确定按钮提示框
+ (void)HHErrorNew:(NSString *)title Message:(NSString *)message ViewController:(UIViewController *)viewController ActionBlock:(void (^)(void))actionBlock {
    
    // 在主线程更新
    dispatch_async(dispatch_get_main_queue(), ^{
        // 1.创建UIAlertController
        HHAlertController *alertController = [HHAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        // 2.1 创建按钮
        UIAlertAction *loginAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确认",@"OK") style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            if (actionBlock) {
                actionBlock();
            }
        }];
        // 2.2 添加按钮
        [alertController addAction:loginAction];
        
        // 3.显示警报控制器
        [viewController presentViewController:alertController animated:YES completion:^{
            
            // 控件抖动
            [[[AFViewShaker alloc] initWithView:alertController.view] shake];
            
            /// 添加震动反馈
            UINotificationFeedbackGenerator *generator = [[UINotificationFeedbackGenerator alloc] init];
            [generator notificationOccurred:UINotificationFeedbackTypeError];
        }];
    });

}



/// 确定按钮提示框
+ (void)HHNew:(NSString *)title Message:(NSString *)message ViewController:(UIViewController *)viewController CancelBlock:(void (^)(void))cancelBlock ActionBlock:(void (^)(void))actionBlock {
    
    // 在主线程更新
    dispatch_async(dispatch_get_main_queue(), ^{
        // 1.创建UIAlertController
        HHAlertController *alertController = [HHAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        // 2.1 创建按钮
        UIAlertAction *loginAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确认",@"OK") style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            if (actionBlock) {
                actionBlock();
            }
        }];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"取消",@"OK") style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            if (cancelBlock) {
                cancelBlock();
            }
        }];
        // 2.2 添加按钮
        [alertController addAction:cancelAction];
        [alertController addAction:loginAction];

        // 3.显示警报控制器
        [viewController presentViewController:alertController animated:YES completion:^{
            
            // 控件抖动
            [[[AFViewShaker alloc] initWithView:alertController.view] shake];
            
            /// 添加震动反馈
            UINotificationFeedbackGenerator *generator = [[UINotificationFeedbackGenerator alloc] init];
            [generator notificationOccurred:UINotificationFeedbackTypeError];
        }];
    });
    
}













- (void)dealloc {
    
    NSLog(@"✅销毁了-弹出视图");
    
    // 移除观察者，Observer不能为nil
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}









@end
