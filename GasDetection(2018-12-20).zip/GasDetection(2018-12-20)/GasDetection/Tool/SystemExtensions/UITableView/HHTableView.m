//
//  HHTableView.m
//  SFile
//
//  Created by 司月 on 2018/3/15.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "HHTableView.h"

@interface HHTableView ()


@end

@implementation HHTableView

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self Initialize];
    }
    return self;
}
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self Initialize];
    }
    return self;
}
- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    self = [super initWithFrame:frame style:style];
    if (self) {
        [self Initialize];
    }
    return self;
}


- (void)layoutSubviews {
    [super layoutSubviews];
 
}

// 初始化
- (void)Initialize {

   

}





// 销毁时
- (void)dealloc {
    NSLog(@"✅销毁了-列表视图📈");
}







@end
