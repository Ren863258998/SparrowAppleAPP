//
//  HHUserNotifications.h
//  iPlore
//
//  Created by 司月 on 2018/8/25.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UserNotifications/UserNotifications.h>


@interface HHUserNotifications : NSObject

/// 通知授权
+ (void)HHRequestAuthorizationWithOptions;

/// 创建后台通知
+ (void)HHLocalNotification:(NSString *)title Subtitle:(NSString *)subtitle Body:(NSString *)body Url:(NSURL *)url;




@end

