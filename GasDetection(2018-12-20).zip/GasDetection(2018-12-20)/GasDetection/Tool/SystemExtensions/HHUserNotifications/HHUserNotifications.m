//
//  HHUserNotifications.m
//  iPlore
//
//  Created by 司月 on 2018/8/25.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "HHUserNotifications.h"

@implementation HHUserNotifications


/// 通知授权
+ (void)HHRequestAuthorizationWithOptions {
    
    // 本地通知初始化
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert + UNAuthorizationOptionSound) completionHandler:^(BOOL granted, NSError * _Nullable error) {
        
        if (error) {
            NSLog(@"授权错误:%@",error);
        }
    }];
    
    
}


/// 创建后台通知
+ (void)HHLocalNotification:(NSString *)title Subtitle:(NSString *)subtitle Body:(NSString *)body Url:(NSURL *)url {
    
    // 1.创建通知内容
    UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc] init];
    content.title = title;
    content.subtitle = subtitle;
    content.body = body;
    content.badge = @1;
    
    
    if (url) {
        // 2.设置通知附件内容
        NSError *error = nil;
        UNNotificationAttachment *att = [UNNotificationAttachment attachmentWithIdentifier:@"att1" URL:url options:nil error:&error];
        if (error) {
            NSLog(@"附件错误:%@",error);
        }
        content.attachments = @[att];
        content.launchImageName = @"hh-icon-file-3gp";
    }
    
    
    // 3.设置声音
    UNNotificationSound *sound = [UNNotificationSound defaultSound];
    content.sound = sound;

    
    // 4.触发模式
    UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
    
    
    // 5.设置UNNotificationRequest
    NSString *requestIdentifer = @"HHLocalNotificationRequest";
    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:requestIdentifer content:content trigger:trigger];
    
    
    // 6.把通知加到UNUserNotificationCenter, 到指定触发点会被触发
    [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
        
        if(error) {
            NSLog(@"发送通知失败%@",error);
        }
    }];
}










@end
