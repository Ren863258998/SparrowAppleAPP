//
//  HHTactileFeedback.m
//  触感反馈
//
//  Created by 司月 on 2018/2/23.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "HHTactileFeedback.h"
#import <UIKit/UIKit.h>


@implementation HHTactileFeedback


/// 触感反馈 - 成功
+ (void)HHFeedbackTypeSuccess {
    UINotificationFeedbackGenerator *generator = [[UINotificationFeedbackGenerator alloc] init];
    [generator notificationOccurred:UINotificationFeedbackTypeSuccess];
}
/// 触感反馈 - 警告
+ (void)HHFeedbackTypeWarning {
    UINotificationFeedbackGenerator *generator = [[UINotificationFeedbackGenerator alloc] init];
    [generator notificationOccurred:UINotificationFeedbackTypeWarning];
}
/// 触感反馈 - 错误
+ (void)HHFeedbackTypeError {
    UINotificationFeedbackGenerator *generator = [[UINotificationFeedbackGenerator alloc] init];
    [generator notificationOccurred:UINotificationFeedbackTypeError];
}



/// 触感反馈 - 轻度
+ (void)HHFeedbackStyleLight {
    /// 添加震动反馈
    UIImpactFeedbackGenerator *generator = [[UIImpactFeedbackGenerator alloc] initWithStyle: UIImpactFeedbackStyleLight];
    // 他的作用就是让响应立刻发生，如果不调用这个方法的话，可能会发生延时，而且多次调用这个方法也没问题，他是安全的。
    [generator prepare];
    [generator impactOccurred];
}

/// 触感反馈 - 中度
+ (void)HHFeedbackStyleMedium {
    /// 添加震动反馈
    UIImpactFeedbackGenerator *generator = [[UIImpactFeedbackGenerator alloc] initWithStyle: UIImpactFeedbackStyleMedium];
    // 他的作用就是让响应立刻发生，如果不调用这个方法的话，可能会发生延时，而且多次调用这个方法也没问题，他是安全的。
    [generator prepare];
    [generator impactOccurred];
}

/// 触感反馈 - 重度
+ (void)HHFeedbackStyleHeavy {
    /// 添加震动反馈
    UIImpactFeedbackGenerator *generator = [[UIImpactFeedbackGenerator alloc] initWithStyle: UIImpactFeedbackStyleHeavy];
    // 他的作用就是让响应立刻发生，如果不调用这个方法的话，可能会发生延时，而且多次调用这个方法也没问题，他是安全的。
    [generator prepare];
    [generator impactOccurred];
}


/// 触感反馈 - 选择切换
+ (void)HHFeedbackStyleselectionChanged {
    // 添加震动反馈 选择切换
    UISelectionFeedbackGenerator *feedbackSelection = [[UISelectionFeedbackGenerator alloc] init];
    [feedbackSelection selectionChanged];
}





















@end
