//
//  HHTactileFeedback.h
//  触感反馈
//
//  Created by 司月 on 2018/2/23.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HHTactileFeedback : NSObject

/// 触感反馈 - 成功
+ (void)HHFeedbackTypeSuccess;
/// 触感反馈 - 警告
+ (void)HHFeedbackTypeWarning;
/// 触感反馈 - 错误
+ (void)HHFeedbackTypeError;


/// 触感反馈 - 轻度
+ (void)HHFeedbackStyleLight;
/// 触感反馈 - 中度
+ (void)HHFeedbackStyleMedium;
/// 触感反馈 - 重度
+ (void)HHFeedbackStyleHeavy;


/// 触感反馈 - 选择切换
+ (void)HHFeedbackStyleselectionChanged;














@end
