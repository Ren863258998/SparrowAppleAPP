//
//  UIButton+Block.h
//  SYButtonBlock
//
//  Created by syihh on 16/5/23.
//  Copyright © 2016年 syinn. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^UIButtonActionBlock)(void);

@interface UIButton (Block)


/**
 *  UIButton添加UIControlEvents事件的block
 *
 *  @param event 事件
 *  @param buttonClickEvent 代码
 *
 *  [button SYHandleClickEvent:UIControlEventTouchUpInside withClickBlock:^{
 *   // 按钮点击事件
 *
 *   }];
 */
- (void)HHHandleClickEvent:(UIControlEvents)event withClickBlock:(UIButtonActionBlock)buttonClickEvent;

@end
