//
//  UIButton+Block.m
//  SYButtonBlock
//
//  Created by syihh on 16/5/23.
//  Copyright © 2016年 syinn. All rights reserved.
//

#import "UIButton+Block.h"
#import <objc/runtime.h>

static char *UIButtonActionBlockKey;

@implementation UIButton (Block)

/**
 *  UIButton添加UIControlEvents事件的block
 *
 *  @param event 事件
 *  @param buttonClickEvent block代码
 */
- (void)HHHandleClickEvent:(UIControlEvents)event withClickBlock:(UIButtonActionBlock)buttonClickEvent{
    objc_setAssociatedObject(self, &UIButtonActionBlockKey, buttonClickEvent, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [self addTarget:self action:@selector(buttonClick) forControlEvents:event];
}

- (void)buttonClick{
    UIButtonActionBlock blockClick = objc_getAssociatedObject(self, &UIButtonActionBlockKey);
    if (blockClick != nil){
        blockClick();
    }
}



















@end
