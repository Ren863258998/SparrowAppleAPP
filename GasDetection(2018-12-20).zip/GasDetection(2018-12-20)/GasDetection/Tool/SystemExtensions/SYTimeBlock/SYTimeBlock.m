//
//  SYTimeBlock.m
//  SYTimeBlock
//
//  Created by 司月 on 2017/7/5.
//  Copyright © 2017年 司月. All rights reserved.
//

#import "SYTimeBlock.h"

@implementation SYTimeBlock


- (instancetype)init {
    
    if (self = [super init]) {
        [self Initialize];
    }
    return self;
}



// 初始化
- (void)Initialize {
    
    self.num = 0;

    
}

// 销毁定时器
- (void)invalidate {
    // 取消定时器
    [self.timer invalidate];   // 将定时器从运行循环中移除，
    self.timer = nil;          // 销毁定时器 ---》 这样可以避免控制器不死
}


/** 定时器创建并开始执行 interval时间间隔 repeats重复次数 0为一直重复 block回调 */
+ (SYTimeBlock *)SYScheduledTimerWithTimeInterval:(NSTimeInterval)interval repeats:(float)repeats block:(void (^)(SYTimeBlock *timer))block {
    
    __block SYTimeBlock *timer = [SYTimeBlock new];
    
    timer.repeats = repeats;
    
    timer.timeInterval = interval;
        
//    NSTimer *time = [NSTimer scheduledTimerWithTimeInterval:interval target:timer selector:@selector(function:) userInfo:nil repeats:YES];
//    timer.timer = time;
    
    if (block) {
        timer.Block = block;
    }

    return timer;
}




- (void)function:(NSTimer *)timer {
    
    self.num ++;
    
    __weak typeof(self) weakSelf = self;

    if (self.Block && [self.timer isEqual:timer]) {
        self.Block(weakSelf);
    }
    
    if (self.num >= self.repeats && self.repeats != 0) {
        [self invalidate]; // 停止计时器
    }
    
}


/// 计时器时间间隔
- (void)setTimeInterval:(NSTimeInterval)timeInterval {
    _timeInterval = timeInterval;
    
    // 销毁定时器
    [self invalidate];
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:self.timeInterval target:self selector:@selector(function:) userInfo:nil repeats:YES];
        self.timer = timer;

        [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
        [[NSRunLoop currentRunLoop] run];
        
        // 启动定时器
        timer.fireDate = [NSDate distantPast];
    });
    
}











- (void)dealloc{
    NSLog(@"控制器销毁");
    [self invalidate]; // 停止计时器
}










@end
