//
//  SYTimeBlock.h
//  SYTimeBlock
//
//  Created by 司月 on 2017/7/5.
//  Copyright © 2017年 司月. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SYTimeBlock : NSObject

/** 计时器 */
@property(nonatomic,strong)NSTimer *timer;

/// 计时器时间间隔
@property(nonatomic,assign)NSTimeInterval timeInterval;

/** 计时器重复次数 */
@property(nonatomic,assign)float repeats;

/** 计时器执行了多少次 */
@property(nonatomic,assign)NSInteger num;


/** block */
@property (nonatomic,strong)void (^Block)(SYTimeBlock *timer);

/** 销毁定时器 */
- (void)invalidate;

/** 定时器创建并开始执行 interval时间间隔 repeats重复次数 0为一直重复 block回调 */
+ (SYTimeBlock *)SYScheduledTimerWithTimeInterval:(NSTimeInterval)interval repeats:(float)repeats block:(void (^)(SYTimeBlock *timer))block;





@end
