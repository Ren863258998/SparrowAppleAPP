//
//  HHViewController.m
//  iPlore
//
//  Created by 司月 on 2018/4/13.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "HHViewController.h"

@interface HHViewController ()

@end

@implementation HHViewController

// 自动隐藏iPhone X 横条
- (BOOL)prefersHomeIndicatorAutoHidden {
    return self.isHomeIndicatorAutoHidden;
}

// 设置样式
- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

// 设置是否隐藏
- (BOOL)prefersStatusBarHidden {
    return self.isStatusHidden;
}

// 设置隐藏动画
- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationFade;
}


/// 是否隐藏状态栏
- (void)setIsStatusHidden:(BOOL)isStatusHidden {
    if (self.isStatusHidden == isStatusHidden) {
        return;
    }
    
    _isStatusHidden = isStatusHidden;
    
    [UIView animateWithDuration:0.4 animations:^{
        // 刷新状态栏
        [self setNeedsStatusBarAppearanceUpdate];
    }];
    
}


/// 是否隐藏home键
- (void)setIsHomeIndicatorAutoHidden:(BOOL)isHomeIndicatorAutoHidden {
    if (self.isHomeIndicatorAutoHidden == isHomeIndicatorAutoHidden) {
        return;
    }
    
    _isHomeIndicatorAutoHidden = isHomeIndicatorAutoHidden;
    
    [UIView animateWithDuration:0.4 animations:^{
        // 刷新home键状态
        [self setNeedsUpdateOfHomeIndicatorAutoHidden];
    }];
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 初始化默认一些属性
    _isStatusHidden = NO;
    
    _isHomeIndicatorAutoHidden = NO;
    
    
    // 一个布尔值，指示扩展布局是否包含不透明条。
//    self.extendedLayoutIncludesOpaqueBars = YES;
    
}


















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
