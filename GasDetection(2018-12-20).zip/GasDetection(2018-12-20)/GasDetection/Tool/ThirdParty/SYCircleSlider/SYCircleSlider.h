//
//  SYCircleSlider.h
//  SYCircleSlider
//
//  Created by syihh on 16/1/4.
//  Copyright © 2016年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

/** @name Constants */
/**
 * 风格允许循环发展的观点。
 *
 * 你可以设置和检索当前风格的进步通过progressViewStyle属性视图。
 */
typedef enum {
    UICircularSliderStyleCircle,
    UICircularSliderStylePie,
} UICircularSliderStyle;

IB_DESIGNABLE@interface SYCircleSlider : UIControl

/**
 * 接收者的当前值。
 *
 * 设置此属性会导致接收机重新绘制使用新的值。
 * 如果你想设置一个值,低于最低或超过最大值,最小值或最大值设置。这个属性的默认值是0.0。
 */
@property (nonatomic) float value;

/**
 * 接收方的最小值。
 *
 * 如果你改变这个属性的值,接收方的当前值低于最低,当前值自动调整以匹配新的最小值。
 * 这个属性的默认值是0.0。
 */
@property (nonatomic) float minimumValue;

/**
 * 接收方的最大价值。
 *
 * 如果你改变这个属性的值,接收方的当前值高于新最大,当前值自动调整以匹配新的最大值。
 * 这个属性的默认值是1.0。
 */
@property (nonatomic) float maximumValue;

/**
 * 显示的颜色填充的部分的滑动条。
 */
@property(nonatomic, retain) UIColor *minimumTrackTintColor;

/**
 * 的滑块部分的颜色显示不了。
 */
@property(nonatomic, retain) UIColor *maximumTrackTintColor;

/**
 * 颜色用于色彩标准的拇指。
 */
@property(nonatomic, retain) UIColor *thumbTintColor;

/**
 * Contains a Boolean value indicating whether changes in the sliders value generate continuous update events.
 *
 * If YES, the slider sends update events continuously to the associated target’s action method.
 * If NO, the slider only sends an action event when the user releases the slider’s thumb control to set the final value.
 * The default value of this property is YES.
 *
 * @warning Not implemented Yet.
 */
@property(nonatomic, getter=isContinuous) BOOL continuous;

/**
 * The current graphical style of the receiver.
 *
 * The value of this property is a constant that specifies the style of the slider.
 The default style is UICircularSliderStyleCircle.
 * For more on these constants, see UICircularSliderStyle.
 */
@property (nonatomic) UICircularSliderStyle sliderStyle;

@end


/** @name Utility Functions */
#pragma mark - Utility Functions
/**
 * Translate a value in a source interval to a destination interval
 * @param sourceValue					The source value to translate
 * @param sourceIntervalMinimum			The minimum value in the source interval
 * @param sourceIntervalMaximum			The maximum value in the source interval
 * @param destinationIntervalMinimum	The minimum value in the destination interval
 * @param destinationIntervalMaximum	The maximum value in the destination interval
 * @return	The value in the destination interval
 *
 * This function uses the linear function method, a.k.a. resolves the y=ax+b equation where y is a destination value and x a source value
 * Formulas :	a = (dMax - dMin) / (sMax - sMin)
 *				b = dMax - a*sMax = dMin - a*sMin
 */
float translateValueFromSourceIntervalToDestinationInterval(float sourceValue, float sourceIntervalMinimum, float sourceIntervalMaximum, float destinationIntervalMinimum, float destinationIntervalMaximum);
/**
 * Returns the smallest angle between three points, one of them clearly indicated as the "junction point" or "center point".
 * @param centerPoint	The "center point" or "junction point"
 * @param p1			The first point, member of the [centerPoint p1] segment
 * @param p2			The second point, member of the [centerPoint p2] segment
 * @return				The angle between those two segments
 
 * This function uses the properties of the triangle and arctan (atan2f) function to calculate the angle.
 */
CGFloat angleBetweenThreePoints(CGPoint centerPoint, CGPoint p1, CGPoint p2);
