//
//  SYCountingTextField.h
//  huagan
//
//  Created by syihh on 16/9/6.
//  Copyright © 2016年 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, UITextFieldCountingMethod) {
    UITextFieldCountingMethodEaseInOut,
    UITextFieldCountingMethodEaseIn,
    UITextFieldCountingMethodEaseOut,
    UITextFieldCountingMethodLinear
};

typedef NSString* (^UICountingTextFieldFormatBlock)(CGFloat value);
typedef NSAttributedString* (^UICountingTextFieldAttributedFormatBlock)(CGFloat value);

@interface SYCountingTextField : UITextField

@property (nonatomic, strong) NSString *format;
@property (nonatomic, assign) UITextFieldCountingMethod method;
@property (nonatomic, assign) NSTimeInterval animationDuration;

@property (nonatomic, copy) UICountingTextFieldFormatBlock formatBlock;
@property (nonatomic, copy) UICountingTextFieldAttributedFormatBlock attributedFormatBlock;
@property (nonatomic, copy) void (^completionBlock)(void);

-(void)countFrom:(CGFloat)startValue to:(CGFloat)endValue;
-(void)countFrom:(CGFloat)startValue to:(CGFloat)endValue withDuration:(NSTimeInterval)duration;

-(void)countFromCurrentValueTo:(CGFloat)endValue;
-(void)countFromCurrentValueTo:(CGFloat)endValue withDuration:(NSTimeInterval)duration;

-(void)countFromZeroTo:(CGFloat)endValue;
-(void)countFromZeroTo:(CGFloat)endValue withDuration:(NSTimeInterval)duration;

- (CGFloat)currentValue;

@end
