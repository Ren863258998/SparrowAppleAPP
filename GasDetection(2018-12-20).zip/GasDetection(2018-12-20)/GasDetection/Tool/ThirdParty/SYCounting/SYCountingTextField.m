//
//  SYCountingTextField.m
//  huagan
//
//  Created by syihh on 16/9/6.
//  Copyright © 2016年 syihh. All rights reserved.
//

#import "SYCountingTextField.h"

#if !__has_feature(objc_arc)
#error UICountingTextField is ARC only. Either turn on ARC for the project or use -fobjc-arc flag
#endif

#pragma mark - UITextFieldCounter

#ifndef kUITextFieldCounterRate
#define kUITextFieldCounterRate 3.0
#endif

@protocol SYCountingTextField<NSObject>

-(CGFloat)update:(CGFloat)t;

@end

@interface UITextFieldCounterLinear : NSObject<SYCountingTextField>

@end

@interface UITextFieldCounterEaseIn : NSObject<SYCountingTextField>

@end

@interface UITextFieldCounterEaseOut : NSObject<SYCountingTextField>

@end

@interface UITextFieldCounterEaseInOut : NSObject<SYCountingTextField>

@end

@implementation UITextFieldCounterLinear

-(CGFloat)update:(CGFloat)t
{
    return t;
}

@end

@implementation UITextFieldCounterEaseIn

-(CGFloat)update:(CGFloat)t
{
    return powf(t, kUITextFieldCounterRate);
}

@end

@implementation UITextFieldCounterEaseOut

-(CGFloat)update:(CGFloat)t{
    return 1.0-powf((1.0-t), kUITextFieldCounterRate);
}

@end

@implementation UITextFieldCounterEaseInOut

-(CGFloat) update: (CGFloat) t
{
    int sign =1;
    int r = (int) kUITextFieldCounterRate;
    if (r % 2 == 0)
        sign = -1;
    t *= 2;
    if (t < 1)
        return 0.5f * powf(t, kUITextFieldCounterRate);
    else
        return sign * 0.5f * (powf(t-2, kUITextFieldCounterRate) + sign * 2);
}

@end

#pragma mark - SYCountingTextField

@interface SYCountingTextField ()

@property CGFloat startingValue;
@property CGFloat destinationValue;
@property NSTimeInterval progress;
@property NSTimeInterval lastUpdate;
@property NSTimeInterval totalTime;
@property CGFloat easingRate;

@property (nonatomic, weak) NSTimer *timer;
@property (nonatomic, strong) id<SYCountingTextField> counter;

@end


@implementation SYCountingTextField

-(void)countFrom:(CGFloat)value to:(CGFloat)endValue {
    
    if (self.animationDuration == 0.0f) {
        self.animationDuration = 2.0f;
    }
    
    [self countFrom:value to:endValue withDuration:self.animationDuration];
}

-(void)countFrom:(CGFloat)startValue to:(CGFloat)endValue withDuration:(NSTimeInterval)duration {
    
    self.startingValue = startValue;
    self.destinationValue = endValue;
    
    // 删除任何旧定时器(可能)
    [self.timer invalidate];
    self.timer = nil;
    
    if (duration == 0.0) {
        // 没有动画
        [self setTextValue:endValue];
        [self runCompletionBlock];
        return;
    }
    
    self.easingRate = 3.0f;
    self.progress = 0;
    self.totalTime = duration;
    self.lastUpdate = [NSDate timeIntervalSinceReferenceDate];
    
    if(self.format == nil)
        self.format = @"%f";
    
    switch(self.method)
    {
        case UITextFieldCountingMethodLinear:
            self.counter = [[UITextFieldCounterLinear alloc] init];
            break;
        case UITextFieldCountingMethodEaseIn:
            self.counter = [[UITextFieldCounterEaseIn alloc] init];
            break;
        case UITextFieldCountingMethodEaseOut:
            self.counter = [[UITextFieldCounterEaseOut alloc] init];
            break;
        case UITextFieldCountingMethodEaseInOut:
            self.counter = [[UITextFieldCounterEaseInOut alloc] init];
            break;
    }
    
    NSTimer *timer = [NSTimer timerWithTimeInterval:(1.0f/30.0f) target:self selector:@selector(updateValue:) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:UITrackingRunLoopMode];
    self.timer = timer;
}

- (void)countFromCurrentValueTo:(CGFloat)endValue {
    [self countFrom:[self currentValue] to:endValue];
}

- (void)countFromCurrentValueTo:(CGFloat)endValue withDuration:(NSTimeInterval)duration {
    [self countFrom:[self currentValue] to:endValue withDuration:duration];
}

- (void)countFromZeroTo:(CGFloat)endValue {
    [self countFrom:0.0f to:endValue];
}

- (void)countFromZeroTo:(CGFloat)endValue withDuration:(NSTimeInterval)duration {
    [self countFrom:0.0f to:endValue withDuration:duration];
}

- (void)updateValue:(NSTimer *)timer {
    
    // 更新的进展
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    self.progress += now - self.lastUpdate;
    self.lastUpdate = now;
    
    if (self.progress >= self.totalTime) {
        [self.timer invalidate];
        self.timer = nil;
        self.progress = self.totalTime;
    }
    
    [self setTextValue:[self currentValue]];
    
    if (self.progress == self.totalTime) {
        [self runCompletionBlock];
    }
}

- (void)setTextValue:(CGFloat)value
{
    if (self.attributedFormatBlock != nil) {
        self.attributedText = self.attributedFormatBlock(value);
    }
    else if(self.formatBlock != nil)
    {
        self.text = self.formatBlock(value);
    }
    else
    {
        // 检查是否与整数计算 - cast to int
        if([self.format rangeOfString:@"%(.*)d" options:NSRegularExpressionSearch].location != NSNotFound || [self.format rangeOfString:@"%(.*)i"].location != NSNotFound )
        {
            self.text = [NSString stringWithFormat:self.format,(int)value];
        }
        else
        {
            self.text = [NSString stringWithFormat:self.format,value];
        }
    }
}

- (void)setFormat:(NSString *)format {
    _format = format;
    // 更新标签的新格式
    [self setTextValue:self.currentValue];
}

- (void)runCompletionBlock {
    
    if (self.completionBlock) {
        self.completionBlock();
        self.completionBlock = nil;
    }
}

- (CGFloat)currentValue {
    
    if (self.progress >= self.totalTime) {
        return self.destinationValue;
    }
    
    CGFloat percent = self.progress / self.totalTime;
    CGFloat updateVal = [self.counter update:percent];
    return self.startingValue + (updateVal * (self.destinationValue - self.startingValue));
}

@end
