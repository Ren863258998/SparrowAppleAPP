//
//  HHLocationInformation.h
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//


// 描述文件中添加权限
// NSLocationWhenInUseUsageDescription
// NSLocationAlwaysUsageDescription

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHLocationInformation : NSObject

/// 提供快速创建方法
+ (instancetype)shared;

/// 开始定位
- (void)HHStartLocation;




/// 地址
@property(nonatomic,strong,readonly)NSString *locationAddress;
/// 经度
@property(nonatomic,strong,readonly)NSString *longitude;
/// 纬度
@property(nonatomic,strong,readonly)NSString *latitude;
/// 高度
@property(nonatomic,strong,readonly)NSString *altitude;
/// 速度
@property(nonatomic,strong,readonly)NSString *speed;


/// 城市
@property(nonatomic,strong,readonly)NSString *city;


/// 天气信息
@property(nonatomic,strong,readonly)NSString *weather;





@end



NS_ASSUME_NONNULL_END
