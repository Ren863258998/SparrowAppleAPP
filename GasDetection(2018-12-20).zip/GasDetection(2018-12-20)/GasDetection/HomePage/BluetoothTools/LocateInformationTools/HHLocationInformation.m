//
//  HHLocationInformation.m
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHLocationInformation.h"
#import <CoreLocation/CoreLocation.h> // 定位库
#import "HHWeatherTool.h"

@interface HHLocationInformation ()<CLLocationManagerDelegate>

/// 位置管理器
@property (nonatomic, strong) CLLocationManager *locationManager;

/// 地址
@property(nonatomic,strong)NSString *locationAddress;
/// 经度
@property(nonatomic,strong)NSString *longitude;
/// 纬度
@property(nonatomic,strong)NSString *latitude;
/// 高度
@property(nonatomic,strong)NSString *altitude;
/// 速度
@property(nonatomic,strong)NSString *speed;

/// 城市
@property(nonatomic,strong)NSString *city;

/// 天气信息
@property(nonatomic,strong)NSString *weather;

@end

@implementation HHLocationInformation

//用来保存唯一的单例对象
static HHLocationInformation *_instance;

+ (instancetype)shared {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance;
}

+ (id)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

- (id)copyWithZone:(NSZone *)zone {
    return _instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize {
    
    /// 地址
    _locationAddress = @"--";
    /// 经度
    _longitude = @"--";
    /// 纬度
    _latitude = @"--";
    /// 高度
    _altitude = @"--";
    /// 速度
    _speed = @"--";

    /// 城市
    _city = @"--";
    
    /// 天气信息
    _weather = @"--";
    
    /// 开始定位
    [self HHStartLocation];

}

/// 开始定位
- (void)HHStartLocation {
    
    if ([CLLocationManager locationServicesEnabled]) {
        NSLog(@"开始定位");
        self.locationManager = [[CLLocationManager alloc]init];
        self.locationManager.delegate = self;
        // 控制定位精度,越高耗电量越
        self.locationManager.desiredAccuracy = kCLLocationAccuracyKilometer;
        // 总是授权
        [self.locationManager requestAlwaysAuthorization];
        self.locationManager.distanceFilter = 10.0f;
        [self.locationManager requestAlwaysAuthorization];
        [self.locationManager startUpdatingLocation];
    }
}


/// 定位失败
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    if ([error code] == kCLErrorDenied) {
        NSLog(@"访问被拒绝");
    }
    if ([error code] == kCLErrorLocationUnknown) {
        NSLog(@"无法获取位置信息");
    }
    if (error) {
        NSLog(@"%@",error);
    }
}

/// 定位代理经纬度回调
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    
    __weak typeof(self) weakSelf = self;

    // 获取位置信息
    CLLocation *newLocation = [locations firstObject];
    
    /// 经度
    self.longitude = [NSString stringWithFormat:@"%f",newLocation.coordinate.longitude];
    /// 纬度
    self.latitude  = [NSString stringWithFormat:@"%f",newLocation.coordinate.latitude];
    /// 高度
    self.altitude  = [NSString stringWithFormat:@"%f",newLocation.altitude];
    /// 速度
    self.speed     = [NSString stringWithFormat:@"%f",newLocation.speed];
    
    // 根据经纬度反向地理编译出地址信息
    [[[CLGeocoder alloc] init] reverseGeocodeLocation:newLocation completionHandler:^(NSArray *array, NSError *error){
        
        // 判断是否错误
        if (error || array.count == 0) {
            NSLog(@"发生一个错误:%@", error);
            return ;
        }
        
        NSLog(@"定位成功");
        
        /// 更新天气信息
        [[HHWeatherTool shared] HHReloadWith:self.longitude Latitude:self.latitude];
        
        // 获取地标
        CLPlacemark *placemark = [array firstObject];

        /// 地址
        weakSelf.locationAddress = [NSString stringWithFormat:@"%@",placemark];

        // 获取城市
        NSString *city = placemark.locality;
        
        if (!city) {
            //四大直辖市的城市信息无法通过locality获得，只能通过获取省份的方法来获得（如果city为空，则可知为直辖市）
            city = placemark.administrativeArea;
        }
        
//        NSLog(@"城市 = %@", city);
        weakSelf.city = city;
        
    }];


    // 系统会一直更新数据，直到选择停止更新，因为我们只需要获得一次经纬度即可，所以获取之后就停止更新
//    [manager stopUpdatingLocation];
    
    

}


/// 获取到城市信息时获取天气
- (void)setCity:(NSString *)city {
    _city = city;
    
    
    
    
}



@end
