//
//  HHHardwareModel.h
//  GasDetection
//
//  Created by 司月 on 2018/11/4.
//  Copyright © 2018 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HHBluetoothModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHHardwareModel : NSObject

/// 设备名称
@property(nonatomic,strong)NSString *name;

/// 设备UDID
@property(nonatomic,strong)NSString *udid;

/// 版本号 <0100>
@property(nonatomic,strong,readonly)NSString *version;

/// CO的传感器敏感系数 <000010ea 000010ea>
@property(nonatomic,strong,readonly)NSString *CO_SC;

/// O3的传感器敏感系数 <fffee54e fffee54e>
@property(nonatomic,strong,readonly)NSString *O3_SC;

/// 硬件中储存的历史数据数量 <1cb0>
@property(nonatomic,strong,readonly)NSString *history_count;


/// 初始化
+ (HHHardwareModel *)HHNew:(NSArray *)array;



@end

NS_ASSUME_NONNULL_END
















