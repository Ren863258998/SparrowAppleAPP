//
//  HHHardwareModel.m
//  GasDetection
//
//  Created by 司月 on 2018/11/4.
//  Copyright © 2018 syihh. All rights reserved.
//

#import "HHHardwareModel.h"

@interface HHHardwareModel ()

typedef union {
    uint8_t data[4];
    int32_t u32;
}u32_t;

typedef union {
    uint8_t data[1];
    int32_t u32;
}u8_t;

/// 版本号 <0100>
@property(nonatomic,strong)NSString *version_temp;

/// CO的传感器敏感系数 <000010ea 000010ea>
@property(nonatomic,strong)NSString *CO_SC_temp;

/// O3的传感器敏感系数 <fffee54e fffee54e>
@property(nonatomic,strong)NSString *O3_SC_temp;

/// 硬件中储存的历史数据数量 <1cb0>
@property(nonatomic,strong)NSString *history_count_temp;


/// 版本号 <0100>
@property(nonatomic,strong)NSString *version;

/// CO的传感器敏感系数 <000010ea 000010ea>
@property(nonatomic,strong)NSString *CO_SC;

/// O3的传感器敏感系数 <fffee54e fffee54e>
@property(nonatomic,strong)NSString *O3_SC;

/// 硬件中储存的历史数据数量 <1cb0>
@property(nonatomic,strong)NSString *history_count;


@end

@implementation HHHardwareModel

/// 初始化
+ (HHHardwareModel *)HHNew:(NSArray *)array {
    
    /// 创建
    HHHardwareModel *hardwareModel = [HHHardwareModel new];
    
    hardwareModel.version_temp = [HHHardwareModel HHCoverFromDataToHexStr:array[0]];
    hardwareModel.CO_SC_temp = [HHHardwareModel HHCoverFromDataToHexStr:array[1]];
    hardwareModel.O3_SC_temp = [HHHardwareModel HHCoverFromDataToHexStr:array[2]];
    hardwareModel.history_count_temp = [HHHardwareModel HHCoverFromDataToHexStr:array[3]];

    return hardwareModel;
    
}


/// 版本号
- (void)setVersion_temp:(NSString *)version_temp {
    _version_temp = version_temp;
    
    if (version_temp.length < 2) {
        self.version_temp = @"0.00";
        return;
    }
    
    self.version = [NSString stringWithFormat:@"%.0f",[HHBluetoothModel HHFloatHexString:version_temp]];
}


- (void)setCO_SC_temp:(NSString *)CO_SC_temp {
    _CO_SC_temp = CO_SC_temp;
    
    if (CO_SC_temp.length < 8) {
        self.CO_SC_temp = @"0.00";
        return;
    }
    
    u32_t num;
    
    NSString *str0 = [CO_SC_temp substringWithRange:NSMakeRange(0,2)];
    NSString *str1 = [CO_SC_temp substringWithRange:NSMakeRange(2,2)];
    NSString *str2 = [CO_SC_temp substringWithRange:NSMakeRange(4,2)];
    NSString *str3 = [CO_SC_temp substringWithRange:NSMakeRange(6,2)];
    
    num.data[3] = strtoul([str0 UTF8String],0,16);
    num.data[2] = strtoul([str1 UTF8String],0,16);
    num.data[1] = strtoul([str2 UTF8String],0,16);
    num.data[0] = strtoul([str3 UTF8String],0,16);
        
    self.CO_SC = [NSString stringWithFormat:@"%d",num.u32];
    
}


- (void)setO3_SC_temp:(NSString *)O3_SC_temp {
    _O3_SC_temp = O3_SC_temp;
    
    if (O3_SC_temp.length < 8) {
        self.O3_SC_temp = @"0.00";
        return;
    }
    
    u32_t num;
    
    NSString *str0 = [O3_SC_temp substringWithRange:NSMakeRange(0,2)];
    NSString *str1 = [O3_SC_temp substringWithRange:NSMakeRange(2,2)];
    NSString *str2 = [O3_SC_temp substringWithRange:NSMakeRange(4,2)];
    NSString *str3 = [O3_SC_temp substringWithRange:NSMakeRange(6,2)];
    
    num.data[3] = strtoul([str0 UTF8String],0,16);
    num.data[2] = strtoul([str1 UTF8String],0,16);
    num.data[1] = strtoul([str2 UTF8String],0,16);
    num.data[0] = strtoul([str3 UTF8String],0,16);
    
    self.O3_SC = [NSString stringWithFormat:@"%d",num.u32];
    
}



- (void)setHistory_count_temp:(NSString *)history_count_temp {
    _history_count_temp = history_count_temp;
    
    if (history_count_temp.length < 2) {
        self.history_count_temp = @"0.00";
        return;
    }
    
    self.history_count = [NSString stringWithFormat:@"%.0f",[HHBluetoothModel HHFloatHexString:history_count_temp]];
}



/// 将 NSData 转化为 16进制字符串
+ (NSString *)HHCoverFromDataToHexStr:(NSData *)data {
    
    /// 格式转换char
    const unsigned char *dataBuffer = (const unsigned char *)[data bytes];
    
    NSUInteger dataLength = [data length];
    
    NSMutableString *hexString = [NSMutableString stringWithCapacity:(dataLength * 2)];
    
    for(int i = 0; i < dataLength; i++){
        
        [hexString appendString:[NSString stringWithFormat:@"%02lx", (unsigned long)dataBuffer[i]]];
        
    }
    
    return [NSString stringWithString:hexString];
    
}


@end
