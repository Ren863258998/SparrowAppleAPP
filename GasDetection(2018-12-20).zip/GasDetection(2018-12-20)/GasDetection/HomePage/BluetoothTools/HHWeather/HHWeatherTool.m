//
//  HHWeatherTool.m
//  HHWeather
//
//  Created by 司月 on 2018/10/11.
//  Copyright © 2018 syihh. All rights reserved.
//

#import "HHWeatherTool.h"

@interface HHWeatherTool ()

/// 经度
@property(nonatomic,strong)NSString *longitude;
/// 纬度
@property(nonatomic,strong)NSString *latitude;

@end

@implementation HHWeatherTool


//用来保存唯一的单例对象
static HHWeatherTool *_instance;

+ (instancetype)shared {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance;
}

+ (id)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

- (id)copyWithZone:(NSZone *)zone {
    return _instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize {
    
//    self.weather = @"--";
    
}




/// 更新天气 根据取经度纬度
- (void)HHReloadWith:(NSString *)longitude Latitude:(NSString *)latitude {
    
    if (longitude.length <= 0 || latitude.length <= 0 || self.weather.length > 0) {
        return;
    }
    
    self.weather = @"--";
    
    NSString *appcode = @"ae111aede2714d8fb9d0abebb4272919";
    NSString *host = @"http://mojibasic.market.alicloudapi.com";
    NSString *path = @"/whapi/json/aliweather/briefcondition";
    NSString *method = @"POST";
    NSString *querys = @"";
    NSString *url = [NSString stringWithFormat:@"%@%@%@",  host,  path , querys];
    NSString *bodys = [NSString stringWithFormat:@"lat=%@&lon=%@&token=a231972c3e7ba6b33d8ec71fd4774f5e",latitude,longitude];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString: url]  cachePolicy:1  timeoutInterval:  5];
    request.HTTPMethod  =  method;
    [request addValue:  [NSString  stringWithFormat:@"APPCODE %@" ,  appcode]  forHTTPHeaderField:  @"Authorization"];
    [request addValue: @"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField: @"Content-Type"];
    NSData *data = [bodys dataUsingEncoding: NSUTF8StringEncoding];
    [request setHTTPBody: data];
    NSURLSession *requestSession = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURLSessionDataTask *task = [requestSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable body , NSURLResponse * _Nullable response, NSError * _Nullable error) {
//        NSLog(@"Response object: %@" , response);
        
//        NSString *bodyString = [[NSString alloc] initWithData:body encoding:NSUTF8StringEncoding];
        
        // 打印应答中的body
//        NSLog(@"天气信息: %@" , bodyString);
        
        if (!body) {return;}
        
        // 方法2：NSJSONSerialization
        NSDictionary *dictFromData = [NSJSONSerialization JSONObjectWithData:body options:NSJSONReadingAllowFragments error:nil];
        
        NSLog(@"天气信息: %@" , dictFromData[@"data"][@"condition"][@"temp"]);
        
        self.weather = dictFromData[@"data"][@"condition"][@"temp"];
//        self.weather = [NSString stringWithFormat:@"%@℃", dictFromData[@"data"][@"condition"][@"temp"]];

    }];
    
    [task resume];

}









@end
