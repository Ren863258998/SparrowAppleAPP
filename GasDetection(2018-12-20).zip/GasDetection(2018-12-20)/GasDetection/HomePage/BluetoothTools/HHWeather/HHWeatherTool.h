//
//  HHWeatherTool.h
//  HHWeather
//
//  Created by 司月 on 2018/10/11.
//  Copyright © 2018 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHWeatherTool : NSObject

/// 天气信息
@property(nonatomic,strong)NSString *weather;


/// 提供快速创建方法
+ (instancetype)shared;



/// 更新天气 根据取经度纬度
- (void)HHReloadWith:(NSString *)longitude Latitude:(NSString *)latitude;








@end

NS_ASSUME_NONNULL_END
