//
//  HHBluetoothModel.m
//  GasDetection
//
//  Created by 司月 on 2018/8/17.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHBluetoothModel.h"
#import "HHLocationInformation.h"
#import "HHWeatherTool.h"

@interface HHBluetoothModel ()

typedef union {
    uint8_t data[4];
    int32_t u32;
}u32_t;



/// 传感器1:ffeb9d00
@property(nonatomic,strong)NSString *sensor1;
/// 传感器2:00000000
@property(nonatomic,strong)NSString *sensor2;
/// 温度:0ab6  2742  27.42℃
@property(nonatomic,strong)NSString *temperature;
/// 湿度:1b2c
@property(nonatomic,strong)NSString *humidity;
/// 压力:0188a3
@property(nonatomic,strong)NSString *pressure;
/// 电池电压:23
@property(nonatomic,strong)NSString *batteryVoltage;





/// 记录时间
@property(nonatomic,strong)NSDate *recordingTime;
/// 记录设备UUID
@property(nonatomic,strong)NSString *identifier;
/// 记录服务UUID
@property(nonatomic,strong)NSString *service_uuid;
/// 记录原始数据
@property(nonatomic,strong)NSString *originalData;



/// 传感器1
//@property(nonatomic,assign)CGFloat sensor1_float;
/// 传感器2
@property(nonatomic,assign)CGFloat sensor2_float;
/// 温度
@property(nonatomic,assign)CGFloat temperature_float;
/// 湿度
@property(nonatomic,assign)CGFloat humidity_float;
/// 压力
@property(nonatomic,assign)CGFloat pressure_float;
/// 电池电压
@property(nonatomic,assign)CGFloat batteryVoltage_float;


@end

@implementation HHBluetoothModel

/// 产生随机数区间
- (int)SYRandomNumber:(int)from to:(int)to {
    return (int)(from + (arc4random() % (to - from + 1)));
}

/// 初始化
+ (HHBluetoothModel *)HHNew_test {
    
    /// 创建
    HHBluetoothModel *bluetoothModel = [HHBluetoothModel new];
    
    /// 服务特征
//    bluetoothModel.characteristic = nil;
    /// 记录时间
    bluetoothModel.recordingTime = [NSDate date];
    /// 记录设备UUID
    bluetoothModel.identifier = @"2236871";
    /// 记录服务UUID
    bluetoothModel.service_uuid = @"2236871";
    /// 记录位置地址
    bluetoothModel.locationAddress = [[HHLocationInformation shared] locationAddress];
    /// 记录原始数据
    bluetoothModel.originalData = nil;
    
    
    NSInteger num = [bluetoothModel SYRandomNumber:0 to:2000];
    
    NSInteger num1 = [bluetoothModel SYRandomNumber:0 to:100];

    NSInteger num2 = [bluetoothModel SYRandomNumber:38 to:42];

    /// 传感器1
    bluetoothModel.sensor1_float = num;
    /// 传感器2
    bluetoothModel.sensor2_float = num;
    /// 温度
    bluetoothModel.temperature_float = num1;
    /// 湿度
    bluetoothModel.humidity_float = num1;
    /// 压力
    bluetoothModel.pressure_float = num1;
    /// 电池电压
    bluetoothModel.batteryVoltage_float = num2*1.0 / 10;
    
    
    /// 天气信息
    bluetoothModel.weather = [[HHWeatherTool shared] weather];
    
    
    
    return bluetoothModel;
    
}


/// 初始化
+ (HHBluetoothModel *)HHNew:(CBCharacteristic *)characteristic {
    
    /// 创建
    HHBluetoothModel *bluetoothModel = [HHBluetoothModel new];
    
    bluetoothModel.characteristic = characteristic;
    
    /// 记录时间
    bluetoothModel.recordingTime = [NSDate date];
    
    /// 记录位置地址
    bluetoothModel.locationAddress = [[HHLocationInformation shared] locationAddress];
    
    // 记录原始数据
    NSString *originalData = [HHBluetoothModel HHCoverFromDataToHexStr:characteristic.value];
    bluetoothModel.originalData = originalData;
    
    // 截取字符串从0开始  截取长度8位 传感器1:ffeb9d00
    NSString *sensor1 = [originalData substringWithRange:NSMakeRange(0,8)];
    bluetoothModel.sensor1 = sensor1;
    
    // 截取字符串从8开始  截取长度8位 传感器2:00000000
    NSString *sensor2 = [originalData substringWithRange:NSMakeRange(8,8)];
    bluetoothModel.sensor2 = sensor2;
    
    // 截取字符串从16开始 截取长度4位 温度:0ab6  2742  27.42℃
    NSString *temperature = [originalData substringWithRange:NSMakeRange(16,4)];
    bluetoothModel.temperature = temperature;
    
    // 截取字符串从20开始 截取长度4位 湿度:1b2c
    NSString *humidity = [originalData substringWithRange:NSMakeRange(20,4)];
    bluetoothModel.humidity = humidity;
    
    // 截取字符串从24开始 截取长度4位 压力:0188a3
    NSString *pressure = [originalData substringWithRange:NSMakeRange(24,6)];
    bluetoothModel.pressure = pressure;
    
    // 截取字符串从28开始 截取长度2位 电池电压:23
    NSString *batteryVoltage = [originalData substringWithRange:NSMakeRange(30,2)];
    bluetoothModel.batteryVoltage = batteryVoltage;
    
    
    /// 天气信息
    bluetoothModel.weather = [[HHWeatherTool shared] weather];
    
    return bluetoothModel;

}

/// 初始化
+ (HHBluetoothModel *)HHNew_L:(CBCharacteristic *)characteristic time:(NSDate *)recordingTime {
    
    /// 创建
    HHBluetoothModel *bluetoothModel = [HHBluetoothModel new];
    
    bluetoothModel.characteristic = characteristic;
    
    /// 记录时间
    bluetoothModel.recordingTime = recordingTime;
    
    // 记录原始数据
    NSString *originalData = [HHBluetoothModel HHCoverFromDataToHexStr:characteristic.value];
    bluetoothModel.originalData = originalData;
    
    // 截取字符串从0开始  截取长度8位 传感器1:ffeb9d00
    NSString *sensor1 = [originalData substringWithRange:NSMakeRange(0,8)];
    bluetoothModel.sensor1 = sensor1;
    
    // 截取字符串从8开始  截取长度8位 传感器2:00000000
    NSString *sensor2 = [originalData substringWithRange:NSMakeRange(8,8)];
    bluetoothModel.sensor2 = sensor2;
    
    // 截取字符串从16开始 截取长度4位 温度:0ab6  2742  27.42℃
    NSString *temperature = [originalData substringWithRange:NSMakeRange(16,4)];
    bluetoothModel.temperature = temperature;
    
    // 截取字符串从20开始 截取长度4位 湿度:1b2c
    NSString *humidity = [originalData substringWithRange:NSMakeRange(20,4)];
    bluetoothModel.humidity = humidity;
    
    return bluetoothModel;
    
}


/// 特征值赋值
- (void)setCharacteristic:(CBCharacteristic *)characteristic {
    _characteristic = characteristic;
    
}


/// 记录原始数据
- (void)setOriginalData:(NSString *)originalData {
    _originalData = originalData;
    
    /// 记录设备UUID
    self.identifier = [[[[HHBluetoothManager shared] peripheral] identifier] UUIDString];
    
    /// 记录服务UUID
    self.service_uuid = self.characteristic.UUID.UUIDString;
    
}

/// 传感器1:ffeb9d00
- (void)setSensor1:(NSString *)sensor1 {
    _sensor1 = sensor1;
    
    if (sensor1.length < 8) {
        self.sensor1_float = 0.00;
        return;
    }
    
    u32_t num;
    
    NSString *str0 = [sensor1 substringWithRange:NSMakeRange(0,2)];
    NSString *str1 = [sensor1 substringWithRange:NSMakeRange(2,2)];
    NSString *str2 = [sensor1 substringWithRange:NSMakeRange(4,2)];
    NSString *str3 = [sensor1 substringWithRange:NSMakeRange(6,2)];

    
    num.data[3] = strtoul([str0 UTF8String],0,16);
    num.data[2] = strtoul([str1 UTF8String],0,16);
    num.data[1] = strtoul([str2 UTF8String],0,16);
    num.data[0] = strtoul([str3 UTF8String],0,16);


    if (num.u32 / 1000.0 < 0) {
        self.sensor1_float = 0.00;
        return;
    }
    self.sensor1_float = num.u32 / 1000.0;

}

/// 传感器2:00000000
- (void)setSensor2:(NSString *)sensor2 {
    _sensor2 = sensor2;
    
    if (sensor2.length < 8) {
        self.sensor2_float = 0.00;
        return;
    }
    
    u32_t num;
    
    NSString *str0 = [sensor2 substringWithRange:NSMakeRange(0,2)];
    NSString *str1 = [sensor2 substringWithRange:NSMakeRange(2,2)];
    NSString *str2 = [sensor2 substringWithRange:NSMakeRange(4,2)];
    NSString *str3 = [sensor2 substringWithRange:NSMakeRange(6,2)];
    
    
    num.data[3] = strtoul([str0 UTF8String],0,16);
    num.data[2] = strtoul([str1 UTF8String],0,16);
    num.data[1] = strtoul([str2 UTF8String],0,16);
    num.data[0] = strtoul([str3 UTF8String],0,16);
    
    
    if (num.u32 / 1000.0 < 0) {
        self.sensor2_float = 0.00;
        return;
    }
    self.sensor2_float = num.u32 / 1000.0;

}

/// 温度:0ab6  2742  27.42℃
- (void)setTemperature:(NSString *)temperature {
    _temperature = temperature;
    
    /// 16进制转10进制
    self.temperature_float = [HHBluetoothModel HHFloatHexString:temperature] / 100.0;
}

/// 湿度:1b2c
- (void)setHumidity:(NSString *)humidity {
    _humidity = humidity;
    
    /// 16进制转10进制
    self.humidity_float = [HHBluetoothModel HHFloatHexString:humidity] / 100.0;
}

/// 压力:0188a3
- (void)setPressure:(NSString *)pressure {
    _pressure = pressure;
    
    /// 16进制转10进制
    self.pressure_float = [HHBluetoothModel HHFloatHexString:pressure];
}

/// 电池电压:23
- (void)setBatteryVoltage:(NSString *)batteryVoltage {
    _batteryVoltage = batteryVoltage;
    
    /// 16进制转10进制
    self.batteryVoltage_float = [HHBluetoothModel HHFloatHexString:batteryVoltage] / 10.0;
}






















/// 将 NSData 转化为 16进制字符串
+ (NSString *)HHCoverFromDataToHexStr:(NSData *)data {
    
    /// 格式转换char
    const unsigned char *dataBuffer = (const unsigned char *)[data bytes];
    
    NSUInteger dataLength = [data length];
    
    NSMutableString *hexString = [NSMutableString stringWithCapacity:(dataLength * 2)];
    
    for(int i = 0; i < dataLength; i++){
        
        [hexString appendString:[NSString stringWithFormat:@"%02lx", (unsigned long)dataBuffer[i]]];

    }
    
    return [NSString stringWithString:hexString];
 
}




/// 16进制转10进制
+ (CGFloat)HHFloatHexString:(NSString *)aHexString {
    
    //    用竖式计算： 2AF5换算成10进制:
    //    第0位： 5 * 16^0 = 5
    //    第1位： F * 16^1 = 240
    //    第2位： A * 16^2 = 2560
    //    第3位： 2 * 16^3 = 8192 ＋
    //    -------------------------------------
    //    10997
    
    CGFloat sum = 0.0;
    
    for (NSInteger i = 0; i < aHexString.length; i++) {
        
        // 截取字符串
        NSString *string = [aHexString substringWithRange:NSMakeRange(aHexString.length-1 - i,1)];
        // 根据公式计算
        CGFloat num = strtoul([string UTF8String], 0, 16) * pow(16,i);
        
        sum += num;
        
    }
    
    return sum;
}


/// 16进制转2进制
+ (NSString *)HHStringBinaryString:(NSString *)aBinaryString {
    
    NSMutableDictionary *hexDic = [[NSMutableDictionary alloc] initWithCapacity:16];
    [hexDic setObject:@"0000" forKey:@"0"];
    [hexDic setObject:@"0001" forKey:@"1"];
    [hexDic setObject:@"0010" forKey:@"2"];
    [hexDic setObject:@"0011" forKey:@"3"];
    [hexDic setObject:@"0100" forKey:@"4"];
    [hexDic setObject:@"0101" forKey:@"5"];
    [hexDic setObject:@"0110" forKey:@"6"];
    [hexDic setObject:@"0111" forKey:@"7"];
    [hexDic setObject:@"1000" forKey:@"8"];
    [hexDic setObject:@"1001" forKey:@"9"];
    [hexDic setObject:@"1010" forKey:@"A"];
    [hexDic setObject:@"1011" forKey:@"B"];
    [hexDic setObject:@"1100" forKey:@"C"];
    [hexDic setObject:@"1101" forKey:@"D"];
    [hexDic setObject:@"1110" forKey:@"E"];
    [hexDic setObject:@"1111" forKey:@"F"];
    
    NSMutableString *binary = [NSMutableString string];
    
    for (int i = 0; i < aBinaryString.length; i++) {
        NSString *key = [aBinaryString substringWithRange:NSMakeRange(i, 1)];
        
        key = key.uppercaseString; // 不管三七二十一,先转为大写字母再说
        NSString *binaryStr = hexDic[key];
        
        [binary appendString:[NSString stringWithFormat:@"%@",binaryStr]];
    }
    
    return binary;
}


/// 2进制取反 +1
+ (NSString *)HHStringNotBinaryString:(NSString *)aBinaryString {

    NSString *binaryString = [aBinaryString stringByReplacingOccurrencesOfString:@"0"withString:@"↓"];
    binaryString = [binaryString stringByReplacingOccurrencesOfString:@"1"withString:@"0"];
    binaryString = [binaryString stringByReplacingOccurrencesOfString:@"↓"withString:@"1"];

    // 获取字符串最后一位
    NSString *lastStr = [binaryString substringWithRange:NSMakeRange(binaryString.length-1,1)];
    
    // 判断最后一位是否需要计算
    if ([lastStr boolValue] == NO) {
        binaryString = [NSString stringWithFormat:@"%@/2",binaryString];
        binaryString = [binaryString stringByReplacingOccurrencesOfString:@"0/2"withString:@"1"];
        return binaryString;
    }
    
    binaryString = [NSString stringWithFormat:@"%@/2",binaryString];
    binaryString = [binaryString stringByReplacingOccurrencesOfString:@"1/2"withString:@"2"];

    
    for (NSInteger i = 0; i < binaryString.length; i++) {
        binaryString = [binaryString stringByReplacingOccurrencesOfString:@"02"withString:@"10"];
        binaryString = [binaryString stringByReplacingOccurrencesOfString:@"12"withString:@"20"];
    }

    binaryString = [binaryString stringByReplacingOccurrencesOfString:@"2"withString:@"10"];
    
    return binaryString;
}

/// 2进制转换为10进制
+ (NSInteger)HHDecimalByBinary:(NSString *)binary {
    
    NSInteger decimal = 0;
    for (int i=0; i<binary.length; i++) {
        
        NSString *number = [binary substringWithRange:NSMakeRange(binary.length - i - 1, 1)];
        if ([number isEqualToString:@"1"]) {
            
            decimal += pow(2, i);
        }
    }
    return decimal;
}





/// 打印model所有值
- (void)HHLogModelAll {
    
    NSLog(@"原始数据:%@",self.originalData);
    NSLog(@"传感器1:%.2f",self.sensor1_float);
    NSLog(@"传感器2:%.2f",self.sensor2_float);
    NSLog(@"温度:%.2f",self.temperature_float);
    NSLog(@"湿度:%.2f",self.humidity_float);
    NSLog(@"压力:%.2f",self.pressure_float);
    NSLog(@"电池电压:%.2f",self.batteryVoltage_float);
    
    NSLog(@"记录时间:%@",self.recordingTime);
    NSLog(@"设备UUID:%@",self.identifier);
    NSLog(@"服务UUID:%@",self.service_uuid);
    NSLog(@"位置坐标:%@",self.locationAddress);
    NSLog(@"天气信息:%@",self.weather);

}




/// 获取地址
- (NSString *)HHAddress {
    
    NSString *address_temp = [[self.locationAddress componentsSeparatedByString:@"@"] firstObject];
    
    NSString *address_temp2 = [[address_temp componentsSeparatedByString:@","] lastObject];

    if (address_temp2.length > 0) {
        return address_temp2;
    }
    
    return address_temp;
}



@end
