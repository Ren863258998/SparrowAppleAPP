//
//  HHBluetoothModel.h
//  GasDetection
//
//  Created by 司月 on 2018/8/17.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h> // 蓝牙库


@interface HHBluetoothModel : NSObject

/// 服务特征
@property(nonatomic,strong)CBCharacteristic *characteristic;



/// 记录时间
@property(nonatomic,strong,readonly)NSDate *recordingTime;

/// 记录设备UUID
@property(nonatomic,strong,readonly)NSString *identifier;

/// 记录服务UUID
@property(nonatomic,strong,readonly)NSString *service_uuid;

/// 记录原始数据
@property(nonatomic,strong,readonly)NSString *originalData;


/// 传感器1
@property(nonatomic,assign)CGFloat sensor1_float;
/// 传感器2
@property(nonatomic,assign,readonly)CGFloat sensor2_float;
/// 温度
@property(nonatomic,assign,readonly)CGFloat temperature_float;
/// 湿度
@property(nonatomic,assign,readonly)CGFloat humidity_float;
/// 压力
@property(nonatomic,assign,readonly)CGFloat pressure_float;
/// 电池电压
@property(nonatomic,assign,readonly)CGFloat batteryVoltage_float;




/// 记录位置地址
@property(nonatomic,strong)NSString *locationAddress;

/// 天气信息
@property(nonatomic,strong)NSString *weather;



/// 初始化 测试数据
+ (HHBluetoothModel *)HHNew_test;

/// 初始化
+ (HHBluetoothModel *)HHNew:(CBCharacteristic *)characteristic;

/// 初始化
+ (HHBluetoothModel *)HHNew_L:(CBCharacteristic *)characteristic time:(NSDate *)recordingTime;



/// 将 NSData 转化为 16进制字符串
+ (NSString *)HHCoverFromDataToHexStr:(NSData *)data;

/// 16进制转10进制
+ (CGFloat)HHFloatHexString:(NSString *)aHexString;

/// 16进制转2进制
+ (NSString *)HHStringBinaryString:(NSString *)aBinaryString;

/// 2进制取反 +1
+ (NSString *)HHStringNotBinaryString:(NSString *)aBinaryString;

/// 2进制转换为10进制
+ (NSInteger)HHDecimalByBinary:(NSString *)binary;



/// 打印model所有值
- (void)HHLogModelAll;



/// 获取地址
- (NSString *)HHAddress;





@end


