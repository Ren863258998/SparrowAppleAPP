//
//  HHBluetoothManager.h
//  GasDetection
//
//  Created by 司月 on 2018/8/15.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h> // 蓝牙库
#import "HHBluetoothModel.h" // 蓝牙数据model
#import "HHHardwareModel.h" // 蓝牙硬件model


NS_ASSUME_NONNULL_BEGIN

@interface HHBluetoothManager : NSObject

/// 提供快速创建方法
+ (instancetype)shared;


/// 中央管理者
@property (nonatomic,strong,readonly)CBCentralManager *centralManager;

/// 蓝牙状态
@property (nonatomic,assign,readonly)CBManagerState peripheralState;

/// 当前连接的外围设备
@property (nonatomic,strong,readonly)CBPeripheral *peripheral;

/// 蓝牙 通知服务
@property (nonatomic,strong,readonly)CBCharacteristic *characteristic_notifying;

/// 蓝牙 写入服务
@property (nonatomic,strong,readonly)CBCharacteristic *characteristic_write;

@property (nonatomic,strong)HHHardwareModel *hardwareModel;


/// 停止扫描
- (void)HHStopScan;

/// 扫描外围设备
- (void)HHScanningEquipment:(void (^)(CBPeripheral *peripheral_temp,NSNumber *RSSI_temp,BOOL isAuto))completeBlock;

/// 连接设备
- (void)HHConnectPeripheral:(CBPeripheral *)peripheral
                 Successful:(void (^)(CBPeripheral *peripheral_temp))successfulBlock
                    Failure:(void (^)(CBPeripheral *peripheral_temp,NSError *error_temp))failureBlock
                 Disconnect:(void (^)(CBPeripheral *peripheral_temp,NSError *error_temp))disconnectBlock;


/// 写入值 s 获取当前监测数据
- (void)HHWriteValue_s:(void (^)(HHBluetoothModel *bluetoothModel))completeBlock;

/// 写入值 e 获取硬件信息
- (void)HHWriteValue_e:(void (^)(HHHardwareModel *hardwareModel))completeBlock;

/// 写入值 l 获取主办历史数据
- (void)HHWriteValue_l:(NSInteger)num ProgressBlock:(void (^)(HHBluetoothModel *bluetoothModel,NSInteger index,NSInteger count))progressBlock block:(void (^)(NSMutableArray <HHBluetoothModel *>*bluetoothArr))completeBlock;

/// 写入值 L 删除硬件历史数据
- (void)HHWriteValue_L;

/// 写入值 l
- (void)HHWriteValue_l;



/// 断开连接
-(void)HHDisconnectPeripheral;




@end

NS_ASSUME_NONNULL_END
