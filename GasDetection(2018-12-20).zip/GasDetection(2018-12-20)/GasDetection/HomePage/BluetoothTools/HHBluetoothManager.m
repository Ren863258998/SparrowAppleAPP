//
//  HHBluetoothManager.m
//  GasDetection
//
//  Created by 司月 on 2018/8/15.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHBluetoothManager.h"
#import "GasDetectionCoreDataTool.h"

@interface HHBluetoothManager ()<CBCentralManagerDelegate,CBPeripheralDelegate>

/// 中央管理者
@property (nonatomic,strong)CBCentralManager *centralManager;

/// 蓝牙状态
@property (nonatomic,assign)CBManagerState peripheralState;

/// 当前连接的外围设备
@property (nonatomic,strong)CBPeripheral *peripheral;

/// 蓝牙 通知服务
@property (nonatomic,strong)CBCharacteristic *characteristic_notifying;

/// 蓝牙 写入服务
@property (nonatomic,strong)CBCharacteristic *characteristic_write;



/// 扫描到设备回调block
@property (nonatomic,strong)void (^HHScanningEquipmentBlock)(CBPeripheral *peripheral_temp,NSNumber *RSSI_temp,BOOL isAuto);

/// 连接失败回调block
@property (nonatomic,strong)void (^HHDidFailToConnectPeripheralBlock)(CBPeripheral *peripheral_temp,NSError *error_temp);

/// 连接断开回调block
@property (nonatomic,strong)void (^HHDidDisconnectPeripheralBlock)(CBPeripheral *peripheral_temp,NSError *error_temp);

/// 连接成功回调block
@property (nonatomic,strong)void (^HHDidConnectPeripheralBlock)(CBPeripheral *peripheral_temp);

/// 读取数据回调block
@property (nonatomic,strong)void (^HHDidUpdateValueForCharacteristicBlock)(CBCharacteristic *characteristic_temp,NSError *error_temp);



@end

@implementation HHBluetoothManager


/// 用来保存唯一的单例对象
static HHBluetoothManager *_instance;

+ (instancetype)shared {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance;
}

+ (id)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [super allocWithZone:zone];
    });
    return _instance;
}

- (id)copyWithZone:(NSZone *)zone {
    return _instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize {
    
    /// 初始化中央管理者
    if (!self.centralManager) {
        CBCentralManager *centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
        self.centralManager = centralManager;
    }
    
    
    
}


/// 当前连接的外围设备 赋值
- (void)setPeripheral:(CBPeripheral *)peripheral {
    _peripheral = peripheral;
    
    /// 停止扫描
    [self HHStopScan];
}


///// 将要恢复状态
//- (void)centralManager:(CBCentralManager *)central willRestoreState:(NSDictionary<NSString *,id> *)dict {
//    
//    NSLog(@"将要恢复状态");
//}

/// 状态更新时调用
- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    
    // 赋值当前的状态
    self.peripheralState = central.state;
    
    // 获取通知中心单例
    NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
    // 发送通知
    [notiCenter postNotificationName:@"HHCentralManagerDidUpdateState" object:central userInfo:nil];
    
    
    switch (central.state) {
        case CBManagerStateUnknown:{
            NSLog(@"未知状态");
        }break;
        case CBManagerStateResetting:{
            NSLog(@"重置状态");
        }break;
        case CBManagerStateUnsupported:{
            NSLog(@"不支持的状态");
        }break;
        case CBManagerStateUnauthorized:{
            NSLog(@"未授权的状态");
        }break;
        case CBManagerStatePoweredOff:{
            NSLog(@"关闭状态");
        }break;
        case CBManagerStatePoweredOn:{
            NSLog(@"开启状态－可用状态");
        }break;default:break;
    }
}





/// 停止扫描
- (void)HHStopScan {
    
    // 回调block 置空
    self.HHScanningEquipmentBlock = nil;
    
    /// 停止扫描
    [self.centralManager stopScan];
    

    // 发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"HHBluetoothManagerState" object:@"停止扫描" userInfo:nil];
}

/// 扫描外围设备
- (void)HHScanningEquipment:(void (^)(CBPeripheral *peripheral_temp,NSNumber *RSSI_temp,BOOL isAuto))completeBlock {
    
    NSLog(@"扫描设备");
    
    /// 停止扫描
    [self HHStopScan];
    
    // 判断蓝牙状态 蓝牙状态正常 扫描连接
    if (self.peripheralState ==  CBManagerStatePoweredOn) {
        
        /// 扫描到设备回调block
        if (completeBlock) {
            self.HHScanningEquipmentBlock = completeBlock;
        }
        
        /// 扫描外围设备
        [self.centralManager scanForPeripheralsWithServices:nil options:nil];
//        [self.centralManager scanForPeripheralsWithServices:nil options:@{CBCentralManagerRestoredStateScanOptionsKey:@(YES)}];
        
        // 发送通知
        [[NSNotificationCenter defaultCenter] postNotificationName:@"HHBluetoothManagerState" object:@"扫描设备" userInfo:nil];
    }else {
        NSLog(@"扫描设备失败-两秒后再次扫描");
        
        __weak typeof(self) weakSelf = self;

        //--- 加载延迟
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            /// 扫描外围设备
            [weakSelf HHScanningEquipment:completeBlock];
        });
    }
    
}


/// 连接设备
- (void)HHConnectPeripheral:(CBPeripheral *)peripheral
                 Successful:(void (^)(CBPeripheral *peripheral_temp))successfulBlock
                    Failure:(void (^)(CBPeripheral *peripheral_temp,NSError *error_temp))failureBlock
                 Disconnect:(void (^)(CBPeripheral *peripheral_temp,NSError *error_temp))disconnectBlock {
    NSLog(@"连接设备");
    
    /// 保存当前连接设备
    self.peripheral = peripheral;
    
    if (successfulBlock) {
        self.HHDidConnectPeripheralBlock = successfulBlock;
    }
    if (failureBlock) {
        self.HHDidFailToConnectPeripheralBlock = failureBlock;
    }
    if (disconnectBlock) {
        self.HHDidDisconnectPeripheralBlock = disconnectBlock;
    }
    
    /// 当前选择的设备
    [self.centralManager connectPeripheral:peripheral options:nil];
    
}







/**
 扫描到设备
 @param central 中心管理者
 @param peripheral 扫描到的设备
 @param advertisementData 广告信息
 @param RSSI 信号强度
 */
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI {
    
    /// 如果没有设备名则不显示
    if (
        peripheral.name.length <= 0
        || ![peripheral.name hasPrefix:@"Sparrow"]
        ) {
        return;
    }
    
    
    /// 判断是否有自动连接设备
    if ([[[[GasDetectionCoreDataTool shared] HHReadDataSettingForm] equipmentUUID] isEqual:peripheral.identifier]) {
        NSLog(@"有自动连接设备");
 
        /// 扫描到设备回调block
        if (self.HHScanningEquipmentBlock) {
            self.HHScanningEquipmentBlock(peripheral,RSSI,YES);
        }
        
        return;
    }
    
    /// 扫描到设备回调block
    if (self.HHScanningEquipmentBlock) {
        self.HHScanningEquipmentBlock(peripheral,RSSI,NO);
    }
    
}


/**
 连接失败
 @param central 中心管理者
 @param peripheral 连接失败的设备
 @param error 错误信息
 */
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"连接失败:%@",error);

    /// 连接失败回调block
    if (self.HHDidFailToConnectPeripheralBlock) {
        self.HHDidFailToConnectPeripheralBlock(peripheral,error);
    }
    
    // 发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"HHBluetoothManagerState" object:@"连接失败" userInfo:nil];
}

/**
 连接断开
 @param central 中心管理者
 @param peripheral 连接断开的设备
 @param error 错误信息
 */
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"连接断开:%@",error);
    
    if (!self.peripheral) {
        return;
    }
 
    /// 连接断开回调block
    if (self.HHDidDisconnectPeripheralBlock) {
        self.HHDidDisconnectPeripheralBlock(peripheral,error);
    }
    
    // 发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"HHBluetoothManagerState" object:@"连接断开" userInfo:nil];
}

/**
 连接成功
 @param central 中心管理者
 @param peripheral 连接成功的设备
 */
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    NSLog(@"连接设备:%@成功",peripheral.name);

    // 设置设备的代理
    peripheral.delegate = self;
    // 传入nil  代表扫描所有服务
    [peripheral discoverServices:nil];

    // 发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"HHBluetoothManagerState" object:@"连接成功" userInfo:nil];
}


/**
 扫描到服务
 @param peripheral 服务对应的设备
 @param error 扫描错误信息
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
//    NSLog(@"扫描服务:%@",peripheral);
    
    // 遍历所有的服务
    for (CBService *service in peripheral.services) {
//        NSLog(@"服务:%@",service);
        
        // 根据服务去扫描特征
        [peripheral discoverCharacteristics:nil forService:service];
    }
}



/**
 扫描到对应的特征
 @param peripheral 设备
 @param service 特征对应的服务
 @param error 错误信息
 */
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error {
    NSLog(@"扫描到对应的特征");
    
    // 遍历所有的特征
    for (CBCharacteristic *characteristic in service.characteristics) {
//        NSLog(@"特征值:%@",characteristic);
        
        /// 判断是否是 通知
        if ([characteristic.UUID.UUIDString isEqualToString:@"6E400003-B5A3-F393-E0A9-E50E24DCCA9E"]) {
            NSLog(@"找到了通知");
            
            self.characteristic_notifying = characteristic;
            // 设置通知
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        }
        
        /// 判断是否是 写入方法
        if ([characteristic.UUID.UUIDString isEqualToString:@"6E400002-B5A3-F393-E0A9-E50E24DCCA9E"]) {
            NSLog(@"找到了写入方法");
            
            self.characteristic_write = characteristic;

        }

    }

    
    /// 连接成功回调block
    if (self.HHDidConnectPeripheralBlock) {
        self.HHDidConnectPeripheralBlock(self.peripheral);
    }
    
    /// 保存设备UUID自动连接使用
    [[GasDetectionCoreDataTool shared] HHReadDataSettingForm].equipmentUUID = self.peripheral.identifier;
    [[GasDetectionCoreDataTool shared] HHUpdateData];
    
}


/**
 根据特征读到数据
 @param peripheral 读取到数据对应的设备
 @param characteristic 特征
 @param error 错误信息
 */
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(nonnull CBCharacteristic *)characteristic error:(nullable NSError *)error {
    NSLog(@"根据特征读到数据:%@",characteristic.value);
    
    /// 读取数据回调block
    if (self.HHDidUpdateValueForCharacteristicBlock) {
        self.HHDidUpdateValueForCharacteristicBlock(characteristic,error);
    }

}
















/// 写入值 s 获取当前监测数据
- (void)HHWriteValue_s:(void (^)(HHBluetoothModel *bluetoothModel))completeBlock {
    
    // 判断是否获取到服务
    if (!self.characteristic_write) {return;}
    
    // 判断block是否存在
    if (completeBlock) {
        
        // 代理结束回调
        self.HHDidUpdateValueForCharacteristicBlock = ^(CBCharacteristic *characteristic_temp, NSError *error_temp) {
            
            // 判断是否获取到值
            if (!error_temp) {
                /// 创建数据model
                HHBluetoothModel *bluetoothModel = [HHBluetoothModel HHNew:characteristic_temp];
                                
                // 回调结束block
                completeBlock(bluetoothModel);
                
                // 获取通知中心单例
                NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
                // 发送通知
                [notiCenter postNotificationName:@"HHWriteValue_s" object:bluetoothModel userInfo:nil];
                
            }else {
                NSLog(@"代理结束回调失败:%@",error_temp);
            }
        };
    }
    
    // 创建写入数据
    Byte byte[] = {0x73};
    
    // 转换和数据格式
    NSData *data = [NSData dataWithBytes:byte length:2];
    
    // 写入数据
    [self.peripheral writeValue:data forCharacteristic:self.characteristic_write type:CBCharacteristicWriteWithResponse];
    
}


/// 写入值 e 获取硬件信息
- (void)HHWriteValue_e:(void (^)(HHHardwareModel *hardwareModel))completeBlock {
    
    __weak typeof(self) weakSelf = self;

    
    // 判断是否获取到服务
    if (!self.characteristic_write) {return;}
    
    // 判断block是否存在
    if (completeBlock) {
        
        NSMutableArray *arr_temp = [NSMutableArray new];
        
        // 代理结束回调
        self.HHDidUpdateValueForCharacteristicBlock = ^(CBCharacteristic *characteristic_temp, NSError *error_temp) {
            
            // 判断是否获取到值
            if (!error_temp) {
                
                [arr_temp addObject:characteristic_temp.value];
                
                if (arr_temp.count == 4) {
                    
                    HHHardwareModel *hardwareModel = [HHHardwareModel HHNew:arr_temp];
                    hardwareModel.name = weakSelf.peripheral.name;
                    hardwareModel.udid = weakSelf.peripheral.identifier.UUIDString;
                    weakSelf.hardwareModel = hardwareModel;
                    
                    // 回调结束block
                    completeBlock(hardwareModel);
                    
                    // 获取通知中心单例
                    NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
                    // 发送通知
                    [notiCenter postNotificationName:@"HHWriteValue_e" object:hardwareModel userInfo:nil];
                }

            }else {
                NSLog(@"代理结束回调失败:%@",error_temp);
            }
        };
    }
    
    // 创建写入数据
    Byte byte[] = {0x65};
    
    // 转换和数据格式
    NSData *data = [NSData dataWithBytes:byte length:2];
    
    // 写入数据
    [self.peripheral writeValue:data forCharacteristic:self.characteristic_write type:CBCharacteristicWriteWithResponse];
    
}


/// 写入值 l 获取主板历史数据
- (void)HHWriteValue_l:(NSInteger)num ProgressBlock:(void (^)(HHBluetoothModel *bluetoothModel,NSInteger index,NSInteger count))progressBlock block:(void (^)(NSMutableArray <HHBluetoothModel *>*bluetoothArr))completeBlock {
    
    // 判断是否获取到服务
    if (!self.characteristic_write) {return;}
    
    NSMutableArray <HHBluetoothModel *>*bluetoothArr = [NSMutableArray new];
    
    if (num <= 0) {
        if (completeBlock) {
            completeBlock(bluetoothArr);
        }
        return;
    }
    
    // 判断block是否存在
    if (completeBlock) {
        
        // 代理结束回调
        self.HHDidUpdateValueForCharacteristicBlock = ^(CBCharacteristic *characteristic_temp, NSError *error_temp) {
            
            // 判断是否获取到值
            if (!error_temp) {
                /// 创建数据model
                HHBluetoothModel *bluetoothModel;

                if (bluetoothArr.count == 0) {
                    
                    NSArray<HistoricalDataDay *> *arr = [[GasDetectionCoreDataTool shared] HHReadDataHistoricalData_All];
                    
                    if (arr.count <= 0) {
 
                        bluetoothModel = [HHBluetoothModel HHNew_L:characteristic_temp time:[NSDate date]];

                    }else {
                        NSTimeInterval timeIntervalSince1970 = arr.lastObject.recordingTime.timeIntervalSince1970;
                        
                        timeIntervalSince1970 += 3.3;
                        
                        NSDate *newTime = [NSDate dateWithTimeIntervalSince1970:timeIntervalSince1970];
                        
                        bluetoothModel = [HHBluetoothModel HHNew_L:characteristic_temp time:newTime];
                    }

                }else {
                    
                    NSTimeInterval timeIntervalSince1970 = bluetoothArr.lastObject.recordingTime.timeIntervalSince1970;
                    
                    timeIntervalSince1970 += 3.3;
                    
                    NSDate *newTime = [NSDate dateWithTimeIntervalSince1970:timeIntervalSince1970];
                    
                    bluetoothModel = [HHBluetoothModel HHNew_L:characteristic_temp time:newTime];
                }
                
//                [bluetoothModel HHLogModelAll];
                
                [bluetoothArr addObject:bluetoothModel];
                
                if (progressBlock) {
                    progressBlock(bluetoothModel,bluetoothArr.count,num);
                }
                
                if (bluetoothArr.count == num - 1) {
                    // 回调结束block
                    completeBlock(bluetoothArr);
                    
                    // 获取通知中心单例
                    NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
                    // 发送通知
                    [notiCenter postNotificationName:@"HHWriteValue_l" object:bluetoothModel userInfo:nil];
                }
                
            }else {
                NSLog(@"代理结束回调失败:%@",error_temp);
            }
        };
    }
    
    // 创建写入数据
    Byte byte[] = {0x6C};
    
    // 转换和数据格式
    NSData *data = [NSData dataWithBytes:byte length:2];
    
    // 写入数据
    [self.peripheral writeValue:data forCharacteristic:self.characteristic_write type:CBCharacteristicWriteWithResponse];
    
}


/// 写入值 L 删除硬件历史数据
- (void)HHWriteValue_L {
    
    // 判断是否获取到服务
    if (!self.characteristic_write) {return;}

    // 创建写入数据
    Byte byte[] = {0x4C};
    
    // 转换和数据格式
    NSData *data = [NSData dataWithBytes:byte length:2];
    
    // 写入数据
    [self.peripheral writeValue:data forCharacteristic:self.characteristic_write type:CBCharacteristicWriteWithResponse];
    
}


/// 写入值 l
- (void)HHWriteValue_l {
    
    // 判断是否获取到服务
    if (!self.characteristic_write) {return;}
    
    // 创建写入数据
    Byte byte[] = {0x6C};
    
    // 转换和数据格式
    NSData *data = [NSData dataWithBytes:byte length:2];
    
    // 写入数据
    [self.peripheral writeValue:data forCharacteristic:self.characteristic_write type:CBCharacteristicWriteWithResponse];
    
    self.HHDidUpdateValueForCharacteristicBlock = nil;
}



/// 断开连接
- (void)HHDisconnectPeripheral {
    
    /// 主动断开
    [self.centralManager cancelPeripheralConnection:self.peripheral];
    self.peripheral = nil;
}

@end
