//
//  HHHomeViewController.h
//  GasDetection
//
//  Created by 司月 on 2018/8/14.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHViewController.h"
#import "HHHomeModel.h"
#import "HHDisplayDataView.h"   // 头部分区
#import "SYTimeBlock.h"         // 计时器block

NS_ASSUME_NONNULL_BEGIN

@interface HHHomeViewController : HHViewController

/// tableView
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

/// 分区头
@property (nonatomic,strong)HHDisplayDataView *displayDataView;

/// 分区头imageView
@property (nonatomic,strong)UIImageView *picView;

/// 计时器控件
@property (nonatomic,strong)SYTimeBlock *time;

/// 硬件信息
@property (nonatomic,strong)HHHardwareModel *hardwareModel;

/// 数组
@property (nonatomic,strong)NSMutableArray<HHHomeModel *> *homeArray;







@end

NS_ASSUME_NONNULL_END
