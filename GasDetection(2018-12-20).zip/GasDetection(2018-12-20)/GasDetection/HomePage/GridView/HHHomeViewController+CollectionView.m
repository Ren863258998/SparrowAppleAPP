//
//  HHHomeViewController+CollectionView.m
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHomeViewController+CollectionView.h"
#import "HHHomeCollectionViewCell.h"
#import "HHLocationInformation.h"

@implementation HHHomeViewController (CollectionView)

/// 网格视图
- (void)HHGridView {

    // 是否显示水平滚动条
//    self.collectionView.showsHorizontalScrollIndicator = NO;
    // 是否显示垂直滚动条
//    self.collectionView.showsVerticalScrollIndicator = NO;
// 是否允许超出滑动范围
    self.collectionView.alwaysBounceVertical = YES;
    // 背景色
//    self.collectionView.backgroundColor = [UIColor colorWithRed:0.463 green:0.878 blue:0.882 alpha:1.000];
    
    
    
    // 注册类，是用纯代码生成的collectiviewcell类才行
    [self.collectionView registerNib:[UINib nibWithNibName:@"HHHomeCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"HHHomeCollectionViewCell"];
    // 注册头部
    [self.collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header"];

    
    
    /// 初始化数组
    self.homeArray = [NSMutableArray new];
    
    [self.homeArray addObject:[HHHomeModel HHNew:@"HHHomeModel_battery" title:NSLocalizedString(@"电量(%)",@"OK") content:@"--" type:HHHomeModel_battery]];
    [self.homeArray addObject:[HHHomeModel HHNew:@"HHHomeModel_weather" title:NSLocalizedString(@"天气(℃)",@"OK") content:@"--" type:HHHomeModel_weather]];
    [self.homeArray addObject:[HHHomeModel HHNew:@"HHHomeModel_temperature" title:NSLocalizedString(@"温度(℃)",@"OK") content:@"--" type:HHHomeModel_temperature]];
    [self.homeArray addObject:[HHHomeModel HHNew:@"HHHomeModel_humidity" title:NSLocalizedString(@"湿度(%)",@"OK") content:@"--" type:HHHomeModel_humidity]];
    [self.homeArray addObject:[HHHomeModel HHNew:@"HHHomeModel_pressure" title:NSLocalizedString(@"压力(pa)",@"OK") content:@"--" type:HHHomeModel_pressure]];
    [self.homeArray addObject:[HHHomeModel HHNew:@"HHHomeModel_address" title:NSLocalizedString(@"位置",@"OK") content:@"--" type:HHHomeModel_address]];

    

    
    __weak typeof(self) weakSelf = self;
    
    // 获取通知中心单例
    NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
    
    // 接收通知
    [notiCenter addObserverForName:@"HHWriteValue_s" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        
        /// 创建数据model
        HHBluetoothModel *bluetoothModel = note.object;
        
        /// 电量
        HHHomeModel *model_temp1 = weakSelf.homeArray[0];
        model_temp1.content = [NSString stringWithFormat:@"%.2f",bluetoothModel.batteryVoltage_float];
        HHHomeCollectionViewCell *cell_temp1 = (HHHomeCollectionViewCell *)[weakSelf.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        cell_temp1.model = model_temp1;
        
        /// 天气
        HHHomeModel *model_temp2 = weakSelf.homeArray[1];
        model_temp2.content = [bluetoothModel weather];
        HHHomeCollectionViewCell *cell_temp2 = (HHHomeCollectionViewCell *)[weakSelf.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
        cell_temp2.model = model_temp2;
        
        /// 温度
        HHHomeModel *model_temp3 = weakSelf.homeArray[2];
        model_temp3.content = [NSString stringWithFormat:@"%.2f",bluetoothModel.temperature_float];
        HHHomeCollectionViewCell *cell_temp3 = (HHHomeCollectionViewCell *)[weakSelf.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
        cell_temp3.model = model_temp3;
        
        /// 湿度
        HHHomeModel *model_temp4 = weakSelf.homeArray[3];
        model_temp4.content = [NSString stringWithFormat:@"%.2f",bluetoothModel.humidity_float];
        HHHomeCollectionViewCell *cell_temp4 = (HHHomeCollectionViewCell *)[weakSelf.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:0]];
        cell_temp4.model = model_temp4;
        
        /// 压力
        HHHomeModel *model_temp5 = weakSelf.homeArray[4];
        model_temp5.content = [NSString stringWithFormat:@"%.2f",bluetoothModel.pressure_float];
        HHHomeCollectionViewCell *cell_temp5 = (HHHomeCollectionViewCell *)[weakSelf.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:4 inSection:0]];
        cell_temp5.model = model_temp5;
        
        /// 位置
        HHHomeModel *model_temp6 = weakSelf.homeArray[5];
        model_temp6.content = [[HHLocationInformation shared] city];
        HHHomeCollectionViewCell *cell_temp6 = (HHHomeCollectionViewCell *)[weakSelf.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:5 inSection:0]];
        cell_temp6.model = model_temp6;

    }];
}




#pragma mark - UICollectionViewDataSource

/// 指定Section个数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

/// 指定section中的collectionViewCell的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.homeArray.count;
}

/// 设置最小行间距，也就是前一行与后一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

/// 设置最小列间距，也就是左行与右一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

// 设置cell上下左右相距
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(15, 5, 10, 5);
}

/// 设置每个cell大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(([[UIScreen mainScreen] bounds].size.width - 2 - 10) / 2 , 120);

}

/// 配置section中的collectionViewCell的显示
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    HHHomeCollectionViewCell *cell_temp = [collectionView dequeueReusableCellWithReuseIdentifier:@"HHHomeCollectionViewCell" forIndexPath:indexPath];
    
    cell_temp.model = self.homeArray[indexPath.row];
    
    
    return cell_temp;
    
}


#pragma mark - UICollectionViewDelegateFlowLayout

// 设置section头视图的参考大小，与tableheaderview类似
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    
    return CGSizeMake(collectionView.contentSize.width, self.view.frame.size.height * 0.65);
    
}

/// 这个也是最重要的方法 获取Header的 方法。
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {

    UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"header" forIndexPath:indexPath];
//    headerView.backgroundColor = [UIColor greenColor];
    self.displayDataView.frame = headerView.frame;
//    self.displayDataView.backgroundColor = [UIColor redColor];
    [headerView addSubview:self.displayDataView];
    
    return headerView;
}




/// 选中操作
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
 
}







@end
