//
//  HHHomeModel.m
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHomeModel.h"

@implementation HHHomeModel


/// 初始化model
+ (HHHomeModel *)HHNew:(NSString *)pic title:(NSString *)title content:(NSString *)content type:(HHHomeModelType)type {
    
    HHHomeModel *model = [HHHomeModel new];
    model.pic = pic;
    model.title = title;
    model.content = content;
    model.type = type;
    
    
    return model;
    
}










@end
