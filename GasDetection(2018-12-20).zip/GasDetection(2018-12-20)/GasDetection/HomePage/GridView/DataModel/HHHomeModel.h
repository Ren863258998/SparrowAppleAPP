//
//  HHHomeModel.h
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>

// 文件操作类型
typedef NS_ENUM(NSInteger,HHHomeModelType) {
    /// 电池
    HHHomeModel_battery = 0,
    /// 天气
    HHHomeModel_weather = 1,
    /// 温度
    HHHomeModel_temperature = 2,
    /// 湿度
    HHHomeModel_humidity = 3,
    /// 压力
    HHHomeModel_pressure = 4,
    /// 位置
    HHHomeModel_address = 5,
};




NS_ASSUME_NONNULL_BEGIN

@interface HHHomeModel : NSObject

/// 图片地址
@property (nonatomic,strong)NSString *pic;

/// 标题
@property (nonatomic,strong)NSString *title;

/// 内容值
@property (nonatomic,strong)NSString *content;

/// 类型
@property (nonatomic,assign)HHHomeModelType type;




/// 初始化model
+ (HHHomeModel *)HHNew:(NSString *)pic title:(NSString *)title content:(NSString *)content type:(HHHomeModelType)type;







@end

NS_ASSUME_NONNULL_END
