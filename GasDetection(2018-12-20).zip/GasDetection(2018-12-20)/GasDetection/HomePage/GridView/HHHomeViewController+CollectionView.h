//
//  HHHomeViewController+CollectionView.h
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHomeViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHHomeViewController (CollectionView)<UICollectionViewDelegate,UICollectionViewDataSource>


/// 网格视图
- (void)HHGridView;




@end

NS_ASSUME_NONNULL_END
