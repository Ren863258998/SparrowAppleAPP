//
//  HHHomeCollectionViewCell.m
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHomeCollectionViewCell.h"

@implementation HHHomeCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    
//    self.contentView.clipsToBounds = YES;
//    self.contentView.layer.cornerRadius = 10;
    
    self.backView.layer.cornerRadius = 10;
    self.backView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.backView.layer.shadowOffset = CGSizeMake(2, 1);
    self.backView.layer.shadowOpacity = 0.1;
    self.backView.layer.shadowRadius = 5;
    self.backView.clipsToBounds = NO;
    
    
    
    
}


/// 赋值model
- (void)setModel:(HHHomeModel *)model {
    _model = model;
    
    self.pic.image = model.pic.length>0?[UIImage imageNamed:model.pic]:nil;
    
    self.title.text = model.title;
    
    
    if ([model.content isEqualToString:@"--"] || model.content.length == 0 || model.content == nil) {
        self.content.text = model.content;
        return;
    }
    
    /// 判断cell类型
    switch (model.type) {
            /// 电量
        case HHHomeModel_battery:{
            // 数字动画 格式
            self.content.formatBlock = ^NSString* (CGFloat value){
                return [NSString stringWithFormat:@"%.0f",value];
            };
            
            CGFloat value = [model.content floatValue];
            
            if (value <= 4.2 && value >= 3.7) {
                value = value / 4.2;
            }

            if (value >= 1.0) {
                value = 1.0;
            }
            
            if (value <= 0.0) {
                value = 0.0;
            }
            
            /// 设置值
            [self.content countFromCurrentValueTo:value * 100.0 withDuration:1.0];
        }break;
            /// 天气
        case HHHomeModel_weather:{
            // 数字动画 格式
            self.content.formatBlock = ^NSString* (CGFloat value){
                return [NSString stringWithFormat:@"%.2f",value];
            };
            /// 设置值
            self.content.text = model.content;
        }break;
            /// 温度
        case HHHomeModel_temperature:{
            // 数字动画 格式
            self.content.formatBlock = ^NSString* (CGFloat value){
                return [NSString stringWithFormat:@"%.1f",value];
            };
            /// 设置值
            [self.content countFromCurrentValueTo:[model.content floatValue] withDuration:1.0];
        }break;
            /// 湿度
        case HHHomeModel_humidity:{
            // 数字动画 格式
            self.content.formatBlock = ^NSString* (CGFloat value){
                return [NSString stringWithFormat:@"%.2f",value];
            };
            /// 设置值
            [self.content countFromCurrentValueTo:[model.content floatValue] withDuration:1.0];
        }break;
            /// 压力
        case HHHomeModel_pressure:{
            // 数字动画 格式
            self.content.formatBlock = ^NSString* (CGFloat value){
                return [NSString stringWithFormat:@"%.0f",value];
            };
            /// 设置值
            [self.content countFromCurrentValueTo:[model.content floatValue] withDuration:1.0];
        }break;
            /// 位置
        case HHHomeModel_address:{
            // 数字动画 格式
            self.content.formatBlock = ^NSString* (CGFloat value){
                return [NSString stringWithFormat:@"%.0f",value];
            };
            /// 设置值
            self.content.text = model.content;
        }break;
        default:{
            // 数字动画 格式
            self.content.formatBlock = ^NSString* (CGFloat value){
                return [NSString stringWithFormat:@"%.0f",value];
            };
            self.content.text = model.content;
        }break;
    }
    

    
}








@end
