//
//  HHHomeCollectionViewCell.h
//  GasDetection
//
//  Created by 司月 on 2018/9/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYCountingLabel.h"
#import "HHHomeModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHHomeCollectionViewCell : UICollectionViewCell

/// 北京View
@property (weak, nonatomic) IBOutlet UIView *backView;

/// 图片
@property (weak, nonatomic) IBOutlet UIImageView *pic;

/// 标题
@property (weak, nonatomic) IBOutlet UILabel *title;

/// 内容
@property (weak, nonatomic) IBOutlet SYCountingLabel *content;


/// 赋值model
@property (nonatomic,strong)HHHomeModel *model;







@end

NS_ASSUME_NONNULL_END
