//
//  SYNeuronsView.h
//  SYNeuronsView
//
//  Created by 司月 on 2017/8/8.
//  Copyright © 2017年 司月. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SYNeuronsBallView.h"


@interface SYNeuronsView : UIView

@property(nonatomic,strong)NSMutableArray *array;


/// 开始
- (void)HHStart:(NSInteger)num;

/// 结束
- (void)HHEnd;





@end
