//
//  SYNeuronsBallView.h
//  SYNeuronsView
//
//  Created by 司月 on 2017/8/9.
//  Copyright © 2017年 司月. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYNeuronsBallView : UIView


- (void)animateWith:(UIView *)view;








@end











