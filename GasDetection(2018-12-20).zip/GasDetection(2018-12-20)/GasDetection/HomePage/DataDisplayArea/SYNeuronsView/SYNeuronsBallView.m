//
//  SYNeuronsBallView.m
//  SYNeuronsView
//
//  Created by 司月 on 2017/8/9.
//  Copyright © 2017年 司月. All rights reserved.
//

#import "SYNeuronsBallView.h"

@implementation SYNeuronsBallView

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self Initialize];
    }
    return self;
}
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize{
 
    self.backgroundColor = [UIColor clearColor];
    float w = [self random:0.5 to:2.5];
    self.frame = CGRectMake(0, 0, w, w);
    self.layer.cornerRadius = self.frame.size.width / 2;
//    self.layer.masksToBounds = YES;
    self.layer.borderWidth = self.frame.size.width / 5;
    self.layer.borderColor = [UIColor whiteColor].CGColor;

}


- (void)animateWith:(UIView *)view {
    
    CGPoint point = [self randomRectWith:view];
    self.frame = CGRectMake(point.x, point.y, self.frame.size.width, self.frame.size.height);
    
    __weak typeof(self) weakSelf = self;

    [UIView animateWithDuration:[self random:20 to:40] animations:^{
        // 动画结果执行动画
        CGPoint point1 = [weakSelf randomRectWith:view];
        weakSelf.frame = CGRectMake(point1.x, point1.y, weakSelf.frame.size.width, weakSelf.frame.size.height);
    }completion:^(BOOL finished) {
        // 动画完成后
        [weakSelf animateWith:view];
    }];
    
    
}




// 随机边框位置
- (CGPoint)randomRectWith:(UIView *)view{
    
    NSMutableArray *ranArr = [@[@"1",@"2",@"3",@"4"] mutableCopy];
    
    switch (self.tag) {
        case 1:
            [ranArr removeObjectAtIndex:0];
            break;
        case 2:
            [ranArr removeObjectAtIndex:1];
            break;
        case 3:
            [ranArr removeObjectAtIndex:2];
            break;
        case 4:
            [ranArr removeObjectAtIndex:3];
            break;
        default:
            break;
    }
    
    switch ([ranArr[[self random:0 to: ranArr.count - 1]] integerValue]) {
        case 1:
            //            NSLog(@"1");
            self.tag = 1;
            return CGPointMake([self random:-self.frame.size.width to:view.frame.size.width],
                               -self.frame.size.height);
        case 2:
            //            NSLog(@"2");
            self.tag = 2;
            return CGPointMake([self random:-self.frame.size.width to:view.frame.size.width],
                               view.frame.size.height);
        case 3:
            //            NSLog(@"3");
            self.tag = 3;
            return CGPointMake(-self.frame.size.width,
                               [self random:-self.frame.size.width to:view.frame.size.height]);
        case 4:
            //            NSLog(@"4");
            self.tag = 4;
            return CGPointMake(view.frame.size.width,
                               [self random:-self.frame.size.width to:view.frame.size.height]);
        default:
            return CGPointMake(0, 0);
    }
    
}

















/** 产生随机数区间 */
- (NSInteger)random:(NSInteger)from to:(NSInteger)to{
    return (NSInteger)(from + (arc4random() % (to - from + 1)));
}


/** 判断区间数 */
- (BOOL)IFInterval:(NSInteger)from to:(NSInteger)to Num:(NSInteger)num{
    if (num >= from && num <= to) {
        return YES;
    }else{
        return NO;
    }
}












@end
