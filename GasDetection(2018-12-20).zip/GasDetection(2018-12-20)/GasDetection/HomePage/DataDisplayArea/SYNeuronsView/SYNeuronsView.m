//
//  SYNeuronsView.m
//  SYNeuronsView
//
//  Created by 司月 on 2017/8/8.
//  Copyright © 2017年 司月. All rights reserved.
//

#import "SYNeuronsView.h"

@implementation SYNeuronsView

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self Initialize];
    }
    return self;
}
-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self Initialize];
    }
    return self;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize{
    self.layer.masksToBounds = YES; // 边框外不显示
//    self.backgroundColor = [UIColor whiteColor];
    
//    __weak typeof(self) weakSelf = self;

    /// 开始
//    [self HHStart:100];
}


/// 开始
- (void)HHStart:(NSInteger)num {
    
    __weak typeof(self) weakSelf = self;

    if (!self.array) {
        NSMutableArray *array = [NSMutableArray new];
        self.array = array;
    }else {
        [self.array removeAllObjects];
    }
    
    for (int i = 0; i < num; i++) {
        //--- 加载延迟
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)([self random:0 to:30] * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            SYNeuronsBallView *ball = [SYNeuronsBallView new];
            ball.tag = i;
//            [ball.backgroundView setTitle:[NSString stringWithFormat:@"%d",i] forState:UIControlStateNormal];
            [weakSelf addSubview:ball];
            
            [weakSelf.array addObject:ball];
            
            [ball animateWith:weakSelf];
        });
    }
}


/// 结束
- (void)HHEnd {
    
    for (SYNeuronsBallView *ball in self.array) {
        
        [ball removeFromSuperview];
        
    }
    
    [self.array removeAllObjects];
}




/** 产生随机数区间 */
- (NSInteger)random:(NSInteger)from to:(NSInteger)to{
    return (NSInteger)(from + (arc4random() % (to - from + 1)));
}


















@end
