//
//  HHDisplayDataView.m
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHDisplayDataView.h"

@interface HHDisplayDataView ()


@end

@implementation HHDisplayDataView

/// 数据赋值
- (void)setBluetoothModel:(HHBluetoothModel *)bluetoothModel {
    _bluetoothModel = bluetoothModel;

    /// 设置值
    [self.sensor1TextField countFromCurrentValueTo:bluetoothModel.sensor1_float withDuration:1.0];
//    /// 设置值
    [self.sensor2TextField countFromCurrentValueTo:bluetoothModel.sensor2_float withDuration:1.0];
    

    ///  更新图表
    [self HHUpdata:bluetoothModel];
    
    
    NSString *str = [NSString stringWithFormat:@"原始数据:%@\n传感器1:%.2f\n传感器2:%.2f\n",bluetoothModel.originalData,bluetoothModel.sensor1_float,bluetoothModel.sensor2_float];
    
    self.test.text = str;

    
}

/// 初始化
+ (HHDisplayDataView *)HHInit {
    HHDisplayDataView *tool = (HHDisplayDataView *)[[[NSBundle mainBundle] loadNibNamed:@"HHDisplayDataView" owner:self options:nil] lastObject];
    if (tool) {
        [tool Initialize];
    }
    return tool;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize {
    
    self.top.constant = 20;

    // 数字动画 格式
    self.sensor1TextField.formatBlock = ^NSString* (CGFloat value){
        return [NSString stringWithFormat:@"%.2f",value];
    };
    // 数字动画 格式
    self.sensor2TextField.formatBlock = ^NSString* (CGFloat value){
        return [NSString stringWithFormat:@"%.2f",value];
    };
    
}


/// frame 发生改变
- (void)layoutSubviews {
    
    [super layoutSubviews];

    self.chartView.clipsToBounds = YES;
    self.chartView.layer.cornerRadius = 10;

    self.chartBackView.layer.cornerRadius = 10;
    self.chartBackView.layer.shadowColor = [UIColor blackColor].CGColor;
    self.chartBackView.layer.shadowOffset = CGSizeMake(2, 5);
    self.chartBackView.layer.shadowOpacity = 0.2;
    self.chartBackView.layer.shadowRadius = 5;
    self.chartBackView.clipsToBounds = NO;

}



// 销毁时
- (void)dealloc {
    
    // 移除观察者，Observer不能为nil
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}





/// 更新图表
- (void)HHUpdata:(HHBluetoothModel *)bluetoothModel {
    
    if (self.chartView.isTouch == YES) {
        return;
    }
  
    if (self.chartView.xLabrlArray.count > 100) {
        [self.chartView.xLabrlArray removeObjectAtIndex:0];
    }
    if (self.chartView.xDataArray.count > 100) {
        [self.chartView.xDataArray removeObjectAtIndex:0];
    }
    
    if (self.histogram.xLabrlArray.count > 100) {
        [self.histogram.xLabrlArray removeObjectAtIndex:0];
    }
    if (self.histogram.xDataArray.count > 100) {
        [self.histogram.xDataArray removeObjectAtIndex:0];
    }

    NSNumberFormatter *numberF = [NSNumberFormatter new];
    numberF.numberStyle = NSNumberFormatterDecimalStyle;
    // 小数位最多位数
    numberF.maximumFractionDigits = 2;

    
    /// x标签数据数组
    [self.chartView.xLabrlArray addObject:[bluetoothModel.recordingTime HHDateTime:@"HH:mm:ss"]];
    /// x数据数组
    [self.chartView.xDataArray addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",bluetoothModel.sensor1_float]]];
    
    /// x标签数据数组
    [self.histogram.xLabrlArray addObject:[bluetoothModel.recordingTime HHDateTime:@"HH:mm:ss"]];
    /// x数据数组
    [self.histogram.xDataArray addObject:@[[numberF numberFromString:[NSString stringWithFormat:@"%.2f",0 - bluetoothModel.sensor2_float]],
                                           [numberF numberFromString:[NSString stringWithFormat:@"%.2f",bluetoothModel.sensor2_float]]]];
    
    
    /// x 轴刻度点间隔数(设置每隔几个点显示一个 X轴的内容)
    self.chartView.chartModel.xAxisTickIntervalSet(@10);
    /// x 轴刻度点间隔数(设置每隔几个点显示一个 X轴的内容)
    self.histogram.chartModel.xAxisTickIntervalSet(@10);
    

    // 更新 AAChartModel 数据之后,刷新图表
    [self.chartView aa_refreshChartWithChartModel:self.chartView.chartModel];
    
    // 更新 AAChartModel 数据之后,刷新图表
    [self.histogram aa_refreshChartWithChartModel:self.histogram.chartModel];
    
    /// 只刷新图表数据的功能
//    [self aa_onlyRefreshTheChartDataWithChartModelSeries:@[@{@"categories":self.xLabrlArray,@"data":self.xDataArray}]];
    

}





@end
