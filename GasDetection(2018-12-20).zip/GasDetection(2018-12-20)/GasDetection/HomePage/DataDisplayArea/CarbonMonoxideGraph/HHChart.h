//
//  HHChart.h
//  GasDetection
//
//  Created by 司月 on 2018/9/25.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AAChartView.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHChart : AAChartView

/// 曲线图配置
@property(nonatomic,strong)AAChartModel *chartModel;

/// 数据配置
@property(nonatomic,strong)AASeriesElement *sseriesElement;


/// x标签数据数组
@property(nonatomic,strong)NSMutableArray *xLabrlArray;
/// x数据数组
@property(nonatomic,strong)NSMutableArray *xDataArray;



/// 判断是否触摸中
@property (nonatomic,assign)BOOL isTouch;

/// 记录上次数据数量
@property (nonatomic,assign)NSInteger num;


@end

NS_ASSUME_NONNULL_END
