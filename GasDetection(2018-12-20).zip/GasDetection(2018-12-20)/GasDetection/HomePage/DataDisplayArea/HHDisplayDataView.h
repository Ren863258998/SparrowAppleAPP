//
//  HHDisplayDataView.h
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UINavigationBar+Custom.h"
#import "SYCircleSlider.h"
#import "SYCountingTextField.h"
#import "HHChart.h"
#import "HHO3Histogram.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHDisplayDataView : UIView

/// 初始化
+ (HHDisplayDataView *)HHInit;

/// 安全区高度
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *top;

/// 传感器1
@property (weak, nonatomic) IBOutlet SYCountingTextField *sensor1TextField;

/// 传感器2
@property (weak, nonatomic) IBOutlet SYCountingTextField *sensor2TextField;


/// O3柱状图
@property (weak, nonatomic) IBOutlet HHO3Histogram *histogram;

/// 曲线图
@property (weak, nonatomic) IBOutlet HHChart *chartView;
@property (weak, nonatomic) IBOutlet UIView *chartBackView;

@property (weak, nonatomic) IBOutlet UITextView *test;


/// 蓝牙数据model
@property (nonatomic,strong)HHBluetoothModel *bluetoothModel;




@end

NS_ASSUME_NONNULL_END
