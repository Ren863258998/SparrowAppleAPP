//
//  HHHomeViewController.m
//  GasDetection
//
//  Created by 司月 on 2018/8/14.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHomeViewController.h"
#import "UIBarButtonItem+Block.h"
#import "HHHomeViewController+Tool.h"       // 首页工具类
#import "GasDetectionCoreDataTool.h"        // 数据库工具
#import "HHHomeViewController+CollectionView.h" // 网格视图工具
#import "HHBluetoothSearchViewController.h"     // 蓝牙搜索界面


@interface HHHomeViewController ()



@end

@implementation HHHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    __weak typeof(self) weakSelf = self;
    
    // 导航条右按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem new] HHPic:@"bluetoothSearch" Block:^(UIBarButtonItem *item) {
        
        if (![[HHBluetoothManager shared] peripheral]) {
            /// 弹出搜索蓝牙界面
            HHBluetoothSearchViewController *bsVc = [HHBluetoothSearchViewController HHPresentViewController:weakSelf.tabBarController];
            bsVc.ActionBlock = ^(CBPeripheral * _Nonnull peripheral) {
                /// 连接设备
                [weakSelf HHConnectPeripheral:peripheral];
            };
            return;
        }
        
        
        // 1.创建UIAlertController
        HHAlertController *alertController = [HHAlertController alertControllerWithTitle:nil message:NSLocalizedString(@"是否断开当前连接？",@"OK") preferredStyle:UIAlertControllerStyleAlert];

        // 2.2  创建 取消 确认 按钮
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"取消",@"OK") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        UIAlertAction *loginAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"确认",@"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            /// 断开连接
            [[HHBluetoothManager shared] HHDisconnectPeripheral];
            
            /// 弹出搜索蓝牙界面
            HHBluetoothSearchViewController *bsVc = [HHBluetoothSearchViewController HHPresentViewController:weakSelf.tabBarController];
            bsVc.ActionBlock = ^(CBPeripheral * _Nonnull peripheral) {
                /// 连接设备
                [weakSelf HHConnectPeripheral:peripheral];
            };
        }];
        // 2.3 添加按钮
        [alertController addAction:cancelAction];
        [alertController addAction:loginAction];
        // 3.显示警报控制器
        [self presentViewController:alertController animated:YES completion:nil];
        
        
    }];

    
    /// 监听蓝牙状态
    [self HHCentralManagerDidUpdateState];
    
    /// 分区头
    self.displayDataView = [HHDisplayDataView HHInit];
    
    /// 初始化collectionView
    [self HHGridView];
    
    CGFloat height = [[UIApplication sharedApplication] statusBarFrame].size.height + self.navigationController.navigationBar.frame.size.height;
    
    /// 初始化下啦放大view
    self.picView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"back_image"]];
    self.picView.frame = CGRectMake(0, 0 - height, self.view.frame.size.width, self.view.frame.size.height * 0.65);
    [self.collectionView addSubview:self.picView];
    
    
    
    
    /// 初始化计时器 测试数据
//    [self HHInitTimer_test];
}

// 加载
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    [self scrollViewDidScroll:self.collectionView];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}

// 重置
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.navigationController.navigationBar reset];
}

// 监听
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    UIColor *color = [UIColor colorWithRed:0.463 green:0.878 blue:0.882 alpha:1.000];
    
    CGFloat offsetY = scrollView.contentOffset.y;
    if (offsetY > [[UIApplication sharedApplication] statusBarFrame].size.height - self.navigationController.navigationBar.frame.size.height) {
        CGFloat alpha = MIN(1, 1 - (([[UIApplication sharedApplication] statusBarFrame].size.height - self.navigationController.navigationBar.frame.size.height + 64 - offsetY) / 64));
        
        [self.navigationController.navigationBar setBackgroundColor:[color colorWithAlphaComponent:alpha]];
    } else {
        [self.navigationController.navigationBar setBackgroundColor:[color colorWithAlphaComponent:0]];
    }
    
    CGFloat yOffset = scrollView.contentOffset.y;
    if (yOffset < 0) {
        CGFloat totalOffset = self.view.frame.size.height * 0.65 + ABS(yOffset);
        self.picView.frame = CGRectMake(0, yOffset, self.displayDataView.frame.size.width, totalOffset);
    }
}



// 销毁时
- (void)dealloc {
    
    // 移除观察者，Observer不能为nil
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}



@end
