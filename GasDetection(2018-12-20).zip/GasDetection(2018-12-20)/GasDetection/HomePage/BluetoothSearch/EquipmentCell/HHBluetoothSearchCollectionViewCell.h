//
//  HHBluetoothSearchCollectionViewCell.h
//  GasDetection
//
//  Created by 司月 on 2018/8/15.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHBluetoothSearchCollectionViewCell : UICollectionViewCell

/// 设备名称
@property (weak, nonatomic) IBOutlet UILabel *name;

/// 设备图片
@property (weak, nonatomic) IBOutlet UIImageView *pic;

/// 设备uuid
@property (weak, nonatomic) IBOutlet UILabel *uuid;


/// 当前显示的外围设备
@property (nonatomic,strong)CBPeripheral *peripheral;


@end

NS_ASSUME_NONNULL_END
