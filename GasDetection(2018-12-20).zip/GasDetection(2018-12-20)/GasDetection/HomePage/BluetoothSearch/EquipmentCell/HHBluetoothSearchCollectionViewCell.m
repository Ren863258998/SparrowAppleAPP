
//
//  HHBluetoothSearchCollectionViewCell.m
//  GasDetection
//
//  Created by 司月 on 2018/8/15.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHBluetoothSearchCollectionViewCell.h"

@implementation HHBluetoothSearchCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.clipsToBounds = YES;
    self.layer.cornerRadius = 10;
}


/// 赋值当前显示的设备
- (void)setPeripheral:(CBPeripheral *)peripheral {
    
    self.name.text = peripheral.name;
    
    self.uuid.text = peripheral.identifier.UUIDString;
    
    
}








@end
