//
//  HHBluetoothSearchViewController.h
//  GasDetection
//
//  Created by 司月 on 2018/8/15.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHBluetoothSearchViewController : HHViewController

/// 底图View
@property (weak, nonatomic) IBOutlet UIView *backView;

/// 网格视图
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

/// 连接按钮
@property (weak, nonatomic) IBOutlet UIButton *connectionButton;

/// 关闭按钮
@property (weak, nonatomic) IBOutlet UIButton *clostButton;



/// 存储已经扫描到的设备
@property (nonatomic,strong)NSMutableArray<CBPeripheral *> *peripherals;


/// 模态显示
+ (HHBluetoothSearchViewController *)HHPresentViewController:(UIViewController *)viewController;


/// 模态显示
- (void)HHPresentViewController:(UIViewController *)viewController;

/// 插入一个新设备
- (void)HHInsertPeripheral:(CBPeripheral *)peripheral;


/// 点击属性block
@property (nonatomic,strong)void (^ActionBlock)(CBPeripheral *peripheral);


@end

NS_ASSUME_NONNULL_END
