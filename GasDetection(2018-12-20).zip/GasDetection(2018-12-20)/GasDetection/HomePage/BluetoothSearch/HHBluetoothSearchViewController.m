//
//  HHBluetoothSearchViewController.m
//  GasDetection
//
//  Created by 司月 on 2018/8/15.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHBluetoothSearchViewController.h"
#import "UIScrollView+EmptyDataSet.h"
#import "HHBluetoothSearchCollectionViewCell.h"

@interface HHBluetoothSearchViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>

@end

@implementation HHBluetoothSearchViewController


/// 模态显示
+ (HHBluetoothSearchViewController *)HHPresentViewController:(UIViewController *)viewController {
    
    // 初始化
    HHBluetoothSearchViewController *bsVc = [HHBluetoothSearchViewController new];
    // 设置模态底图
    bsVc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    // 设置动画效果
    bsVc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    // 模态显示
    [viewController presentViewController:bsVc animated:YES completion:nil];
    
    return bsVc;
}

/// 模态显示
- (void)HHPresentViewController:(UIViewController *)viewController {
    // 设置模态底图
    self.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    // 设置动画效果
    self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    // 模态显示
    [viewController presentViewController:self animated:YES completion:nil];
}


// 视图将要显示
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    
    __weak typeof(self) weakSelf = self;
    
    /// 临时保存frame
    CGRect frame_temp = self.backView.frame;
    
    /// 将View的frame设置到屏幕外
    self.backView.frame = CGRectMake(frame_temp.origin.x, self.view.frame.size.height, frame_temp.size.width, frame_temp.size.height);
    
    // 动画
    [UIView animateWithDuration:0.2 animations:^{
        weakSelf.backView.frame = frame_temp;
    }];
    
}
// 试图已经出现
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];

}

// 视图将要消失
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    __weak typeof(self) weakSelf = self;
    
    // 动画
    [UIView animateWithDuration:0.2 animations:^{
        /// 将View的frame设置到屏幕外
        weakSelf.backView.frame = CGRectMake(weakSelf.backView.frame.origin.x, weakSelf.view.frame.size.height, weakSelf.backView.frame.size.width, weakSelf.backView.frame.size.height);
    }];
}

// 视图已经消失
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
}



/// 初始化
- (void)viewDidLoad {
    [super viewDidLoad];

    /// 初始背景色
//    self.view.backgroundColor = [UIColor clearColor];

    // 设置视图圆角
    self.backView.clipsToBounds = YES;
    self.backView.layer.cornerRadius = 20;

    // 设置按钮圆角
    self.connectionButton.clipsToBounds = YES;
    self.connectionButton.layer.cornerRadius = 10;

    // 占位代理
    self.collectionView.emptyDataSetSource = self;
    self.collectionView.emptyDataSetDelegate = self;
    
    
    // 网格视图代理
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    
    // 整页滑动
    self.collectionView.pagingEnabled = YES;
    // 是否允许超出滑动范围
//    self.collectionView.alwaysBounceVertical = YES;
    // 背景色
    self.collectionView.backgroundColor = [UIColor clearColor];
    
    
    // 注册类，是用纯代码生成的collectiviewcell类才行
    [self.collectionView registerNib:[UINib nibWithNibName:@"HHBluetoothSearchCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"HHBluetoothSearchCollectionViewCell"];
  
    
    /// 自定义的布局对象
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    // 设置UICollectionView为横向滚动
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    // 设置每个cell上下左右相距
    layout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    // 设置最小行间距，也就是前一行与后一行的中间最小间隔
    layout.minimumLineSpacing = 0;
    // 设置最小列间距，也就是左行与右一行的中间最小间隔
    layout.minimumInteritemSpacing = 0;
    // 设置每个cell大小
    layout.itemSize = CGSizeMake(self.collectionView.frame.size.width,self.collectionView.frame.size.height);
    // 改变layout
    [self.collectionView setCollectionViewLayout:layout animated:NO];

    
    
    /// 初始化储存蓝牙数组
    if (!self.peripherals) {
        NSMutableArray<CBPeripheral *> *peripherals = [NSMutableArray new];
        self.peripherals = peripherals;
    }
    
    
    /// 扫描设备
    [self HHScanningEquipment];
}


/// 关闭按钮点击事件
- (IBAction)closeButtonAction:(UIButton *)sender {
 
    /// 停止扫描
    [[HHBluetoothManager shared] HHStopScan];
    
    // 关闭当前视图
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

/// 连接按钮点击事件
- (IBAction)connectionButtonAction:(UIButton *)sender {
    
//    __weak typeof(self) weakSelf = self;
    
    
    // 获取当前显示cell 标记
    NSIndexPath *indexPath = self.collectionView.indexPathsForVisibleItems.firstObject;
    
    CBPeripheral *peripheral = self.peripherals[indexPath.row];
    
    NSLog(@"连接设备%@",peripheral.name);
    
    // block 回调
    if (self.ActionBlock) {
        
        self.clostButton.enabled = NO;
        
        self.ActionBlock(peripheral);
        /// 关闭按钮点击事件
        [self closeButtonAction:nil];
    }

}



/// 占位图
- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
    return [UIImage imageNamed:@"icon_list_empty.png"];
}

/// 占位文字
- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView {
    NSString *title = NSLocalizedString(@"请长按设备可搜索键～",@"OK");
    NSDictionary *attributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:16.0f],NSForegroundColorAttributeName:RGBColor(206, 206, 206)};
    return [[NSAttributedString alloc] initWithString:title attributes:attributes];
}





#pragma mark - UICollectionViewDataSource

/// 指定Section个数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

/// 指定section中的collectionViewCell的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.peripherals.count;
}

/// 配置section中的collectionViewCell的显示
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
   
    HHBluetoothSearchCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HHBluetoothSearchCollectionViewCell" forIndexPath:indexPath];
    
    cell.peripheral = self.peripherals[indexPath.row];

    return cell;
}





/// 插入一个新设备
- (void)HHInsertPeripheral:(CBPeripheral *)peripheral {
    
    __weak typeof(self) weakSelf = self;
    
    // 在主线程更新
    dispatch_async(dispatch_get_main_queue(), ^{
 
        /// 插入数组
        [weakSelf.peripherals addObject:peripheral];
        /// 刷新网格视图
        [weakSelf.collectionView reloadData];
        // 刷新占位图
        [weakSelf.collectionView reloadEmptyDataSet];
        

        // 判断当前搜索到的设备大于一个则 不允许用户点击 连接按钮 将连接按钮 显示 请选择设备连接
        if (weakSelf.peripherals.count > 1 && weakSelf.collectionView.indexPathsForSelectedItems.count == 0) {
            [weakSelf.connectionButton setTitle:NSLocalizedString(@"横向滑动选择设备连接",@"OK") forState:UIControlStateNormal];
        }

        if (weakSelf.peripherals.count > 0) {
            weakSelf.connectionButton.enabled = YES;
        }else {
            weakSelf.connectionButton.enabled = NO;
        }
        
    });
}



/// 扫描设备
- (void)HHScanningEquipment {
    
    __weak typeof(self) weakSelf = self;
    
    
    /// 初始化蓝牙管理类
    HHBluetoothManager *bluetoothManager = [HHBluetoothManager shared];
    
    /// 扫描外围设备
    [bluetoothManager HHScanningEquipment:^(CBPeripheral * _Nonnull peripheral_temp, NSNumber * _Nonnull RSSI_temp, BOOL isAuto) {
        // 在主线程更新
        dispatch_async(dispatch_get_main_queue(), ^{
            // 判断是否已经存在于 扫描数组 如果不存在 则是发现新设备
            if (![self.peripherals containsObject:peripheral_temp]) {
                
                NSLog(@"设备名:%@-信号:%@",peripheral_temp.name,RSSI_temp);
                
                /// 插入一个新设备
                [weakSelf HHInsertPeripheral:peripheral_temp];
                
                
            }else {
                
                // 已经存在的更新数据
                NSInteger index = [weakSelf.peripherals indexOfObject:peripheral_temp];
                weakSelf.peripherals[index] = peripheral_temp;
                
            }
        });
    }];
    
    
    
}






// 内存警告
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    NSLog(@"⚠️收到内存警告_蓝牙搜索");
}

// 销毁时
- (void)dealloc {
    NSLog(@"✅销毁了_蓝牙搜索");

}


@end
