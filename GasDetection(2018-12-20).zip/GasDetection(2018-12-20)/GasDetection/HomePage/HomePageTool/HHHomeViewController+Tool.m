//
//  HHHomeViewController+Tool.m
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHomeViewController+Tool.h"
#import "HHBluetoothSearchViewController.h" // 蓝牙搜索界面

@implementation HHHomeViewController (Tool)


/// 监听蓝牙状态
- (void)HHCentralManagerDidUpdateState {
    
    __weak typeof(self) weakSelf = self;
    
    // 获取通知中心单例
    NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
    
    // 接收通知
    [notiCenter addObserverForName:@"HHCentralManagerDidUpdateState" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        
        // 判断计时器如果存在 则销毁 重新创建
        if (weakSelf.time) {[weakSelf.time invalidate];}
        
        // 获取蓝牙状态
        CBCentralManager *central_temp = note.object;
        
        switch (central_temp.state) {
            case CBManagerStateUnknown:{
                [HHAlertController HHErrorNew:NSLocalizedString(@"蓝牙状态错误",@"OK") Message:NSLocalizedString(@"未知状态",@"OK") ViewController:weakSelf ActionBlock:nil];
            }break;
            case CBManagerStateResetting:{
                [HHAlertController HHErrorNew:NSLocalizedString(@"蓝牙状态错误",@"OK") Message:NSLocalizedString(@"重置状态",@"OK") ViewController:weakSelf ActionBlock:nil];
            }break;
            case CBManagerStateUnsupported:{
                [HHAlertController HHErrorNew:NSLocalizedString(@"蓝牙状态错误",@"OK") Message:NSLocalizedString(@"不支持的状态",@"OK") ViewController:weakSelf ActionBlock:nil];
            }break;
            case CBManagerStateUnauthorized:{
                [HHAlertController HHErrorNew:NSLocalizedString(@"蓝牙状态错误",@"OK") Message:NSLocalizedString(@"未授权的状态",@"OK") ViewController:weakSelf ActionBlock:nil];
            }break;
            case CBManagerStatePoweredOff:{
                [HHAlertController HHErrorNew:NSLocalizedString(@"蓝牙状态错误",@"OK") Message:NSLocalizedString(@"关闭状态",@"OK") ViewController:weakSelf ActionBlock:nil];
            }break;
            case CBManagerStatePoweredOn:{
                
                /// 扫描设备
                [weakSelf HHScanningEquipment];
                
            }break;default:break;
        }
        
    }];
    
}

/// 扫描设备
- (void)HHScanningEquipment {
    
    __weak typeof(self) weakSelf = self;
    
    /// 判断是否有自动连接设备
    if ([[[GasDetectionCoreDataTool shared] HHReadDataSettingForm] equipmentUUID].UUIDString.length > 5) {
        NSLog(@"有自动连接设备");

        // 添加HUD
        __block MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.tabBarController.view animated:YES];
        // 水平进度条
        hud.mode = MBProgressHUDModeIndeterminate;
        hud.label.text = [NSString stringWithFormat:NSLocalizedString(@"正在连接设备～",@"NO")];
        hud.detailsLabel.text = @"\n";
        
        [hud.button setTitle:NSLocalizedString(@"取消",@"NO") forState:UIControlStateNormal];
        [hud.button HHHandleClickEvent:UIControlEventTouchUpInside withClickBlock:^{
            // 在主线程更新
            dispatch_async(dispatch_get_main_queue(), ^{
                [hud hideAnimated:YES];
                [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"请手动连接～",@"NO")];
            });
            /// 停止扫描
            [[HHBluetoothManager shared] HHStopScan];
        }];
        
        
        /// 扫描外围设备
        [[HHBluetoothManager shared] HHScanningEquipment:^(CBPeripheral * _Nonnull peripheral_temp, NSNumber * _Nonnull RSSI_temp, BOOL isAuto) {
            // 如果是自动连接设备直接连接
            if (isAuto == YES) {
                
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    [hud hideAnimated:YES];
                });
                
                /// 连接设备
                [weakSelf HHConnectPeripheral:peripheral_temp];
            }
        }];
        
        return;
    }
    

    /// 弹出搜索蓝牙界面
    HHBluetoothSearchViewController *bsVc = [HHBluetoothSearchViewController HHPresentViewController:weakSelf.tabBarController];
    bsVc.ActionBlock = ^(CBPeripheral * _Nonnull peripheral) {
        /// 连接设备
        [weakSelf HHConnectPeripheral:peripheral];
    };
    
}


/// 连接设备
- (void)HHConnectPeripheral:(CBPeripheral *)peripheral {
    
    __weak typeof(self) weakSelf = self;
    
    [SVProgressHUD showWithStatus:NSLocalizedString(@"正在连接设备～",@"NO")];

    /// 停止扫描
    [[HHBluetoothManager shared] HHStopScan];
    
    /// 连接设备
    [[HHBluetoothManager shared] HHConnectPeripheral:peripheral Successful:^(CBPeripheral * _Nonnull peripheral_temp) {
        
        [SVProgressHUD showSuccessWithStatus:NSLocalizedString(@"设备连接成功～",@"NO")];

        /// 初始化计时器
        [weakSelf HHInitTimer];
        
    } Failure:^(CBPeripheral * _Nonnull peripheral_temp, NSError * _Nonnull error_temp) {
        
        [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"设备连接失败～",@"NO")];

        /// 重新扫描设备
        [weakSelf HHScanningEquipment];
        
        
        // 判断计时器如果存在 则销毁 重新创建
        if (weakSelf.time) {[weakSelf.time invalidate];}
        
    } Disconnect:^(CBPeripheral * _Nonnull peripheral_temp, NSError * _Nonnull error_temp) {
        
        [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"设备断开连接～",@"NO")];
        
        /// 重新扫描设备
        [weakSelf HHScanningEquipment];
        
        
        // 判断计时器如果存在 则销毁 重新创建
        if (weakSelf.time) {[weakSelf.time invalidate];}
    }];

}






/// 初始化计时器
- (void)HHInitTimer {
    
    __weak typeof(self) weakSelf = self;

    
    /// 判断是否获取到主板的信息
    if (!self.hardwareModel) {
        
        [SVProgressHUD showWithStatus:NSLocalizedString(@"获取硬件信息～",@"NO")];

        /// 写入值 e 获取硬件信息
        [[HHBluetoothManager shared] HHWriteValue_e:^(HHHardwareModel * _Nonnull hardwareModel) {
            
            [SVProgressHUD showSuccessWithStatus:NSLocalizedString(@"获取硬件信息成功～",@"NO")];
            
            weakSelf.hardwareModel = hardwareModel;
            
            NSInteger history_count = [weakSelf.hardwareModel.history_count integerValue];

            
            /// 判断数据库中是否有数据 没有数据 无法计算时间，将数据丢弃
            if ([[[GasDetectionCoreDataTool shared] HHReadDataHistoricalData_All] count] <= 0) {
                /// 写入值 L 删除硬件历史数据
                [[HHBluetoothManager shared] HHWriteValue_L];
                
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    /// 初始化计时器
                    [weakSelf HHInitTimer];
                });
                return ;
            }
            
            // 添加HUD
            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:weakSelf.tabBarController.view animated:YES];
            // 将文本模式设置为只显示文本
            hud.mode = MBProgressHUDModeDeterminateHorizontalBar;
            hud.label.text = NSLocalizedString(@"正在读取设备文件",@"NO");
            
            [hud.button setTitle:NSLocalizedString(@"取消",@"NO") forState:UIControlStateNormal];
            
            [hud.button HHHandleClickEvent:UIControlEventTouchUpInside withClickBlock:^{
                
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    // 删除HUD
                    [hud hideAnimated:YES];
                });
                
                /// 写入值 l
                [[HHBluetoothManager shared] HHWriteValue_l];
                
                [HHAlertController HHNew:NSLocalizedString(@"提示",@"NO") Message:NSLocalizedString(@"是否删除主板数据",@"NO") ViewController:weakSelf CancelBlock:^{
                    
                    // 在主线程更新
                    dispatch_async(dispatch_get_main_queue(), ^{
                        /// 初始化计时器
                        [weakSelf HHInitTimer];
                    });
                    
                } ActionBlock:^{
                    /// 写入值 L 删除硬件历史数据
                    [[HHBluetoothManager shared] HHWriteValue_L];
                    
                    // 在主线程更新
                    dispatch_async(dispatch_get_main_queue(), ^{
                        /// 初始化计时器
                        [weakSelf HHInitTimer];
                    });
                }];
                

            }];
            
            /// 写入值 l 获取主板历史数据
            [[HHBluetoothManager shared] HHWriteValue_l:history_count ProgressBlock:^(HHBluetoothModel * _Nonnull bluetoothModel,NSInteger index,NSInteger count) {
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    // 显示删除中的文件
                    hud.detailsLabel.text = [NSString stringWithFormat:@"%ld/%ld",index,count];
                    hud.progress = index*1.0 / count*1.0;
                });
            } block:^(NSMutableArray<HHBluetoothModel *> * _Nonnull bluetoothArr) {
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    // 删除HUD
                    [hud hideAnimated:YES];
                });
                
                if (bluetoothArr.count <= 0) {
                    /// 初始化计时器
                    [weakSelf HHInitTimer];
                    return ;
                }
                
                [SVProgressHUD showWithStatus:NSLocalizedString(@"保存历史数据～",@"NO")];
                
                for (HHBluetoothModel *model in bluetoothArr) {
                    /// 初始化数据库 将数据保存到数据库
                    [[GasDetectionCoreDataTool shared] HHInsertDataHistoricalDataDay:model];
                }
                
                /// 写入值 L 删除硬件历史数据
                [[HHBluetoothManager shared] HHWriteValue_L];
                
                [SVProgressHUD dismiss];
                
                /// 初始化计时器
                [weakSelf HHInitTimer];
            }];
            
        }];
        
        return;
    }
    
    
    // 判断计时器如果存在 则销毁 重新创建
    if (self.time) {
        [self.time invalidate];
        self.time = nil;
    }
    
    // 获取系统设置频率
    CGFloat frequency = [[GasDetectionCoreDataTool shared] HHReadDataSettingForm].frequency;
    
    /// 初始化计时器
    SYTimeBlock *time = [SYTimeBlock SYScheduledTimerWithTimeInterval:frequency repeats:0 block:^(SYTimeBlock *timer) {
//        NSLog(@"计时器被调用%ld",timer.num);
        
        /// 写入值 s 获取当前监测数据
        [[HHBluetoothManager shared] HHWriteValue_s:^(HHBluetoothModel * _Nonnull bluetoothModel) {
            
            // 在主线程更新
            dispatch_async(dispatch_get_main_queue(), ^{
                
                // 赋值 刷新界面数据
                weakSelf.displayDataView.bluetoothModel = bluetoothModel;
                
                /// 初始化数据库 将数据保存到数据库
                [[GasDetectionCoreDataTool shared] HHInsertDataHistoricalDataDay:bluetoothModel];
                
                /// 打印model所有值
//                [bluetoothModel HHLogModelAll];

            });
            
        }];
        
        // 判断 如果 系统设置时间间隔 更改 则重新赋值计时器 时间间隔
        if (timer.timeInterval != [[GasDetectionCoreDataTool shared] HHReadDataSettingForm].frequency) {
            NSLog(@"系统设置时间间隔 更改");
            // 赋值计时器时间间隔
            timer.timeInterval = [[GasDetectionCoreDataTool shared] HHReadDataSettingForm].frequency;
        }
    }];
    // 赋值计时器
    self.time = time;
    
}



/// 初始化计时器
- (void)HHInitTimer_test {
    
    __weak typeof(self) weakSelf = self;
    
    
    // 判断计时器如果存在 则销毁 重新创建
    if (self.time) {[self.time invalidate];}
    
    // 获取系统设置频率
    CGFloat frequency = [[GasDetectionCoreDataTool shared] HHReadDataSettingForm].frequency;
    
    /// 初始化计时器
    SYTimeBlock *time = [SYTimeBlock SYScheduledTimerWithTimeInterval:frequency repeats:0 block:^(SYTimeBlock *timer) {
//        NSLog(@"计时器被调用%ld",timer.num);
        
        // 在主线程更新
        dispatch_async(dispatch_get_main_queue(), ^{
            
            /// 初始化数组
            HHBluetoothModel *bluetoothModel = [HHBluetoothModel HHNew_test];

            // 赋值 刷新界面数据
            weakSelf.displayDataView.bluetoothModel = bluetoothModel;
            
            /// 初始化数据库 将数据保存到数据库
            [[GasDetectionCoreDataTool shared] HHInsertDataHistoricalDataDay:bluetoothModel];
            
            /// 打印model所有值
//            [bluetoothModel HHLogModelAll];
 
            // 获取通知中心单例
            NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
            // 发送通知
            [notiCenter postNotificationName:@"HHWriteValue_s" object:bluetoothModel userInfo:nil];
        });
        
        // 判断 如果 系统设置时间间隔 更改 则重新赋值计时器 时间间隔
        if (timer.timeInterval != [[GasDetectionCoreDataTool shared] HHReadDataSettingForm].frequency) {
            NSLog(@"系统设置时间间隔 更改");
            // 赋值计时器时间间隔
            timer.timeInterval = [[GasDetectionCoreDataTool shared] HHReadDataSettingForm].frequency;
        }
    }];
    // 赋值计时器
    self.time = time;
    
}



@end
