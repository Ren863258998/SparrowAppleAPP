//
//  HHHomeViewController+Tool.h
//  GasDetection
//
//  Created by 司月 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHomeViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHHomeViewController (Tool)

/// 监听蓝牙状态
- (void)HHCentralManagerDidUpdateState;

/// 扫描设备
- (void)HHScanningEquipment;

/// 连接设备
- (void)HHConnectPeripheral:(CBPeripheral *)peripheral;



/// 初始化计时器
- (void)HHInitTimer;

/// 初始化计时器 测试数据
- (void)HHInitTimer_test;

@end

NS_ASSUME_NONNULL_END
