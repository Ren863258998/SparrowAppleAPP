//
//  HHTabBarController.m
//  iPlore
//
//  Created by 司月 on 2018/2/11.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "HHTabBarController.h"

/// 首页
#import "HHHomeViewController.h"
/// 历史数据
#import "HHHistoryViewController.h"
/// 报警历史
#import "HHAlarmViewController.h"
/// 设置
#import "HHSettingViewController.h"


@interface HHTabBarController ()<UITabBarControllerDelegate,UITabBarDelegate>

@end

@implementation HHTabBarController

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// frame改变的时候
- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];

}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.delegate = self;

    
    // 设置标签栏 不透明
    self.tabBar.translucent = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    // 设置背景颜色
    self.tabBar.barTintColor = [UIColor whiteColor];
    // 设置文字颜色
    self.tabBar.tintColor = RGBColor( 49, 98, 177);
    // 未选中颜色
//    self.tabBar.unselectedItemTintColor = [UIColor redColor];

    
    // 设置HUD颜色类型
    [SVProgressHUD setMinimumDismissTimeInterval:0.5];
//    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeClear];


    
    /// 首页
    HHHomeViewController *homeVC = [HHHomeViewController new];
    [self HHAddOneChildVc:homeVC title:NSLocalizedString(@"首页",@"OK") image:@"gas-detection-home-icon" selectedImage:@"gas-detection-home-icon-selected"];
    
    /// 历史数据
    HHHistoryViewController *historyVC = [HHHistoryViewController new];
    [self addOneChildVc:historyVC title:NSLocalizedString(@"历史",@"OK") image:@"gas-detection-history-icon" selectedImage:@"gas-detection-history-icon-selected"];
    
    /// 报警历史
    HHAlarmViewController *alarmVC = [HHAlarmViewController new];
    [self addOneChildVc:alarmVC title:NSLocalizedString(@"报警",@"OK") image:@"gas-detection-notification-icon" selectedImage:@"gas-detection-notification-icon-selected"];
    
    /// 设置
    HHSettingViewController *settingVC = [HHSettingViewController new];
    [self addOneChildVc:settingVC title:NSLocalizedString(@"设置",@"OK") image:@"gas-detection-settings-icon" selectedImage:@"gas-detection-settings-icon-selected"];
    
 
}



//// 添加一个子控制器
- (void)addOneChildVc:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage {
    
    // 未选中文字颜色
//    [vc.tabBarItem  setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:10], NSFontAttributeName, [UIColor blackColor], NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    
    // 选中文字颜色
//    [vc.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:10], NSFontAttributeName, RGBColor(49, 98, 177), NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    
    
    // 同时设置tabbar每个标签的文字 和 navigationBar的文字
    vc.title = title;
    vc.tabBarItem.image = [UIImage imageNamed:image];
    vc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImage];
    
    // 这张图片按照原始的样子显示出来，不要自动渲染成其他颜色
    UIImage *newimage = [UIImage imageNamed:selectedImage];
    newimage = [newimage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.tabBarItem.selectedImage = newimage;
    
    
//    vc.view.backgroundColor = [UIColor redColor];
    
    // 包装一个导航控制器后,再成为tabbar的子控制器
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    
    
//    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"A_recommend_27_menubar_bg 720x86"] forBarMetrics:UIBarMetricsDefault];
    
    
    [self addChildViewController:nav];
}


//// 添加一个子控制器
- (void)HHAddOneChildVc:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage {
    
    // 未选中文字颜色
    //    [vc.tabBarItem  setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:10], NSFontAttributeName, [UIColor blackColor], NSForegroundColorAttributeName, nil] forState:UIControlStateNormal];
    
    // 选中文字颜色
    //    [vc.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont boldSystemFontOfSize:10], NSFontAttributeName, RGBColor(49, 98, 177), NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    
    
    // 同时设置tabbar每个标签的文字 和 navigationBar的文字
    vc.title = title;
    vc.tabBarItem.image = [UIImage imageNamed:image];
    vc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImage];
    
    // 这张图片按照原始的样子显示出来，不要自动渲染成其他颜色
    UIImage *newimage = [UIImage imageNamed:selectedImage];
    newimage = [newimage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.tabBarItem.selectedImage = newimage;
    
    
    //    vc.view.backgroundColor = [UIColor redColor];
    
    // 包装一个导航控制器后,再成为tabbar的子控制器
    HHNavigationController *nav = [[HHNavigationController alloc] initWithRootViewController:vc];
    
    
    //    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"A_recommend_27_menubar_bg 720x86"] forBarMetrics:UIBarMetricsDefault];
    
    
    [self addChildViewController:nav];
}



-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    NSLog(@"%lu",(unsigned long)tabBarController.selectedIndex);
    
}










@end
