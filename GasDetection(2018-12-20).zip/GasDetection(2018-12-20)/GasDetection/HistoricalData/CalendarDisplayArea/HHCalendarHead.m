//
//  HHCalendarHead.m
//  GasDetection
//
//  Created by 司月 on 2018/8/29.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHCalendarHead.h"
#import "GasDetectionCoreDataTool.h" // 数据库

@interface HHCalendarHead ()<FSCalendarDataSource,FSCalendarDelegate,FSCalendarDelegateAppearance,YQNumberSlideViewDelegate>


@end

@implementation HHCalendarHead

/// 初始化
+ (HHCalendarHead *)HHInit {
    HHCalendarHead *tool = (HHCalendarHead *)[[[NSBundle mainBundle] loadNibNamed:@"HHCalendarHead" owner:self options:nil] lastObject];
    if (tool) {
        [tool Initialize];
    }
    return tool;
}

- (void)layoutSubviews {
    
    self.segementView.frame = CGRectMake(0, 0, self.bounds.size.width, 40);
    
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self Initialize];
    }
    return self;
}

// 初始化
- (void)Initialize {
    
    self.dict = [NSMutableDictionary new];
    
    self.calendar.dataSource = self;
    self.calendar.delegate = self;
    
//    self.calendar.clipsToBounds = YES;
//    self.calendar.layer.cornerRadius = 10;

    
    self.calendar.backgroundColor = [UIColor whiteColor];

    /// 月标题文本的颜色
    self.calendar.appearance.headerTitleColor = [UIColor colorWithHue:0.707 saturation:0.325 brightness:0.941 alpha:1.000];
    
    /// 星期题文本的颜色
    self.calendar.appearance.weekdayTextColor = [UIColor colorWithHue:0.508 saturation:0.441 brightness:0.890 alpha:1.000];
    
    /// 事件点的颜色
    self.calendar.appearance.eventDefaultColor = [UIColor colorWithHue:0.605 saturation:0.338 brightness:0.918 alpha:1.000];
    
    /// 事件点的颜色
    self.calendar.appearance.eventSelectionColor = [UIColor colorWithHue:0.505 saturation:0.447 brightness:0.886 alpha:1.000];
    
    /// 今天日历的字幕文本颜色
    self.calendar.appearance.subtitleTodayColor = [UIColor whiteColor];
    
    /// 今天的填充色
    self.calendar.appearance.todayColor = [UIColor colorWithHue:0.702 saturation:0.318 brightness:0.937 alpha:1.000];
    
    /// 日期选中的文字颜色
    self.calendar.appearance.titleSelectionColor = [UIColor whiteColor];
    
    /// 选定状态下形状的填充颜色
    self.calendar.appearance.selectionColor = [UIColor colorWithHue:0.505 saturation:0.447 brightness:0.886 alpha:1.000];


    /// 月的alpha值标签保持边缘。
    self.calendar.appearance.headerMinimumDissolvedAlpha = 0;

    

}

- (void)setTitleArray:(NSMutableArray *)titleArray {
    _titleArray = titleArray;
    
    if (self.segementView) {
        self.segementView.delegate = nil;
        [self.segementView removeFromSuperview];
    }

    self.segementView = [[YQNumberSlideView alloc]initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 40)];
    self.segementView.backgroundColor = [UIColor clearColor];
    self.segementView.LabColor = [UIColor whiteColor];
    [self.segementView setLableCount:40];
    //监控代理
    self.segementView.delegate = self;
    [self.backView addSubview:self.segementView];
    
    // 设置数量
    [self.segementView setShowArray:titleArray];
    [self.segementView setLableCount:titleArray.count];
    // 显示
    [self.segementView show];
    
    if (titleArray.count <= 1) {
        self.segementView.userInteractionEnabled = NO;
    }else {
        self.segementView.userInteractionEnabled = YES;
    }
}



#pragma mark - <FSCalendarDataSource>

- (NSInteger)calendar:(FSCalendar *)calendar numberOfEventsForDate:(NSDate *)date {

//    NSLog(@"%@",date);
    
    /// 读取历史数据表 一天的数据
    HistoricalDataDay *dayModel = [[GasDetectionCoreDataTool shared] HHReadDataHistoricalData_Day:date];
    
    if (dayModel) {
//        [self.dict setObject:@[@"有值"] forKey:date];
        return 1;
    }
    
//    [self.dict setObject:@[] forKey:date];

    return 0;
}

/// 日期选中
- (void)calendar:(FSCalendar *)calendar didSelectDate:(NSDate *)date atMonthPosition:(FSCalendarMonthPosition)monthPosition {
    
    NSLog(@"%@",date);
    
    self.selectionDate = date;
    
    if (self.dateActionBlock) {
        self.dateActionBlock(date);
    }
}



-(void)YQSlideViewDidChangeIndex:(int)count {
//    NSLog(@"%@", [NSString stringWithFormat:@"当前页：%d",count+1]);
    
    if (!self.selectionDate) {
        self.selectionDate = [NSDate date];
    }
    
    if (self.YQSlideViewDidChangeIndexBlock) {
        self.YQSlideViewDidChangeIndexBlock(self.selectionDate,[self.titleArray objectAtIndex:count]);
    }
  
}







@end
