//
//  HHCalendarHead.h
//  GasDetection
//
//  Created by 司月 on 2018/8/29.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FSCalendar.h"
#import "YQNumberSlideView.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHCalendarHead : UIView

/// 日历
@property (weak, nonatomic) IBOutlet FSCalendar *calendar;

@property (weak, nonatomic) IBOutlet UIView *backView;

@property (nonatomic,strong)NSMutableDictionary *dict;

@property (nonatomic,strong)YQNumberSlideView *segementView;

@property (nonatomic,strong)NSMutableArray *titleArray;

@property (nonatomic,strong)NSDate *selectionDate;

/// 初始化
+ (HHCalendarHead *)HHInit;


/// 属性block
@property (nonatomic,strong)void (^dateActionBlock)(NSDate *date);

/// 属性block
@property (nonatomic,strong)void (^YQSlideViewDidChangeIndexBlock)(NSDate *date, NSString *title);


@end

NS_ASSUME_NONNULL_END
