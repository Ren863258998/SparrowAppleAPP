//
//  HHHistoryViewController+Sensor1.h
//  GasDetection
//
//  Created by 司月 on 2018/8/28.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHistoryViewController.h"
#import "AAChartView.h"
#import "GasDetectionCoreDataTool.h" // 数据库

NS_ASSUME_NONNULL_BEGIN

@interface HHHistoryViewController (Sensor1)


/// 传感器1曲线图model
- (void)HHSensor1;









@end

NS_ASSUME_NONNULL_END
