//
//  HHHistoryTableViewCell.h
//  GasDetection
//
//  Created by 司月 on 2018/8/27.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AAChartView.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHHistoryTableViewCell : UITableViewCell

/// 背景View
@property (weak, nonatomic) IBOutlet UIView *backView;

/// 图片
@property (weak, nonatomic) IBOutlet UIImageView *pic;

/// 标题
@property (weak, nonatomic) IBOutlet UILabel *title;

/// 标题2
@property (weak, nonatomic) IBOutlet UILabel *title2;


/// 曲线图
@property (nonatomic, strong) IBOutlet AAChartView *chartView;

/// 曲线图model
@property (nonatomic,strong)AAChartModel *chartModel;







@end

NS_ASSUME_NONNULL_END
