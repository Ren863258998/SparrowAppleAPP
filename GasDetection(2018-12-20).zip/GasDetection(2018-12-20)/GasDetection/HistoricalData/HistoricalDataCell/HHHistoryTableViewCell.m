//
//  HHHistoryTableViewCell.m
//  GasDetection
//
//  Created by 司月 on 2018/8/27.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHistoryTableViewCell.h"

@interface HHHistoryTableViewCell ()

/// 判断是否已经添加通知
@property(nonatomic,assign)BOOL isAddNotification;


@end

@implementation HHHistoryTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    

    // 设置图表视图的内容高度(默认 contentHeight 和 AAChartView 的高度相同)
//    self.chartView.contentHeight = self.contentView.frame.size.height - 10;

    
    self.backView.clipsToBounds = YES;
    self.backView.layer.cornerRadius = 10;

    
    
    if (self.isAddNotification == NO) {
        
        self.isAddNotification = YES;
        
        __weak typeof(self) weakSelf = self;

        // 获取通知中心单例
        NSNotificationCenter *notiCenter = [NSNotificationCenter defaultCenter];
        
        // 接收通知
        [notiCenter addObserverForName:@"HHWriteValue_s" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
            
            /// 创建数据model
            HHBluetoothModel *bluetoothModel = note.object;
            
            // 判断当前cell是否是co曲线图
            if ([weakSelf.title.text isEqualToString:NSLocalizedString(@"CO",@"OK")]) {
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakSelf.title2.text = [NSString stringWithFormat:NSLocalizedString(@"当前CO:%.2fppm",@"OK"),bluetoothModel.sensor1_float];
                });
            }
            // 判断当前cell是否是o3曲线图
            if ([weakSelf.title.text isEqualToString:NSLocalizedString(@"O3",@"OK")]) {
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakSelf.title2.text = [NSString stringWithFormat:NSLocalizedString(@"当前O3:%.2fppm",@"OK"),bluetoothModel.sensor2_float];
                });
            }
            // 判断当前cell是否是 温度 曲线图
            if ([weakSelf.title.text isEqualToString:NSLocalizedString(@"温度",@"OK")]) {
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakSelf.title2.text = [NSString stringWithFormat:NSLocalizedString(@"当前温度:%.2f℃",@"OK"),bluetoothModel.temperature_float];
                });
            }
            // 判断当前cell是否是 压力 曲线图
            if ([weakSelf.title.text isEqualToString:NSLocalizedString(@"压力",@"OK")]) {
                // 在主线程更新
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakSelf.title2.text = [NSString stringWithFormat:NSLocalizedString(@"当前压力:%.2fpa",@"OK"),bluetoothModel.pressure_float];
                });
            }
            
        }];
    }

}



/// 曲线图model
- (void)setChartModel:(AAChartModel *)chartModel {
    _chartModel = chartModel;
    
    
//    /*Custom Tooltip Style --- 自定义图表浮动提示框样式及内容*/
//    AAOptions *options = [AAOptionsConstructor configureChartOptionsWithAAChartModel:chartModel];
//    AATooltip *tooltip = options.tooltip;
//    tooltip
//    .useHTMLSet(true)
//    .headerFormatSet(@"{series.name}-<b>{point.key}</b> &nbsp12:00<br>")
//    .pointFormatSet(@"<b>{point.y}</b>&nbsp元/克")
//    .valueDecimalsSet(@2)//设置取值精确到小数点后几位
//    .backgroundColorSet(@"#000000")
//    .borderColorSet(@"#000000")
//    .styleSet(@{@"color":@"#FFD700"/*(纯金色)*/,
//                @"fontSize":@"12px",})
//    ;
    // 自定义图表浮动提示框样式及内容
//    [self.chartView aa_drawChartWithOptions:options];
    
    
    
    /// x 轴刻度点间隔数(设置每隔几个点显示一个 X轴的内容)
    self.chartModel.xAxisTickIntervalSet(@3);
    
    /// x 轴刻度点间隔数(设置每隔几个点显示一个 X轴的内容)
    self.chartModel.xAxisTickIntervalSet(@3);
    
    
    // 图表视图对象调用图表模型对象,绘制最终图形
    [self.chartView aa_drawChartWithChartModel:chartModel];
    
    // 更新 AAChartModel 数据之后,刷新图表
    [self.chartView aa_refreshChartWithChartModel:chartModel];
}












- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



// 销毁时
- (void)dealloc {
    
    // 移除观察者，Observer不能为nil
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}



@end
