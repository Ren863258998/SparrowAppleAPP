//
//  HHHistoryViewController+Pressure.m
//  GasDetection
//
//  Created by 司月 on 2018/10/9.
//  Copyright © 2018 syihh. All rights reserved.
//

#import "HHHistoryViewController+Pressure.h"

@implementation HHHistoryViewController (Pressure)


- (void)HHPressure {
    
    
    /// x标签数据数组
    self.xLabrlArray_Pressure = [NSMutableArray new];
    /// x数据数组
    self.xDataArray_Pressure = [NSMutableArray new];
    
    
    /// 图表设置
    
    //    self.delegate = self;
    
    /// 设置图表视图可以滚动
    //    self.scrollEnabled = NO;
    /// AAChartView的内容宽度
    //    self.chartView.contentWidth = 200;
    /// AAChartView的内容高度
    //    self.chartView.contentHeight = 200;
    /// 隐藏图表系列内容或不
    //    self.chartView.chartSeriesHidden = NO;
    /// 设置图表视图背景颜色要清晰
    //    self.chartView.isClearBackgroundColor = YES;
    /// 模糊效果使
    //    self.chartView.blurEffectEnabled = YES;
    
    
    /// 图点设置
    //    AAMarker *markerSet = AAObject(AAMarker);
    //    /// 半径
    //    markerSet.radius = @10;
    //    /// 象征
    //    markerSet.symbol = @"???";
    //    /// 点的填充色(用来设置折线连接点的填充色)
    //    markerSet.fillColor = @"???";
    //    /// 外沿线的宽度(用来设置折线连接点的轮廓描边的宽度)
    //    markerSet.lineWidth = @5;
    //    /// 外沿线的颜色(用来设置折线连接点的轮廓描边颜色，当值为空字符串时，默认取数据点或数据列的颜色。)
    //    markerSet.lineColor = @"#800000";
    
    
    
    /// 数据配置
    AASeriesElement *sseriesElement = AAObject(AASeriesElement);
    self.sseriesElement_Pressure = sseriesElement;
    /// 类型
    sseriesElement.typeSet(AAChartTypeAreaspline);
    /// 是否允许在点击数据点标记（markers）、柱子（柱形图）、扇区（饼图）时选中该点，选中的点可以通过 Chart.getSelectedPoints 来获取。 默认是：false.
    //    sseriesElement.allowPointSelectSet(YES);
    /// 标题名称
    sseriesElement.nameSet(NSLocalizedString(@"压力",@"OK"));
    /// 数据
    sseriesElement.dataSet(self.xDataArray_Pressure);
    /// 数据颜色
    //    sseriesElement.colorSet(@"#0000FF");
    /// 决定了图表是否给每个数据列或每个点分配一个颜色，默认值是 false， 即默认是给每个数据类分配颜色，
    //    sseriesElement.colorByPointSet(@YES);
    /// 标记
    //    sseriesElement.markerSet(markerSet);
    /// 设置是否百分比堆叠显示图形
    //    sseriesElement.stackingSet(AAChartStackingTypePercent);
    /// 曲线类型
    //    sseriesElement.dashStyleSet(AALineDashSyleTypeLongDash);
    /// 阈值
    //    sseriesElement.thresholdSet(@111);
    /// 折线图、曲线图、直方折线图、折线填充图、曲线填充图、直方折线填充图的线条宽度
    //    sseriesElement.lineWidthSet(@11);
    /// 柱形图、条形图、扇形图等图形的描边宽度
    //    sseriesElement.borderWidthSet(@10);
    /// 柱形图、条形图、扇形图等图形的描边颜色
    //    sseriesElement.borderColorSet(@"#0000FF");
    /// 折线填充图、曲线填充图、直方折线填充图等填充图类型的填充颜色
    sseriesElement.fillColorSet(@0);
    /// 折线填充图、曲线填充图、直方折线填充图等填充图类型的填充颜色透明度
    sseriesElement.fillOpacitySet(@1);
    /// 图中低于阈值的部分或点的颜色
    //    sseriesElement.negativeColorSet(@"#0000FF");
    
    
    
    
    /// 曲线图配置
    AAChartModel *chartModel = AAObject(AAChartModel);
    self.chartModel_Pressure = chartModel;
    
    /// 标题内容
    chartModel.titleSet(@"");
    //    /// 标题字体大小
    //    chartModel.titleFontSizeSet(@11);
    //    /// 标题字体颜色
    //    chartModel.titleFontColorSet(@"#191970");
    //    /// 标题字体
    //    chartModel.titleFontWeightSet(@"AAChartFontWeightTypeRegular");
    
    /// 副标题内容
    chartModel.subtitleSet(@"");
    //    /// 副标题字体大小
    //    chartModel.subtitleFontSizeSet(@11);
    /// 副标题字体颜色
    //    chartModel.subtitleFontColorSet(@"#191970");
    //    /// 副标题字体
    //    chartModel.subtitleFontWeightSet(@"AAChartFontWeightTypeRegular");
    
    /// 图表背景色
    //    chartModel.backgroundColorSet(@"#FAFAD2");
    /// 图表主题颜色数组
    chartModel.colorsThemeSet(@[@"#483D8B"]);
    /// x轴坐标每个点对应的名称
    chartModel.categoriesSet(self.xLabrlArray_Pressure);
    /// 图表的数据列内容
    chartModel.seriesSet(@[self.sseriesElement_Pressure]);
    
    /// 图表副标题文本水平对齐方式。可选的值有 “left”，”center“和“right”。 默认是：center.
    //    chartModel.subtitleAlignSet(AAChartSubtitleAlignTypeLeft);
    /// 图表类型
    chartModel.chartTypeSet(AAChartTypeAreaspline);
    /// 堆积样式
    //    chartModel.stackingSet(AAChartStackingTypeFalse);
    /// 折线曲线连接点的类型："circle", "square", "diamond", "triangle","triangle-down"，默认是"circle"
    chartModel.symbolSet(AAChartSymbolTypeCircle);
    /// 图点风格
    chartModel.symbolStyleSet(AAChartSymbolStyleTypeBorderBlank);
    /// 缩放类型 AAChartZoomTypeX 表示可沿着 x 轴进行手势缩放
    chartModel.zoomTypeSet(AAChartZoomTypeX);
    /// 设置图表的渲染动画类型
    chartModel.animationTypeSet(AAChartAnimationEaseTo);
    /// 设置图表的渲染动画时长(动画单位为毫秒)
    chartModel.animationDurationSet(@0);
    
    /// x 轴是否垂直,默认为否
    chartModel.invertedSet(NO);
    /// 是否要为渐变色,默认为否
    chartModel.gradientColorEnabledSet(YES);
    /// 是否极化图形(变为雷达图),默认为否
    chartModel.polarSet(NO);
    /// 是否显示数据,默认为否
    //    chartModel.dataLabelEnabledSet(YES);
    /// 数据标签字体颜色
    //    chartModel.dataLabelFontColorSet(@"#00FF00");
    /// 数据标签字体大小
    //    chartModel.dataLabelFontSizeSet(@10);
    /// 数据标签字体
    //    chartModel.dataLabelFontWeightSet(@"AAChartFontWeightTypeRegular");
    
    /// x 轴是否可见(默认可见)
    chartModel.xAxisVisibleSet(YES);
    /// x 轴翻转,默认为否
    chartModel.xAxisReversedSet(NO);
    
    /// x 轴是否显示文字
    chartModel.xAxisLabelsEnabledSet(YES);
    /// x 轴文字字体大小
    chartModel.xAxisLabelsFontSizeSet(@8);
    /// x 轴文字字体颜色
    chartModel.xAxisLabelsFontColorSet(@"#483D8B");
    /// x 轴文字字体粗细
    //    chartModel.xAxisLabelsFontWeightSet(AAChartFontWeightTypeThin);
    
    /// x 轴网格线的宽度
    chartModel.xAxisGridLineWidthSet(@LINE_1);
    /// x 轴刻度点间隔数(设置每隔几个点显示一个 X轴的内容)
    chartModel.xAxisTickIntervalSet(@1);
    
    /// x 轴交叉宽度
    chartModel.xAxisCrosshairWidthSet(@LINE_1);
    /// x 轴网格线的颜色
    chartModel.xAxisCrosshairColorSet(@"#7B68EE");
    /// x 轴十字划线式
    chartModel.xAxisCrosshairDashStyleTypeSet(AALineDashSyleTypeLongDash);
    
    
    /// y 轴是否可见(默认可见)
    chartModel.yAxisVisibleSet(YES);
    /// y 轴翻转,默认为否
    //    chartModel.yAxisReversedSet(NO);
    /// y 轴是否显示文字
    chartModel.yAxisLabelsEnabledSet(YES);
    /// y 轴文字字体大小
    chartModel.yAxisLabelsFontSizeSet(@8);
    /// y 轴文字字体颜色
    chartModel.yAxisLabelsFontColorSet(@"#7B68EE");
    /// y 轴文字字体粗细
    //    chartModel.yAxisLabelsFontWeightSet(AAChartFontWeightTypeThin);
    /// y 轴标题
    chartModel.yAxisTitleSet(@"");
    /// y 轴线宽
    chartModel.yAxisLineWidthSet(@0);
    /// y 轴网格线的宽度
    chartModel.yAxisGridLineWidthSet(@LINE_1);
    /// y 轴显示小数
    chartModel.yAxisAllowDecimalsSet(NO);
    /// y 轴基线的配置
    //    chartModel.yAxisPlotLinesSet(xLabrlArray);
    /// y 轴最大值
    //    chartModel.yAxisMaxSet(@500);
    /// y 轴最小值（设置为0就不会有负数）
    //    chartModel.yAxisMinSet(@0);
    /// 5 轴刻度点间隔数(设置每隔几个点显示一个 X轴的内容)
    //    chartModel.yAxisTickIntervalSet(@100);
    /// 自定义 y 轴坐标（如：[@(0), @(25), @(50), @(75) , (100)]）
    //    chartModel.yAxisTickPositionsSet(xLabrlArray);
    
    /// y 轴交叉宽度设置
    chartModel.yAxisCrosshairWidthSet(@LINE_1);
    /// y 轴网格线的颜色
    chartModel.yAxisCrosshairColorSet(@"#7B68EE");
    /// y 轴十字划线式
    chartModel.yAxisCrosshairDashStyleTypeSet(AALineDashSyleTypeLongDash);
    
    /// 是否显示浮动提示框(默认显示)
    chartModel.tooltipEnabledSet(YES);
    /// 是否多组数据共享一个浮动提示框
    chartModel.tooltipSharedSet(NO);
    /// 浮动提示框单位后缀
    chartModel.tooltipValueSuffixSet(@"ppm");
    
    /// 设置折线是否断点重连(是否连接空值点)
    chartModel.connectNullsSet(NO);
    /// 是否显示图例 lengend(图表底部可点按的圆点和文字)
    chartModel.legendEnabledSet(NO);
    
    /// 柱状图长条图头部圆角半径(可用于设置头部的形状,仅对条形图,柱状图有效)
    //    chartModel.borderRadiusSet(@20);
    /// 折线连接点的半径长度
    chartModel.markerRadiusSet(@3);
    /// 字符串显示'缩放重置按钮'
    chartModel.zoomResetButtonTextSet(NSLocalizedString(@"恢复缩放",@"NO"));
    
    
    
    //    // 图表视图对象调用图表模型对象,绘制最终图形
    //    [self aa_drawChartWithChartModel:chartModel];
    //
    //    // 更新 AAChartModel 数据之后,刷新图表
    //    [self aa_refreshChartWithChartModel:chartModel];
    //
    
    
    
    
}





@end
