//
//  HHHistoryViewController+Pressure.h
//  GasDetection
//
//  Created by 司月 on 2018/10/9.
//  Copyright © 2018 syihh. All rights reserved.
//

#import "HHHistoryViewController.h"
#import "AAChartView.h"
#import "GasDetectionCoreDataTool.h" // 数据库

NS_ASSUME_NONNULL_BEGIN

@interface HHHistoryViewController (Pressure)

/// 压力 曲线图model
- (void)HHPressure;



@end

NS_ASSUME_NONNULL_END
