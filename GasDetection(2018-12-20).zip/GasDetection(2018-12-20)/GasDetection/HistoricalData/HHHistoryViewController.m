//
//  HHHistoryViewController.m
//  GasDetection
//
//  Created by 司月 on 2018/8/14.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHHistoryViewController.h"
#import "HHHistoryTableViewCell.h"
#import "GasDetectionCoreDataTool.h" // 数据库
#import "UIScrollView+EmptyDataSet.h" // 占位图
#import "HHHistoryViewController+Sensor1.h"
#import "HHHistoryViewController+Sensor2.h"
#import "HHHistoryViewController+Temperature.h"
#import "HHHistoryViewController+Humidity.h"
#import "HHHistoryViewController+Pressure.h"
#import "HHCalendarHead.h"
#import "UIBarButtonItem+Block.h"


@interface HHHistoryViewController ()

/// 日历头
@property(nonatomic,strong)HHCalendarHead *calendarHead;

@end

@implementation HHHistoryViewController
    
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    self.backView.frame = CGRectMake(0, 0, self.tableView.contentSize.width, self.tableView.contentSize.height);
    self.gradientLayer.frame = self.backView.bounds;
    
    // 下面这行代码能够将view2  调整到父视图的最下面
    [self.tableView sendSubviewToBack:self.backView];
}

// 设置样式
- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    __weak typeof(self) weakSelf = self;
    
    
    // 导航条右按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem new] HHPic:@"file_item_extended_share" Block:^(UIBarButtonItem *item) {
        
        [weakSelf HHSave];
    }];
    
    // 无边线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    // 隐藏多余线
    self.tableView.tableFooterView = [[UIView alloc] init];
    
    /// 注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"HHHistoryTableViewCell" bundle:nil] forCellReuseIdentifier:@"HHHistoryTableViewCell"];

    
    
    
    /// 初始化头部分区
    if (!self.calendarHead) {
        HHCalendarHead *calendarHead = [HHCalendarHead HHInit];
        self.calendarHead = calendarHead;
        
        /// 点击事件回调
        calendarHead.dateActionBlock = ^(NSDate * _Nonnull date) {
            
            /// 读取历史数据表 一天的数据
            [weakSelf HHReadDataHistorical_Day:date];
        };
        calendarHead.YQSlideViewDidChangeIndexBlock = ^(NSDate * _Nonnull date, NSString * _Nonnull title) {
            if ([title isEqualToString:NSLocalizedString(@"全天",@"OK")]) {
                /// 读取历史数据表 一天的数据
                [weakSelf HHReadDataHistorical_Day:date];
            }else {
                [weakSelf HHReadDataHistorical_Day:date Hour:[title integerValue]];
            }

        };
        //--- 加载延迟
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            /// 读取历史数据表 一天的数据
            [weakSelf HHReadDataHistorical_Day:[NSDate date]];
        });
        
    }

    
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.contentSize.width, self.tableView.contentSize.height)];
    backView.backgroundColor = [UIColor greenColor];
    self.backView = backView;
    [self.tableView addSubview:backView];
    // 下面这行代码能够将view2  调整到父视图的最下面
    [self.tableView sendSubviewToBack:backView];

    // 初始化CAGradientlayer对象，使它的大小为UIView的大小
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    self.gradientLayer = gradientLayer;
    gradientLayer.frame = backView.bounds;
    
    // 将CAGradientlayer对象添加在我们要设置背景色的视图的layer层
    [backView.layer addSublayer:gradientLayer];
    
    // 设置渐变区域的起始和终止位置（范围为0-1）
    gradientLayer.startPoint = CGPointMake(0, 0);
    gradientLayer.endPoint = CGPointMake(0, 1);
  
    // 设置颜色数组
    gradientLayer.colors = @[(__bridge id)[UIColor colorWithHue:0.546 saturation:0.439 brightness:0.902 alpha:1.000].CGColor,
                             (__bridge id)[UIColor colorWithHue:0.713 saturation:0.360 brightness:0.949 alpha:1.000].CGColor];

    // 设置颜色分割点（范围：0-1）
    gradientLayer.locations = @[@(0.0f), @(1.0f)];

    
    
    
    /// 初始化数组
    self.chartModelArray = [NSMutableArray new];
    
    
    /// 初始化传感器1
    [self HHSensor1];
    [self.chartModelArray addObject:@[self.chartModel_Sensor1,NSLocalizedString(@"CO",@"OK"),@"019 Tree"]];
    
    /// 初始化传感器2
    [self HHSensor2];
    [self.chartModelArray addObject:@[self.chartModel_Sensor2,NSLocalizedString(@"O3",@"OK"),@"001 Dry"]];
    
    /// 初始化温度传感器
    [self HHTemperature];
    [self.chartModelArray addObject:@[self.chartModel_Temperature,NSLocalizedString(@"温度",@"OK"),@"013 Thermometer 2"]];
    
    /// 初始化湿度传感器
    [self HHHumidity];
    [self.chartModelArray addObject:@[self.chartModel_Humidity,NSLocalizedString(@"湿度",@"OK"),@"013 Thermometer 2"]];
    
    /// 初始化压力传感器
    [self HHPressure];
    [self.chartModelArray addObject:@[self.chartModel_Pressure,NSLocalizedString(@"压力",@"OK"),@"007 Remote Control"]];

}


/// 读取历史数据表 一天的数据
- (void)HHReadDataHistorical_Day:(NSDate *)date {
    
    __weak typeof(self) weakSelf = self;
    
    NSLog(@"--%@",date);
    
    NSMutableArray *timeArray = [NSMutableArray new];
    [timeArray addObject:NSLocalizedString(@"全天",@"OK")];
    
    // 在主线程更新
    dispatch_async(dispatch_get_main_queue(), ^{
        [SVProgressHUD showWithStatus:NSLocalizedString(@"正在加载数据库～",@"NO")];
    });
    
    // 开启子线程执行
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        /// 获取当天数据
        HistoricalDataDay *dayModel = [[GasDetectionCoreDataTool shared] HHReadDataHistoricalData_Day:date];
        /// 获取所有历史记录
        NSSet<HistoricalInformation *> *historicalData = dayModel.historicalData;
        
        
        // 日期时间排序
        NSSortDescriptor *dateSD = [NSSortDescriptor sortDescriptorWithKey:@"recordingTime" ascending:YES];
        /// 数组排序
        NSArray<HistoricalInformation *> *historicalArr = [historicalData sortedArrayUsingDescriptors:@[dateSD]];
        self.historicalArr = historicalArr;
        
//    NSLog(@"刷新%@",[historicalArr.lastObject.recordingTime HHDateTime:@"HH:mm"]);
        
        NSNumberFormatter *numberF = [NSNumberFormatter new];
        numberF.numberStyle = NSNumberFormatterDecimalStyle;
        // 小数位最多位数
        numberF.maximumFractionDigits = 2;
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Sensor1 removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Sensor1 removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Sensor2 removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Sensor2 removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Temperature removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Temperature removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Humidity removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Humidity removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Pressure removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Pressure removeAllObjects];
        
        /// 每小时显示
        for (NSInteger i = 0; i < 24; i++) {
            
            // 整小时时间 开始时间
            NSDate *startDate = [[date HHDateTime:[NSString stringWithFormat:@"yyyy-MM-dd %02ld:00:00",i]] HHDateTime:@"yyyy-MM-dd HH:mm:ss"];
            // 结束时间
            NSDate *endDate = [[date HHDateTime:[NSString stringWithFormat:@"yyyy-MM-dd %02ld:59:59",i]] HHDateTime:@"yyyy-MM-dd HH:mm:ss"];
            
            
            // 谓词筛选数组中数据
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"recordingTime >= %@ AND recordingTime <= %@",startDate,endDate];
            NSArray<HistoricalInformation *> *array_temp = [historicalArr filteredArrayUsingPredicate:predicate];
            
            if (array_temp.count > 0) {
                
                HistoricalInformation *obj = array_temp.firstObject;
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Sensor1 addObject:[obj.recordingTime HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Sensor1 addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.sensor1]]];
                
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Sensor2 addObject:[obj.recordingTime HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Sensor2 addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.sensor2]]];
                
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Temperature addObject:[obj.recordingTime HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Temperature addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.temperature]]];
                
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Humidity addObject:[obj.recordingTime HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Humidity addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.humidity]]];
                
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Pressure addObject:[obj.recordingTime HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Pressure addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.pressure]]];
                
                
                [timeArray addObject:[startDate HHDateTime:@"HH:mm"]];
            }else {
                /// x标签数据数组
                [weakSelf.xLabrlArray_Sensor1 addObject:[startDate HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Sensor1 addObject:@""];
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Sensor2 addObject:[startDate HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Sensor2 addObject:@""];
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Temperature addObject:[startDate HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Temperature addObject:@""];
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Humidity addObject:[startDate HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Humidity addObject:@""];
                
                /// x标签数据数组
                [weakSelf.xLabrlArray_Pressure addObject:[startDate HHDateTime:@"HH:mm"]];
                /// x数据数组
                [weakSelf.xDataArray_Pressure addObject:@""];
            }
        }
        
        
        // 在主线程更新
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [weakSelf.tableView reloadData];
            
            [SVProgressHUD dismiss];
            
            self.calendarHead.titleArray = timeArray;
 
        });
        
    });
    
}



/// 读取历史数据表 一天的数据 其中一小时的
- (void)HHReadDataHistorical_Day:(NSDate *)date Hour:(NSInteger)hour {
    
    __weak typeof(self) weakSelf = self;
    
    NSLog(@"--%@",date);
    
    // 在主线程更新
    dispatch_async(dispatch_get_main_queue(), ^{
        [SVProgressHUD showWithStatus:NSLocalizedString(@"正在加载数据库～",@"NO")];
    });
    
    // 开启子线程执行
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        /// 获取当天数据
        HistoricalDataDay *dayModel = [[GasDetectionCoreDataTool shared] HHReadDataHistoricalData_Day:date];
        /// 获取所有历史记录
        NSSet<HistoricalInformation *> *historicalData = dayModel.historicalData;
        
        
        // 日期时间排序
        NSSortDescriptor *dateSD = [NSSortDescriptor sortDescriptorWithKey:@"recordingTime" ascending:YES];
        /// 数组排序
        NSArray<HistoricalInformation *> *historicalArr = [historicalData sortedArrayUsingDescriptors:@[dateSD]];
        self.historicalArr = historicalArr;
        
//    NSLog(@"刷新%@",[historicalArr.lastObject.recordingTime HHDateTime:@"HH:mm"]);
        
        NSNumberFormatter *numberF = [NSNumberFormatter new];
        numberF.numberStyle = NSNumberFormatterDecimalStyle;
        // 小数位最多位数
        numberF.maximumFractionDigits = 2;
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Sensor1 removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Sensor1 removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Sensor2 removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Sensor2 removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Temperature removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Temperature removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Humidity removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Humidity removeAllObjects];
        
        
        /// x标签数据数组
        [weakSelf.xLabrlArray_Pressure removeAllObjects];
        /// x数据数组
        [weakSelf.xDataArray_Pressure removeAllObjects];
        
        // 整小时时间 开始时间
        NSDate *startDate = [[date HHDateTime:[NSString stringWithFormat:@"yyyy-MM-dd %02ld:00:00",hour]] HHDateTime:@"yyyy-MM-dd HH:mm:ss"];
        // 结束时间
        NSDate *endDate = [[date HHDateTime:[NSString stringWithFormat:@"yyyy-MM-dd %02ld:59:59",hour]] HHDateTime:@"yyyy-MM-dd HH:mm:ss"];
        
        
        // 谓词筛选数组中数据
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"recordingTime >= %@ AND recordingTime <= %@",startDate,endDate];
        NSArray<HistoricalInformation *> *array_temp = [historicalArr filteredArrayUsingPredicate:predicate];
        
        
        [array_temp enumerateObjectsUsingBlock:^(HistoricalInformation * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            /// x标签数据数组
            [weakSelf.xLabrlArray_Sensor1 addObject:[obj.recordingTime HHDateTime:@"HH:mm:ss"]];
            /// x数据数组
            [weakSelf.xDataArray_Sensor1 addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.sensor1]]];
            
            
            /// x标签数据数组
            [weakSelf.xLabrlArray_Sensor2 addObject:[obj.recordingTime HHDateTime:@"HH:mm:ss"]];
            /// x数据数组
            [weakSelf.xDataArray_Sensor2 addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.sensor2]]];
            
            
            /// x标签数据数组
            [weakSelf.xLabrlArray_Temperature addObject:[obj.recordingTime HHDateTime:@"HH:mm:ss"]];
            /// x数据数组
            [weakSelf.xDataArray_Temperature addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.temperature]]];
            
            
            /// x标签数据数组
            [weakSelf.xLabrlArray_Humidity addObject:[obj.recordingTime HHDateTime:@"HH:mm:ss"]];
            /// x数据数组
            [weakSelf.xDataArray_Humidity addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.humidity]]];
            
            
            /// x标签数据数组
            [weakSelf.xLabrlArray_Pressure addObject:[obj.recordingTime HHDateTime:@"HH:mm:ss"]];
            /// x数据数组
            [weakSelf.xDataArray_Pressure addObject:[numberF numberFromString:[NSString stringWithFormat:@"%.2f",obj.pressure]]];
            
        }];
        
        
        // 在主线程更新
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [weakSelf.tableView reloadData];
            
            [SVProgressHUD dismiss];
            
        });
        
    });
    
}









//- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView {
//    return YES;
//}
//
//- (UIImage *)imageForEmptyDataSet:(UIScrollView *)scrollView {
//    return [UIImage imageNamed:@"icon_list_empty.png"];
//}
//
//- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView {
//    NSString *title = @"暂无历史数据";
//    NSDictionary *attributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:16.0f],NSForegroundColorAttributeName:RGBColor(206, 206, 206)};
//    return [[NSAttributedString alloc] initWithString:title attributes:attributes];
//}



// 设置表格的组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// 设置每个组有多少行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.chartModelArray.count;
}

// 设置单元格行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 200;
}

// 设置分区头间距
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 250;
}

// 设置分区头View
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return self.calendarHead;
}

// 设置单元格显示的内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HHHistoryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HHHistoryTableViewCell" forIndexPath:indexPath];

    cell.chartModel = self.chartModelArray[indexPath.row][0];
    cell.title.text = self.chartModelArray[indexPath.row][1];
    cell.pic.image = [UIImage imageNamed:self.chartModelArray[indexPath.row][2]];
    
    return cell;
}

// cell将要显示
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

// cell将要消失
- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath*)indexPath {
    
}


// 选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
}


/// cell 取消选中状态
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
}



// 监听
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    
    // 下面这行代码能够将view2  调整到父视图的最下面
    [self.tableView sendSubviewToBack:self.backView];
}





/// 保存数据分享出去
- (void)HHSave {
    
    // 在主线程更新
    dispatch_async(dispatch_get_main_queue(), ^{
        [SVProgressHUD showWithStatus:NSLocalizedString(@"正在保存历史数据～",@"NO")];
    });
    
    // 详情报告
    NSMutableString *reportHeader = [@"" mutableCopy];
    
    [reportHeader appendString:NSLocalizedString(@"记录时间,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"原始数据,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"UDID,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"OC,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"O3,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"温度,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"湿度,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"压力,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"电量,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"天气,",@"NO")];
    [reportHeader appendString:NSLocalizedString(@"位置地址,",@"NO")];

    [reportHeader appendString:@"\n"];
    
    __weak typeof(self) weakSelf = self;
    
    /// 开启子线程执行
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        /// 获取所有天数数据
        NSArray<HistoricalDataDay *> *arr = [[GasDetectionCoreDataTool shared] HHReadDataHistoricalData_All];
        
        /// 遍历所有天数 获取每一天的数据
        [arr enumerateObjectsUsingBlock:^(HistoricalDataDay * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            /// 获取所有历史记录
            NSSet<HistoricalInformation *> *historicalData = obj.historicalData;
            // 日期时间排序
            NSSortDescriptor *dateSD = [NSSortDescriptor sortDescriptorWithKey:@"recordingTime" ascending:YES];
            /// 数组排序
            NSArray<HistoricalInformation *> *historicalArr = [historicalData sortedArrayUsingDescriptors:@[dateSD]];
            
            /// 获取每一天的所有数据
            [historicalArr enumerateObjectsUsingBlock:^(HistoricalInformation * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                
                NSMutableArray *dataArray = [NSMutableArray new];
                
                /// 记录时间
                [dataArray addObject:[NSString stringWithFormat:@"\"%@\"",[obj.recordingTime HHDateTime]]];
                /// 原始数据
                [dataArray addObject:[NSString stringWithFormat:@"\"%@\"",obj.originalData]];
                /// UDID
                [dataArray addObject:[NSString stringWithFormat:@"\"%@\"",obj.identifier]];
                /// OC
                [dataArray addObject:[NSString stringWithFormat:@"\"%.2f\"",obj.sensor1]];
                /// O3
                [dataArray addObject:[NSString stringWithFormat:@"\"%.2f\"",obj.sensor2]];
                /// 温度
                [dataArray addObject:[NSString stringWithFormat:@"\"%.2f\"",obj.temperature]];
                /// 湿度
                [dataArray addObject:[NSString stringWithFormat:@"\"%.2f\"",obj.humidity]];
                /// 压力
                [dataArray addObject:[NSString stringWithFormat:@"\"%.2f\"",obj.pressure]];
                /// 电量
                [dataArray addObject:[NSString stringWithFormat:@"\"%.2f\"",obj.batteryVoltage]];
                /// 天气
                [dataArray addObject:[NSString stringWithFormat:@"\"%@\"",obj.weather]];
                /// 位置地址
                [dataArray addObject:[NSString stringWithFormat:@"\"%@\"",obj.locationAddress]];
                
                // 将数组拼接成字符串
                [reportHeader appendString:[dataArray componentsJoinedByString:@","]];
                [reportHeader appendString:@"\n"];
                
                NSLog(@"--%@",[dataArray componentsJoinedByString:@","]);
            }];
            
        }];
        
        /// 保存文件路径
        NSString *str = [NSString stringWithFormat:@"/save_%@.csv",[[NSDate date] HHDateTime]];
        NSString *filePath = FILEPATH_D(str);
        NSURL    *fileUrl = [NSURL fileURLWithPath:filePath];
        
        BOOL isWrite = [reportHeader writeToURL:fileUrl atomically:YES encoding:NSUTF8StringEncoding error:nil];
        
        if (isWrite == NO) {
            [SVProgressHUD showErrorWithStatus:NSLocalizedString(@"保存历史数据失败～",@"NO")];
            return ;
        }
        
        // 添加HUD
        __block MBProgressHUD *hud;
        
        ///在主线程更新
        dispatch_async(dispatch_get_main_queue(), ^{
            hud = [MBProgressHUD showHUDAddedTo:self.tabBarController.view animated:YES];
        });
        
        // 创建隔空投送控制器
        UIActivityViewController *activityController = [[UIActivityViewController alloc] initWithActivityItems:@[fileUrl] applicationActivities:nil];
        
        // 完成与物品处理程序
        activityController.completionWithItemsHandler = ^(UIActivityType _Nullable activityType, BOOL completed, NSArray * _Nullable returnedItems, NSError * _Nullable activityError) {

            // 判断是否拷贝文件
            if ([activityType isEqualToString:@"com.apple.UIKit.activity.CopyToPasteboard"]) {
                NSLog(@"拷贝文件");
                // 显示HUD信息
                [SVProgressHUD showSuccessWithStatus:NSLocalizedString(@"已经拷贝到粘贴板",@"NO")];
            }

        };
        
        ///在主线程更新
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.navigationController presentViewController:activityController animated:YES completion:nil];
            // 删除HUD
            [hud hideAnimated:YES];
            [SVProgressHUD dismiss];
        });
    });

}












@end
