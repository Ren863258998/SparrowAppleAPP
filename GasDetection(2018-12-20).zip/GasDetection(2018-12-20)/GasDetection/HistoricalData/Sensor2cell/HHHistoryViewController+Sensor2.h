//
//  HHHistoryViewController+Sensor2.h
//  GasDetection
//
//  Created by 司月 on 2018/10/9.
//  Copyright © 2018 syihh. All rights reserved.
//

#import "HHHistoryViewController.h"
#import "AAChartView.h"
#import "GasDetectionCoreDataTool.h" // 数据库

NS_ASSUME_NONNULL_BEGIN

@interface HHHistoryViewController (Sensor2)

/// 传感器2曲线图model
- (void)HHSensor2;




@end

NS_ASSUME_NONNULL_END
