//
//  HHHistoryViewController.h
//  GasDetection
//
//  Created by 司月 on 2018/8/14.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHViewController.h"
#import "AAChartView.h"
#import "HHTableView.h"

NS_ASSUME_NONNULL_BEGIN

@interface HHHistoryViewController : HHViewController

/// tableView
@property (weak, nonatomic) IBOutlet HHTableView *tableView;

/// 渐变色View
@property (nonatomic,strong)UIView *backView;
@property (nonatomic,strong)CAGradientLayer *gradientLayer;
    
/// 曲线图model 数组
@property (nonatomic,strong)NSMutableArray *chartModelArray;


/// 当天的所有数据
@property (nonatomic,strong)NSArray<HistoricalInformation *> *historicalArr;



/// 传感器1 model
@property (nonatomic,strong)AAChartModel *chartModel_Sensor1;
/// 数据配置
@property(nonatomic,strong)AASeriesElement *sseriesElement_Sensor1;
/// x标签数据数组
@property(nonatomic,strong)NSMutableArray *xLabrlArray_Sensor1;
/// x数据数组
@property(nonatomic,strong)NSMutableArray *xDataArray_Sensor1;





/// 传感器2 model
@property (nonatomic,strong)AAChartModel *chartModel_Sensor2;
/// 数据配置
@property(nonatomic,strong)AASeriesElement *sseriesElement_Sensor2;
/// x标签数据数组
@property(nonatomic,strong)NSMutableArray *xLabrlArray_Sensor2;
/// x数据数组
@property(nonatomic,strong)NSMutableArray *xDataArray_Sensor2;




/// 温度 model
@property (nonatomic,strong)AAChartModel *chartModel_Temperature;
/// 数据配置
@property(nonatomic,strong)AASeriesElement *sseriesElement_Temperature;
/// x标签数据数组
@property(nonatomic,strong)NSMutableArray *xLabrlArray_Temperature;
/// x数据数组
@property(nonatomic,strong)NSMutableArray *xDataArray_Temperature;



/// 湿度 model
@property (nonatomic,strong)AAChartModel *chartModel_Humidity;
/// 数据配置
@property(nonatomic,strong)AASeriesElement *sseriesElement_Humidity;
/// x标签数据数组
@property(nonatomic,strong)NSMutableArray *xLabrlArray_Humidity;
/// x数据数组
@property(nonatomic,strong)NSMutableArray *xDataArray_Humidity;





/// 压力 model
@property (nonatomic,strong)AAChartModel *chartModel_Pressure;
/// 数据配置
@property(nonatomic,strong)AASeriesElement *sseriesElement_Pressure;
/// x标签数据数组
@property(nonatomic,strong)NSMutableArray *xLabrlArray_Pressure;
/// x数据数组
@property(nonatomic,strong)NSMutableArray *xDataArray_Pressure;














@end

NS_ASSUME_NONNULL_END
