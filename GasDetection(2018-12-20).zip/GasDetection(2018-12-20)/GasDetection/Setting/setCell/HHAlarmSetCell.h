//
//  HHAlarmSetCell.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHAlarmSetCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UISwitch *isSelect;
@property (assign, nonatomic) NSInteger row;
@property (copy  , nonatomic) void(^selectBlock)(NSInteger tag);
@property (weak, nonatomic) IBOutlet UISwitch *alarmSwitch;

+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView;

@end

NS_ASSUME_NONNULL_END
