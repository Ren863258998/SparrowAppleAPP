//
//  HHAlarmSetCell.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHAlarmSetCell.h"


#define TUISONG @"TUISONG"
#define SHENGYIN @"SHENGYIN"
#define TEL_911 @"TEL_911"
#define FAXINXI @"FAXINXI"
#define ZHENDONG @"ZHENDONG"

@implementation HHAlarmSetCell
+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView{
    
     HHAlarmSetCell *   cell= (HHAlarmSetCell *)[[[NSBundle  mainBundle]  loadNibNamed:@"HHAlarmSetCell" owner:nil options:nil]  lastObject];
    [cell.alarmSwitch addTarget:cell action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    [cell.alarmSwitch setOn:NO];
    return cell;
}

- (void)switchAction:(id)sender{
    UISwitch *switchButton = (UISwitch*)sender;
    
    BOOL isButtonOn = [switchButton isOn];
    
    
    switch (self.row) {
        case 0:
        {
            [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isPush = isButtonOn;
            [[GasDetectionCoreDataTool shared] HHUpdateData];
            !_selectBlock? :_selectBlock(self.row);
            break;
            
        }
        case 1:
        {
            [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isVoice = isButtonOn;
            [[GasDetectionCoreDataTool shared] HHUpdateData];
            !_selectBlock? :_selectBlock(self.row);

            break;
            
        }
        case 2:
        {
            [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isVibration = isButtonOn;
            [[GasDetectionCoreDataTool shared] HHUpdateData];
            !_selectBlock? :_selectBlock(self.row);
            break;
            
        }
        case 3:
        {
    
            // 是否自动联系紧急联系人
            [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isContactEmergencyContact = isButtonOn;
            [[GasDetectionCoreDataTool shared] HHUpdateData];
            
            
            
           
            
//            if (isButtonOn) {
//                [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isAutoPhoneCall = NO;
//            }
            !_selectBlock? :_selectBlock(self.row);
            break;
            
        }
        case 4:
        {
            /// 是否自动拨打电话
            [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isAutoPhoneCall = isButtonOn;
            [[GasDetectionCoreDataTool shared] HHUpdateData];
            if (isButtonOn) {
                [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isContactEmergencyContact = NO;
            }
            !_selectBlock? :_selectBlock(self.row);
            break;
            
        }
            
        default:
            break;
    }
    
    
    

}

- (void)setAlarmPreferences:(BOOL)isYes name:(NSString *)name{

    [GasDetectionCoreDataTool shared].HHReadDataSettingForm.isVoice = isYes;
    
    [[NSUserDefaults standardUserDefaults] setBool:isYes forKey:name];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)setRow:(NSInteger)row{

    _row = row;

    if (row == 0) {
        [self.alarmSwitch setOn:[GasDetectionCoreDataTool shared].HHReadDataSettingForm.isPush animated:NO];
    }

    
    if (row == 1) {
        [self.alarmSwitch setOn:[GasDetectionCoreDataTool shared].HHReadDataSettingForm.isVoice animated:NO];

    }
    if (row == 2) {
        [self.alarmSwitch setOn:[GasDetectionCoreDataTool shared].HHReadDataSettingForm.isVibration animated:NO];

    }
    if (row == 3) {
        [self.alarmSwitch setOn:[GasDetectionCoreDataTool shared].HHReadDataSettingForm.isContactEmergencyContact animated:NO];

    }
    if (row == 4) {
       
        [self.alarmSwitch setOn:[GasDetectionCoreDataTool shared].HHReadDataSettingForm.isAutoPhoneCall animated:NO];

    }
    
}


@end
