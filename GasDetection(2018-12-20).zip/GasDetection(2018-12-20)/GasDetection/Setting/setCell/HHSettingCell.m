//
//  HHSettingCell.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHSettingCell.h"

@implementation HHSettingCell


+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView{
    HHSettingCell *cell = (HHSettingCell *)[tableView dequeueReusableCellWithIdentifier:@"HHSettingCellId"];
    if (cell == nil) {
        cell= (HHSettingCell *)[[[NSBundle  mainBundle]  loadNibNamed:@"HHSettingCell" owner:nil options:nil]  lastObject];
    }
    
    return cell;
}




- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
