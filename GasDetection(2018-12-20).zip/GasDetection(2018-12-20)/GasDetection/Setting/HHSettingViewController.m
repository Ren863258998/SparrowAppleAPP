//
//  HHSettingViewController.m
//  GasDetection
//
//  Created by 司月 on 2018/8/14.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHSettingViewController.h"
#import "HHAlarmSetViewController.h"
#import "HHSettingCell.h"
#import "HHMyInfoViewController.h"
#import "BRPickerView.h"

#import "SubmitFeedbackViewController.h"
#import "Set_SparrowInfoViewController.h"

@interface HHSettingViewController () <UITableViewDataSource,UITableViewDelegate>
{
    NSString *tmp_rate; // 临时频率
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic , copy) NSArray * settingArray;
@property (nonatomic , copy) NSArray * iconArray;

@end

@implementation HHSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    
}

#pragma mark -- tableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.settingArray[section] count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    HHSettingCell *cell = [HHSettingCell creatXibCellWithTableView:tableView];
    
    cell.title.text = self.settingArray[indexPath.section][indexPath.row];
    cell.icon.image = [UIImage imageNamed:self.iconArray[indexPath.section][indexPath.row]];
    if (indexPath.section == 1 && indexPath.row == 0) {
        if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency > 0) {
            
            
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 1. ) {
                cell.subtitle.text = @"1s";
            }
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 3.) {
                cell.subtitle.text = @"3s";
            }
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 6.) {
                cell.subtitle.text = @"6s";
            }
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 15.) {
               cell.subtitle.text = @"15s";
            }
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 30.) {
                cell.subtitle.text = @"30s";             }
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 60.) {
               cell.subtitle.text = @"1minute";
            }
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 300.) {
                cell.subtitle.text = @"5minute";
            }
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency == 600.) {
               cell.subtitle.text = @"10minute";
            }
        } else {
            // 默认3秒
            cell.subtitle.text = @"3s";

        }
        
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle= UITableViewCellSelectionStyleNone;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50.;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        switch (indexPath.row) {
            case 1:
            {
                Set_SparrowInfoViewController *vc = [Set_SparrowInfoViewController new];
                vc.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:vc animated:YES];
            }
                break;
            case 0:
            {
                
                [self.navigationController pushViewController:[HHMyInfoViewController new] animated:YES];
            }
                break;
                
                
                
            default:
                break;
        }
    }
    
    if (indexPath.section == 1) {
        switch (indexPath.row) {
            case 1:
            {
                [self.navigationController pushViewController:[HHAlarmSetViewController new] animated:YES];
            }
                break;
            case 0:
            {
                
                [BRStringPickerView showStringPickerWithTitle:NSLocalizedString(@"频率选择",@"") dataSource:@[@"1s", @"3s", @"6s", @"15s", @"30s", @"1minute", @"5minute", @"10minute"] defaultSelValue:@"1s" resultBlock:^(id selectValue) {
                    self->tmp_rate = (NSString *)selectValue;
                    
                    
                    CGFloat frequency = 0.0;
                    if ([self->tmp_rate isEqualToString:@"1s"] ) {
                        frequency = 1;
                    }
                    if ([self->tmp_rate isEqualToString:@"3s"] ) {
                        frequency = 3.;
                    }
                    if ([self->tmp_rate isEqualToString:@"6s"] ) {
                        frequency = 6.;
                    }
                    if ([self->tmp_rate isEqualToString:@"15s"] ) {
                        frequency = 15.;
                    }
                    if ([self->tmp_rate isEqualToString:@"30s"] ) {
                        frequency = 30.;
                    }
                    if ([self->tmp_rate isEqualToString:@"1minute"] ) {
                        frequency = 60.;
                    }
                    if ([self->tmp_rate isEqualToString:@"5minute"] ) {
                        frequency = 300.;
                    }
                    if ([self->tmp_rate isEqualToString:@"10minute"] ) {
                        frequency = 600.;
                    }
                    
                    
                    [GasDetectionCoreDataTool shared].HHReadDataSettingForm.frequency  = frequency;
                    [[GasDetectionCoreDataTool shared] HHUpdateData];
                    [tableView reloadData];
                }];
            }
                break;
                
                
                
            default:
                break;
        }
    }
    
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            [self.navigationController pushViewController:[SubmitFeedbackViewController new] animated:YES];
        } else {
            [SVProgressHUD showInfoWithStatus:NSLocalizedString(@"暂无购买渠道", @"")];
        }
    }
    
    
}
#pragma mark -- getter
- (NSArray *)settingArray{
    if (!_settingArray) {
        _settingArray = @[@[NSLocalizedString(@"个人账户信息",@""),NSLocalizedString(@"设备版本信息",nil)],
                          @[NSLocalizedString(@"数据读取频率设置",@""),NSLocalizedString(@"警报设置",@""),NSLocalizedString(@"传感器设置",@"")],
                        @[NSLocalizedString(@"提交反馈",nil),NSLocalizedString(@"购买渠道",nil)]];
    }
    return _settingArray;
}

- (NSArray *)iconArray{
    if (!_iconArray) {
        _iconArray = @[@[@"个人信息",@"set-info-icon"],
                          @[@"频率选择",@"我的报警设置",@"传感器_设置"],
                          @[@"set-feedback-icon",@"set-buy-icon"]];
    }
    return _iconArray;
}

@end
