//
//  HHMyInfoCell.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHMyInfoCell.h"

@implementation HHMyInfoCell
+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView{
    HHMyInfoCell *cell = (HHMyInfoCell *)[tableView dequeueReusableCellWithIdentifier:@"HHMyInfoCellID"];
    if (cell == nil) {
        cell= (HHMyInfoCell *)[[[NSBundle  mainBundle]  loadNibNamed:@"HHMyInfoCell" owner:nil options:nil]  lastObject];
    }
    
    cell.selectionStyle =UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
