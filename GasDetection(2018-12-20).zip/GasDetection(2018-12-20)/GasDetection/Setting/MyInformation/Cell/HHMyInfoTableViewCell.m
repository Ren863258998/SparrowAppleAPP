//
//  HHMyInfoTableViewCell.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHMyInfoTableViewCell.h"

@implementation HHMyInfoTableViewCell

+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView{
    HHMyInfoTableViewCell *cell = (HHMyInfoTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"HHMyInfoTableViewCellId"];
    if (cell == nil) {
        cell= (HHMyInfoTableViewCell *)[[[NSBundle  mainBundle]  loadNibNamed:@"HHMyInfoTableViewCell" owner:nil options:nil]  lastObject];
    }
    
    cell.backView.layer.cornerRadius = 10;
    cell.backView.layer.masksToBounds= YES;
    cell.backView.backgroundColor = [UIColor whiteColor];
    [cell.addBtn addTarget:cell action:@selector(addAction) forControlEvents:UIControlEventTouchUpInside];
    cell.selectionStyle =UITableViewCellSelectionStyleNone;
    
    cell.title.text = NSLocalizedString(@"添加", nil);
    return cell;
}

- (void)addAction{
    !_addBlcok ? : _addBlcok();
}
@end
