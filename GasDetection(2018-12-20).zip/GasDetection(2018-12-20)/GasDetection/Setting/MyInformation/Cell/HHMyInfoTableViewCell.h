//
//  HHMyInfoTableViewCell.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHMyInfoTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *addBtn;
@property (weak, nonatomic) IBOutlet UIView *backView;
@property (weak, nonatomic) IBOutlet UILabel *title;

@property (copy, nonatomic) dispatch_block_t addBlcok;

+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView;

@end

NS_ASSUME_NONNULL_END
