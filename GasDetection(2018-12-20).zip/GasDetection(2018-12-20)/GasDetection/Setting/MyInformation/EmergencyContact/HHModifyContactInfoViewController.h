//
//  HHModifyContactInfoViewController.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum VCType {
    VCTypeAdd = 0,
    VCTypeModify
}VCType;


@class MyInfo;
NS_ASSUME_NONNULL_BEGIN

@interface HHModifyContactInfoViewController : UIViewController

@property (nonatomic , copy) void(^addContactSuccessBlock)(MyInfo *info);
@property (nonatomic , copy) void(^modifyContactSuccessBlock)(EmergencyContact *info,NSIndexPath *index);


@property (nonatomic , strong) EmergencyContact *modifyInfo;
@property (nonatomic , assign) VCType type;
@property (nonatomic , assign) NSIndexPath *index;



@end

NS_ASSUME_NONNULL_END
