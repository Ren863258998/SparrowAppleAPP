//
//  HHModifyContactInfoViewController.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHModifyContactInfoViewController.h"
#import "HHMyInfoCell.h"
#import "HHAddInfoViewController.h"

#import "MyInfo.h"

@interface HHModifyContactInfoViewController () <UITableViewDelegate,UITableViewDataSource>

{
    NSString *tmpName;
    NSString *tmpTel;
    NSString *tmpEmail;
    NSString *tmpMessage;

}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, copy) NSArray *titleArray;
@property (weak, nonatomic) IBOutlet UIButton *saveBtn;


@property (nonatomic, strong) MyInfo *tmpInfo;



@end

@implementation HHModifyContactInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.titleArray = @[NSLocalizedString( @"名字",@""),NSLocalizedString( @"电话",@""),NSLocalizedString( @"邮箱",@""),NSLocalizedString( @"紧急信息",@"")];
    self.title = self.type == 0 ? NSLocalizedString(@"新增联系人信息",@"") : NSLocalizedString(@"修改联系人信息",@"");
    
    _saveBtn.layer.masksToBounds = YES;
    _saveBtn.layer.cornerRadius = _saveBtn.frame.size.height/2;
    
    [_saveBtn setTitle:NSLocalizedString( @"保存",@"") forState:0];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.titleArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HHMyInfoCell *cell = [HHMyInfoCell creatXibCellWithTableView:tableView];
    cell.mainTitle.text = self.titleArray[indexPath.row];
    if (indexPath.row == 0) {
        cell.content.text =  self.tmpInfo.name;
    }
    if (indexPath.row == 1) {
        cell.content.text = self.tmpInfo.tel;
    }
    if (indexPath.row == 2) {
        cell.content.text =  self.tmpInfo.email;
    }
    if (indexPath.row == 3) {
        cell.content.text =  self.tmpInfo.message;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50.f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10.;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HHAddInfoViewController *addVC = [HHAddInfoViewController new];
    
    __weak typeof(self) weakSelf = self;
    switch (indexPath.row) {
        case 0:
        {
            
            addVC.title = NSLocalizedString( @"修改名字",@"");
            addVC.infoTextChangeBlock = ^(NSString * _Nonnull infoText) {
                weakSelf.tmpInfo.name = infoText;
                [tableView reloadData];
            };
            [self.navigationController pushViewController:addVC animated:YES];
            
        }
            break;
        case 1:
        {
            addVC.title = NSLocalizedString( @"修改电话",@"");
            addVC.infoTextChangeBlock = ^(NSString * _Nonnull infoText) {
                weakSelf.tmpInfo.tel = infoText;
                [tableView reloadData];
            };
            [self.navigationController pushViewController:addVC animated:YES];
        }
            break;
        case 2:
        {
            addVC.title = NSLocalizedString( @"修改邮箱",@"");
            addVC.infoTextChangeBlock = ^(NSString * _Nonnull infoText) {
                weakSelf.tmpInfo.email = infoText;
                [tableView reloadData];
            };
            [self.navigationController pushViewController:addVC animated:YES];
        }
            break;
        case 3:
        {
            addVC.title = NSLocalizedString( @"编辑信息",@"");
            addVC.infoTextChangeBlock = ^(NSString * _Nonnull infoText) {
                weakSelf.tmpInfo.message = infoText;
                [tableView reloadData];
            };
            [self.navigationController pushViewController:addVC animated:YES];
        }
            break;
        
            
        default:
            break;
    }
}
- (IBAction)saveBtnAction:(id)sender {
    
    if (self.type == 0) {
        !_addContactSuccessBlock ? :_addContactSuccessBlock(self.tmpInfo);

    } else {
         !_modifyContactSuccessBlock ? :_modifyContactSuccessBlock(self.modifyInfo,self.index);
        self.modifyInfo.email = self.tmpInfo.email;
        self.modifyInfo.name = self.tmpInfo.name;
        self.modifyInfo.phoneNumber = self.tmpInfo.tel;
        self.modifyInfo.emergencyInformation = self.tmpInfo.message;

        [[GasDetectionCoreDataTool shared] HHUpdateData];

    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (MyInfo *)tmpInfo{
    if (!_tmpInfo) {
        _tmpInfo = [MyInfo new];
        
        _tmpInfo.name = self.modifyInfo.name.length ? self.modifyInfo.name : @"null";;
        _tmpInfo.tel = self.modifyInfo.phoneNumber.length ? self.modifyInfo.phoneNumber : @"null";;
        _tmpInfo.email = self.modifyInfo.email.length ? self.modifyInfo.email : @"null";
        _tmpInfo.message = self.modifyInfo.emergencyInformation.length ? self.modifyInfo.emergencyInformation : @"null";;
    }
    return _tmpInfo;
}



@end
