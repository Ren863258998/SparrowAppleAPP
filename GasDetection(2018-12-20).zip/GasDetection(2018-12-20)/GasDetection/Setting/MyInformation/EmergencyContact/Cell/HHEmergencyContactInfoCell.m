//
//  HHEmergencyContactInfoCell.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHEmergencyContactInfoCell.h"

@implementation HHEmergencyContactInfoCell
+ (instancetype)creatXibCellWithTableView:(UITableView *)tableView{
    HHEmergencyContactInfoCell *cell = (HHEmergencyContactInfoCell *)[tableView dequeueReusableCellWithIdentifier:@"HHEmergencyContactInfoCellID"];
    if (cell == nil) {
        cell= (HHEmergencyContactInfoCell *)[[[NSBundle  mainBundle]  loadNibNamed:@"HHEmergencyContactInfoCell" owner:nil options:nil]  lastObject];
    }
    
    cell.backView.layer.cornerRadius = 10;
    cell.backView.layer.masksToBounds= YES;
    cell.backView.backgroundColor = [UIColor whiteColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

@end
