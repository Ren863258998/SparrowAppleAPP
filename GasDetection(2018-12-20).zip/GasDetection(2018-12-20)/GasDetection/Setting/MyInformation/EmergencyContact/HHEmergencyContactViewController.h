//
//  HHEmergencyContactViewController.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHEmergencyContactViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
