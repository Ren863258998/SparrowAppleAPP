//
//  HHEmergencyContactViewController.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHEmergencyContactViewController.h"

#import "HHMyInfoTableViewCell.h"
#import "HHEmergencyContactInfoCell.h"
#import "HHModifyContactInfoViewController.h"

#import "MyInfo.h"
@interface HHEmergencyContactViewController ()
@property (nonatomic, copy) NSArray *titleArray;

@property (nonatomic, copy) NSMutableArray <EmergencyContact*>*contactArray;

@end

@implementation HHEmergencyContactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = NSLocalizedString( @"添加紧急联系人",@"");

}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) return 1;
    return [[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact].count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    __weak typeof(self) weakSelf = self;
    if (indexPath.section == 1) {
        
        EmergencyContact *info = [[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact][indexPath.row];
        
        HHEmergencyContactInfoCell *cell = [HHEmergencyContactInfoCell creatXibCellWithTableView:tableView];
        cell.contantName.text = info.name;
        cell.contactTel.text  = info.phoneNumber;
        cell.contactEmail.text = info.email;
        return cell;
    }
    
    HHMyInfoTableViewCell *cell = [HHMyInfoTableViewCell creatXibCellWithTableView:tableView];
    cell.title.text = NSLocalizedString( @"添加紧急联系人",@"");
    cell.addBlcok = ^{
        
        
        // 目前只允许添加一个紧急联系人
        if ([[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact].count >= 1) {
            
            [HHAlertController HHErrorNew:NSLocalizedString(@"提示",@"") Message:NSLocalizedString(@"只允许添加一个紧急联系人",@"") ViewController:self ActionBlock:nil];
            
            
            return ;
        }
        
        
        [weakSelf addContant];
    };
    return cell;
}

#pragma mark -- 添加紧急联系人 按钮事件
- (void)addContant{
    HHModifyContactInfoViewController *addVC = [HHModifyContactInfoViewController new];
    addVC.type = VCTypeAdd;
    __weak typeof(self) weakSelf = self;
    addVC.addContactSuccessBlock = ^(MyInfo * _Nonnull info) {
        
        [[GasDetectionCoreDataTool shared] HHInsertDataEmergencyContact:info.name PhoneNumber:info.tel Email:info.email EmergencyInformation:info.message];

//        weakSelf.contactArray = [[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact];
  
    
        [weakSelf.tableView reloadData];
    };
    [self.navigationController pushViewController:addVC animated:YES];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 1) {
        HHModifyContactInfoViewController *modifyVC = [HHModifyContactInfoViewController new];
        modifyVC.type = VCTypeModify;
        modifyVC.index = indexPath;
        modifyVC.modifyInfo = [[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact][indexPath.row];
        __weak typeof(self) weakSelf = self;
        modifyVC.modifyContactSuccessBlock = ^(EmergencyContact * _Nonnull info, NSIndexPath * _Nonnull index) {
            
            
            [weakSelf.tableView reloadData];
        };
        [self.navigationController pushViewController:modifyVC animated:YES];
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 175.;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10.;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 1) {
        return YES;
    }
    return NO;
    
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return UITableViewCellEditingStyleDelete;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return NSLocalizedString( @"删除",@"");
    
}


- (BOOL)tableView: (UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return NO;
    
}

// 5.点击删除的实现。特别提醒：必须要先删除了数据，才能再执行删除的动画或者其他操作，不然会引起崩溃。

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    EmergencyContact *contact = [[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact][indexPath.row];
    
    [[GasDetectionCoreDataTool shared] HHDeleteDataEmergencyContact:contact];
    
    
    [tableView reloadData];
    
}


#pragma arguments -- getter
- (NSMutableArray *)contactArray {
    if (!_contactArray) {
        _contactArray = [NSMutableArray array];
    }
    return _contactArray;
}
@end
