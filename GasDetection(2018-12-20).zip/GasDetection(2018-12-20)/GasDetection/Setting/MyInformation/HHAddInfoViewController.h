//
//  HHAddInfoViewController.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HHAddInfoViewController : UIViewController

@property (nonatomic , copy) NSString *mainTitle;
@property (nonatomic, copy) void (^infoTextChangeBlock)(NSString *infoText);

@end

NS_ASSUME_NONNULL_END
