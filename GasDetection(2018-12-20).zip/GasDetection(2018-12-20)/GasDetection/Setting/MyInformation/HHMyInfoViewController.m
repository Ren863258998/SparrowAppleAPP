//
//  HHMyInfoViewController.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHMyInfoViewController.h"
#import "HHMyInfoTableViewCell.h"
#import "HHMyInfoCell.h"
#import "HHAddInfoViewController.h"
#import "HHEmergencyContactViewController.h"
#import "BRPickerView.h"

@interface HHMyInfoViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSString *tmp_birthday;
    NSString *tmp_sex;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, copy) NSArray *titleArray;
@property (nonatomic, copy) NSMutableDictionary *infoDict;

@property (nonatomic, strong) UserInformation *user;
@property (nonatomic, copy) NSArray *contactArray;


@end

@implementation HHMyInfoViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
//    self.user = [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].name;
    self.contactArray = [[GasDetectionCoreDataTool shared] HHReadDataEmergencyContact];
    [_tableView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"我的个人信息",nil);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.titleArray = @[NSLocalizedString(@"添加个人信息",nil),NSLocalizedString(@"添加紧急联系人",nil)];
    self.titleArray = @[NSLocalizedString(@"名字",nil),NSLocalizedString(@"生日",nil),NSLocalizedString(@"性别",nil),NSLocalizedString(@"邮箱",nil),NSLocalizedString(@"紧急联系人",nil)];

    
}

#pragma mark -- tableView
- (BOOL)hidesBottomBarWhenPushed{
    return YES;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titleArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HHMyInfoCell *cell = [HHMyInfoCell creatXibCellWithTableView:tableView];
    cell.mainTitle.text = self.titleArray[indexPath.row];
    
    if (indexPath.row == 0) {
        NSLog(@"%@",[[GasDetectionCoreDataTool shared] HHReadDataUserInformation].name);
        cell.content.text = [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].name.length ? [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].name : NSLocalizedString(@"暂无",nil);
    }
    if (indexPath.row == 1) {
        cell.content.text = [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].birthday.length ? [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].birthday : NSLocalizedString(@"暂无",nil);
    }
    
    if (indexPath.row == 2) {
        cell.content.text = [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].sex.length ? [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].sex : NSLocalizedString(@"暂无",nil);
    }
    if (indexPath.row == 3) {
        cell.content.text = [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].email.length ? [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].email : NSLocalizedString(@"暂无",nil);
    }
    if (indexPath.row == 4) {
        cell.content.text = [NSString stringWithFormat:@"%ld",self.contactArray.count];
    }
    
    return cell;

}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HHAddInfoViewController *addVC = [HHAddInfoViewController new];
    addVC.hidesBottomBarWhenPushed = YES;
//    __weak typeof(self) weakSelf = self;
    switch (indexPath.row) {
        case 0:
            {

                
                addVC.title = NSLocalizedString(@"修改名字", nil);
                addVC.infoTextChangeBlock = ^(NSString * _Nonnull infoText) {
                    NSLog(@"--------%@",infoText);
                    [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].name = infoText;
                    [[GasDetectionCoreDataTool shared] HHUpdateData];
                    [tableView reloadData];
                };
                [self.navigationController pushViewController:addVC animated:YES];
                
            }
            break;
        case 1:
        {
//            NSDate *minDate = [NSDate br_setYear:1990 month:3 day:12];
//            NSDate *maxDate = [NSDate date];
            [BRDatePickerView showDatePickerWithTitle:NSLocalizedString(@"出生日期", nil) dateType:BRDatePickerModeYMD defaultSelValue:nil minDate:nil maxDate:nil isAutoSelect:YES themeColor:nil resultBlock:^(NSString *selectValue) {
                [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].birthday  = (NSString *)selectValue;
                [[GasDetectionCoreDataTool shared] HHUpdateData];
                [tableView reloadData];
                
            } cancelBlock:^{
                NSLog(@"点击了背景或取消按钮");
            }];
        }
            break;
        case 2:
        {
            [BRStringPickerView showStringPickerWithTitle:NSLocalizedString(@"选择性别", nil) dataSource:@[NSLocalizedString(@"女", nil),NSLocalizedString(@"男", nil)] defaultSelValue:@"10s" resultBlock:^(id selectValue) {
                  [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].sex  = (NSString *)selectValue;
                [[GasDetectionCoreDataTool shared] HHUpdateData];

                [tableView reloadData];
            }];
        }
            break;
        case 3:
        {
            addVC.title = NSLocalizedString(@"修改邮箱", nil);
            addVC.infoTextChangeBlock = ^(NSString * _Nonnull infoText) {
//                weakSelf.user.email = infoText;
                [[GasDetectionCoreDataTool shared] HHReadDataUserInformation].email  = infoText;
                [[GasDetectionCoreDataTool shared] HHUpdateData];

                [tableView reloadData];
            };
            [self.navigationController pushViewController:addVC animated:YES];
        }
            break;
        case 4:
        {
            HHEmergencyContactViewController *contactVC = [HHEmergencyContactViewController new];
            [self.navigationController pushViewController:contactVC animated:YES];
        }
            break;
            
        default:
            break;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50.;
}

- (NSMutableDictionary *)infoDict{
    if (!_infoDict) {
        _infoDict = [NSMutableDictionary dictionaryWithDictionary:@{@"name":NSLocalizedString(@"暂无", nil),
                                                                    @"birthday":NSLocalizedString(@"暂无", nil),
                                                                    @"sex":NSLocalizedString(@"暂无", nil),
                                                                    @"email":NSLocalizedString(@"暂无", nil),
                                                                    @"contact":NSLocalizedString(@"暂无", nil)
                                                                    }];
    }
    return _infoDict;
}
@end
