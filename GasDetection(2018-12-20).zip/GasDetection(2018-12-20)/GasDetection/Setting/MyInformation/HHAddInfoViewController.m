//
//  HHAddInfoViewController.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/18.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHAddInfoViewController.h"

@interface HHAddInfoViewController ()
@property (weak, nonatomic) IBOutlet UITextField *infoTextField;
@property (weak, nonatomic) IBOutlet UIButton *enterBtn;

@end

@implementation HHAddInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.infoTextField addTarget:self action:@selector(textValueChange:) forControlEvents:UIControlEventValueChanged];
    _enterBtn.layer.masksToBounds = YES;
    _enterBtn.layer.cornerRadius = _enterBtn.frame.size.height/2;
    
    _infoTextField.placeholder = NSLocalizedString(@"请输入要修改的相关信息", nil);
    
    [_enterBtn setTitle:NSLocalizedString(@"确认",nil) forState:0];
}
- (IBAction)enterBtnAction:(id)sender {
    !_infoTextChangeBlock ? : _infoTextChangeBlock(self.infoTextField.text);

    [self.navigationController popViewControllerAnimated:YES];

}
- (void)textValueChange:(UITextField *)textField{
    
}
- (BOOL)hidesBottomBarWhenPushed{
    return YES;
}

@end
