//
//  Set_SparrowInfoViewController.m
//  GasDetection
//
//  Created by catbook on 2018/10/8.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "Set_SparrowInfoViewController.h"
#import "Set_SparrowInfoTableViewCell.h"

@interface Set_SparrowInfoViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic,strong)NSMutableArray *array;

@end

@implementation Set_SparrowInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"设备信息",@"OK");
    
    // 无边线
//    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    // 隐藏多余线
    self.tableView.tableFooterView = [[UIView alloc] init];
    
    
    /// 注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"Set_SparrowInfoTableViewCell" bundle:nil] forCellReuseIdentifier:@"Set_SparrowInfoTableViewCell"];

    HHHardwareModel *hardwareModel = [[HHBluetoothManager shared] hardwareModel];
    
    self.array = [NSMutableArray new];
    
    [self.array addObject:@[NSLocalizedString(@"设备名称",@"OK"),hardwareModel.name]];
    [self.array addObject:@[NSLocalizedString(@"设备UDID",@"OK"),hardwareModel.udid]];
    [self.array addObject:@[NSLocalizedString(@"版本号",@"OK"),hardwareModel.version]];
    [self.array addObject:@[NSLocalizedString(@"CO的传感器敏感系数",@"OK"),hardwareModel.CO_SC]];
    [self.array addObject:@[NSLocalizedString(@"O3的传感器敏感系数",@"OK"),hardwareModel.O3_SC]];

    
}


// 设置表格的组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// 设置每个组有多少行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}

// 设置单元格行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

// 设置单元格显示的内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    Set_SparrowInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Set_SparrowInfoTableViewCell" forIndexPath:indexPath];

    cell.textLabel.text = self.array[indexPath.row][0];
    
    cell.detailTextLabel.text = self.array[indexPath.row][1];
    return cell;
}

// cell将要显示
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

// cell将要消失
- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath*)indexPath {
    
}


// 选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
}


/// cell 取消选中状态
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
}










@end
