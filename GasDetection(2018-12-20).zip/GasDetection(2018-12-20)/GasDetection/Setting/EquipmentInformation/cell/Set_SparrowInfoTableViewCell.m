//
//  Set_SparrowInfoTableViewCell.m
//  GasDetection
//
//  Created by 司月 on 2018/11/10.
//  Copyright © 2018 syihh. All rights reserved.
//

#import "Set_SparrowInfoTableViewCell.h"

@implementation Set_SparrowInfoTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
