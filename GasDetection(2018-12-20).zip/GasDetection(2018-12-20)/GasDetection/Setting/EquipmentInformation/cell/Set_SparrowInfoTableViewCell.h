//
//  Set_SparrowInfoTableViewCell.h
//  GasDetection
//
//  Created by 司月 on 2018/11/10.
//  Copyright © 2018 syihh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Set_SparrowInfoTableViewCell : UITableViewCell

@end

NS_ASSUME_NONNULL_END
