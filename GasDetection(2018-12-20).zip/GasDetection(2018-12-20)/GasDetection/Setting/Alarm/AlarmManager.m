//
//  AlarmManager.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/24.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "AlarmManager.h"
#import "NSDate+Extension.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>


@interface AlarmManager ()
@property (nonatomic, strong) AVAudioPlayer *audioPlay;


@end
static AlarmManager *_instance = nil;
@implementation AlarmManager

+ (instancetype)shared{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
        
        
        [_instance play];

    });
    return _instance;
}



- (void)play{
    
    
    
    
    // 使用振动
    if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.isVibration) {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    }
    
    // 是否播放声音
    if (![GasDetectionCoreDataTool shared].HHReadDataSettingForm.isVoice) {
        return;
    }
    
    // 在播放音频前将其设为可后台播放
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:nil];
    [[AVAudioSession sharedInstance] setActive: YES error: nil];

    if (_instance.audioPlay.isPlaying == NO) {
        NSString *soundPath = [[NSBundle mainBundle]pathForResource:@"警报" ofType:@"wav"];
        NSURL *soundUrl = [NSURL fileURLWithPath:soundPath];
        //初始化播放器对象
        _instance.audioPlay = [[AVAudioPlayer alloc]initWithContentsOfURL:soundUrl error:nil];
        //设置声音的大小
        _instance.audioPlay.volume = 1.;//范围为（0到1）；
        //设置循环次数，如果为负数，就是无限循环
        _instance.audioPlay.numberOfLoops =-1;
        //设置播放进度
        _instance.audioPlay.currentTime = 0;
        //准备播放
        [_instance.audioPlay prepareToPlay];

        [_instance.audioPlay play];
    }
    
    
//    AudioServicesPlaySystemSound(1007);
}

- (void)stop{
    AudioServicesDisposeSystemSoundID(kSystemSoundID_Vibrate);
    //    AudioServicesRemoveSystemSoundCompletion(kSystemSoundID_Vibrate);
    [_instance.audioPlay stop];
}

- (void)pause{
    AudioServicesDisposeSystemSoundID(kSystemSoundID_Vibrate);
    //    AudioServicesRemoveSystemSoundCompletion(kSystemSoundID_Vibrate);
    [_instance.audioPlay pause];
}
@end
