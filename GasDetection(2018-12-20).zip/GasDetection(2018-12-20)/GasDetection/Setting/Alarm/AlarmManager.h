//
//  AlarmManager.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/24.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AlarmManager : NSObject

+ (instancetype)shared;

- (void)play;
- (void)stop;
@end

NS_ASSUME_NONNULL_END
