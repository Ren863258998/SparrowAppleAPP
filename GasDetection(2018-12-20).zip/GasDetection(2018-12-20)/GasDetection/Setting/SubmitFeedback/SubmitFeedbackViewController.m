//
//  SubmitFeedbackViewController.m
//  GasDetection
//
//  Created by catbook on 2018/10/8.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "SubmitFeedbackViewController.h"

#import <MessageUI/MessageUI.h>
@interface SubmitFeedbackViewController ()<UITextViewDelegate,MFMailComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIButton *sub;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

@implementation SubmitFeedbackViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    
    self.textView.delegate = self;

    self.title = NSLocalizedString(@"提交反馈", nil);

    _sub.layer.masksToBounds = YES;
    _sub.layer.cornerRadius = 45/2;
    
    _textView.layer.borderColor = [UIColor grayColor].CGColor;
    _textView.layer.borderWidth = 1;
    _textView.layer.masksToBounds = YES;
    _textView.layer.cornerRadius= 4;
}

- (IBAction)submitBtnAction:(id)sender {
    
    
    //判断用户是否已设置邮件账户
    if ([MFMailComposeViewController canSendMail]) {
        [self sendEmailAction]; // 调用发送邮件的代码
    }else{
        //给出提示,设备未开启邮件服务
        [SVProgressHUD showInfoWithStatus:NSLocalizedString(@"设备未开启邮件服务", nil)];
    }
  
}

#pragma mark -- 发送邮件
-(void)sendEmailAction{
    // 创建邮件发送界面
    MFMailComposeViewController *mailCompose = [[MFMailComposeViewController alloc] init];
    // 设置邮件代理
    [mailCompose setMailComposeDelegate:self];
    // 设置收件人
    [mailCompose setToRecipients:@[@"626595005@qq.com"]];
    // 设置抄送人
    [mailCompose setCcRecipients:@[@"626595005@qq.com"]];
    // 设置密送人
    [mailCompose setBccRecipients:@[@"626595005@qq.com"]];
    // 设置邮件主题
    [mailCompose setSubject:NSLocalizedString(@"提交反馈",nil)];
    //设置邮件的正文内容
    NSString *emailContent = _textView.text;
    // 是否为HTML格式
    [mailCompose setMessageBody:emailContent isHTML:NO];
    // 如使用HTML格式，则为以下代码
    // [mailCompose setMessageBody:@"<html><body><p>Hello</p><p>World！</p></body></html>" isHTML:YES];
    //添加附件
//    UIImage *image = [UIImage imageNamed:@"qq"];
//    NSData *imageData = UIImagePNGRepresentation(image);
//    [mailCompose addAttachmentData:imageData mimeType:@"" fileName:@"qq.png"];
//    NSString *file = [[NSBundle mainBundle] pathForResource:@"EmptyPDF" ofType:@"pdf"];
//    NSData *pdf = [NSData dataWithContentsOfFile:file];
//    [mailCompose addAttachmentData:pdf mimeType:@"" fileName:@"EmptyPDF.pdf"];
    // 弹出邮件发送视图
    [self presentViewController:mailCompose animated:YES completion:nil];
}




- (void)textViewDidChange:(UITextView *)textView{
    
}


@end
