//
//  MyInfo.h
//  GasDetection
//
//  Created by 张国微 on 2018/8/20.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyInfo : NSObject
@property (nonatomic , copy) NSString *name;
@property (nonatomic , copy) NSString *tel;
@property (nonatomic , copy) NSString *sex;
@property (nonatomic , copy) NSString *birthday;
@property (nonatomic , copy) NSString *message;
@property (nonatomic , copy) NSString *email;

@end

NS_ASSUME_NONNULL_END
