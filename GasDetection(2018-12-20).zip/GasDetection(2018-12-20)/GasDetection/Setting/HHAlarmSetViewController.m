//
//  HHAlarmSetViewController.m
//  GasDetection
//
//  Created by 张国微 on 2018/8/16.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "HHAlarmSetViewController.h"

#import "HHAlarmSetCell.h"

@interface HHAlarmSetViewController () <UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;


@property (nonatomic , copy) NSArray * settingArray;
@end

@implementation HHAlarmSetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.title = NSLocalizedString(@"警报设置",@"") ;
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    HHAlarmSetCell *cell = [HHAlarmSetCell creatXibCellWithTableView:tableView];
    cell.title.text = self.settingArray[indexPath.row];
    cell.row = indexPath.row;
    cell.selectBlock = ^(NSInteger tag) {
        
        // 判断是否选择自动联系紧急联系人 需提示设置紧急联系人信息
        if (tag == 3) {
            // 判断只要在联系人选项开启的时候才选择
            if ([GasDetectionCoreDataTool shared].HHReadDataSettingForm.isContactEmergencyContact) {
                [HHAlertController HHErrorNew:NSLocalizedString(@"提示",@"") Message:NSLocalizedString(@"请您稍后设置一个紧急联系人信息用于报警提示",@"") ViewController:self ActionBlock:^{
                    
                }];
            }
        }
        
        
//        if (tag == 3 || tag == 4) {
//            [self.tableView reloadData];
//        }
    };
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.001;
}
#pragma mark -- getter
- (NSArray *)settingArray{
    if (!_settingArray) {
        _settingArray = @[NSLocalizedString(@"启用推送",@""),NSLocalizedString(@"启用声音",@""),NSLocalizedString(@"启用震动",@""),NSLocalizedString(@"自动提示联系紧急联系人",@"")];
    }
    return _settingArray;
}

@end
