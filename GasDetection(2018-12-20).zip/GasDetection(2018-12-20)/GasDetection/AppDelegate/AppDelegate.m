//
//  AppDelegate.m
//  GasDetection
//
//  Created by 司月 on 2018/7/9.
//  Copyright © 2018年 syihh. All rights reserved.
//

#import "AppDelegate.h"
#import "HHTabBarController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {


    /// 通知授权
    [HHUserNotifications HHRequestAuthorizationWithOptions];

    /// 初始化蓝牙管理类
    [HHBluetoothManager shared];

    /// 初始化数据库
    [GasDetectionCoreDataTool shared];

    return YES;
    
}

///// 是否允许横屏
//- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
//    
//    if (!self.allowRotation) {
//        // 默认返回支持所有方向
//        return UIInterfaceOrientationMaskAll;
//    }
//    
//    // 获取当前屏幕方向
//    UIInterfaceOrientation orientation = application.statusBarOrientation;
//    
//    // 判断如果是横屏 不允许竖屏
//    if (orientation == UIInterfaceOrientationLandscapeLeft ||
//        orientation == UIInterfaceOrientationLandscapeRight) {
//        // 不允许竖屏
//        return UIInterfaceOrientationMaskLandscape;
//    }else {
//        // 不允许横屏
//        return UIInterfaceOrientationMaskPortrait;
//    }
//    
//}

// 程序将要进入后台
- (void)applicationWillResignActive:(UIApplication *)application {
    NSLog(@"程序将要进入后台");
    
}

// 程序进入后台
- (void)applicationDidEnterBackground:(UIApplication *)application {
    NSLog(@"程序进入后台");
    
}

// 程序将要进入前台
- (void)applicationWillEnterForeground:(UIApplication *)application {
    NSLog(@"程序将要进入前台");
    
}

// 程序进入前台
- (void)applicationDidBecomeActive:(UIApplication *)application {
    NSLog(@"程序进入前台");
 
}

// 程序终止
- (void)applicationWillTerminate:(UIApplication *)application {
    NSLog(@"程序终止");
    
}




@end
