//
//  HHNavigationController.m
//  nav
//
//  Created by 司月 on 2018/4/11.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import "HHNavigationController.h"
#import "YYFPSLabel.h"

@interface HHNavigationController ()

/// FPS
@property (nonatomic,strong)YYFPSLabel *fpsLabel;


@end

@implementation HHNavigationController

//// 窗口旋转或大小改变时
//- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
//
//    // 记录当前是横屏还是竖屏
//    BOOL isLandscape = size.width < size.height;
//    // 翻转的时间
//    CGFloat duration = [coordinator transitionDuration];
//
//    [UIView animateWithDuration:duration animations:^{
//        if (isLandscape) {
//            NSLog(@"竖屏");
//        }else{
//            NSLog(@"横屏");
//        }
//    }];
//}

// frame改变的时候
- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    if (STARUSBAR_HEIGHT <= 0) {
        self.fpsLabel.frame = CGRectMake((SCREEN_WIDTH - 55) / 3, 6, 55, 20);
    }else{
        self.fpsLabel.frame = CGRectMake((SCREEN_WIDTH - 55) / 2, STARUSBAR_HEIGHT - 11, 55, 20);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // 设置状态栏颜色
    self.navigationBar.barStyle = UIBarStyleBlack;
    
    // 设置导航栏 不透明
//    self.navigationBar.translucent = YES;
    
    // 设置导航栏图片
//    [self.navigationBar setBackgroundImage:[UIImage HHColor:RGBColor(49, 98, 177)] forBarMetrics:UIBarMetricsDefault];

//    [self.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
    self.navigationBar.shadowImage = [[UIImage alloc] init];
    
    // 设置导航栏颜色
    self.navigationBar.barTintColor = [UIColor whiteColor];
    
    // 设置导航栏文字颜色
    self.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    
    // 设置导航栏按钮的颜色
    self.navigationBar.tintColor = [UIColor whiteColor];
    
    // 启用大标题导航条
//    self.navigationBar.prefersLargeTitles = YES;
    
    // 设置自动大标题模式
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAutomatic;
    
    
    // 设置导航工具栏 不透明
    self.toolbar.translucent = NO;
    
    // 设置工具栏颜色
    self.toolbar.backgroundColor = [UIColor whiteColor];

   
    
//    // 创建fps
//    YYFPSLabel *fpsLabel = [YYFPSLabel new];
//    fpsLabel.frame = CGRectMake((SCREEN_WIDTH - 55) / 2, STARUSBAR_HEIGHT - 11, 55, 20);
//    [fpsLabel sizeToFit];
//    [self.view addSubview:fpsLabel];
//    self.fpsLabel = fpsLabel;
    
 
}




// 自动隐藏iPhone X 横条
- (BOOL)prefersHomeIndicatorAutoHidden {
    return self.isHomeIndicatorAutoHidden;
}

// 设置样式
- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

// 设置是否隐藏
- (BOOL)prefersStatusBarHidden {
    return self.isStatusHidden;
}

// 设置隐藏动画
- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationFade;
}


/// 是否隐藏状态栏
- (void)setIsStatusHidden:(BOOL)isStatusHidden {
    if (self.isStatusHidden == isStatusHidden) {
        return;
    }
    
    _isStatusHidden = isStatusHidden;
    
    [UIView animateWithDuration:0.4 animations:^{
        // 刷新状态栏
        [self setNeedsStatusBarAppearanceUpdate];
    }];
    
}


/// 是否隐藏home键
- (void)setIsHomeIndicatorAutoHidden:(BOOL)isHomeIndicatorAutoHidden {
    if (self.isHomeIndicatorAutoHidden == isHomeIndicatorAutoHidden) {
        return;
    }
    
    _isHomeIndicatorAutoHidden = isHomeIndicatorAutoHidden;
    
    [UIView animateWithDuration:0.4 animations:^{
        // 刷新home键状态
        [self setNeedsUpdateOfHomeIndicatorAutoHidden];
    }];
    
}




// 内存警告
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    NSLog(@"⚠️收到内存警告_HHNavigationController");
}



@end
