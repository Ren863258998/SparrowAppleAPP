//
//  HHNavigationController.h
//  nav
//
//  Created by 司月 on 2018/4/11.
//  Copyright © 2018年 syimm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HHNavigationController : UINavigationController


/// 是否隐藏状态栏
@property(nonatomic,assign)BOOL isStatusHidden;

/// 是否隐藏home键
@property(nonatomic,assign)BOOL isHomeIndicatorAutoHidden;





@end
